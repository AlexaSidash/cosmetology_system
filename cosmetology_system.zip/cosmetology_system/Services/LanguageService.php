<?php
namespace App\Services;

class LanguageService
{
    private $availableLanguages = ['uk', 'en'];
    private $defaultLanguage = 'uk';
    private $translations = [];
    
    public function __construct()
    {
        $this->loadTranslations();
    }
    
    private function loadTranslations()
    {
        $currentLang = $this->getCurrentLanguage();
        $filePath = __DIR__ . "/../../languages/{$currentLang}.php";
        if (file_exists($filePath)) {
            $this->translations = require $filePath;
        }
    }
    
    public function getCurrentLanguage()
    {
        if (isset($_COOKIE['lang']) && in_array($_COOKIE['lang'], $this->availableLanguages)) {
            return $_COOKIE['lang'];
        }
        
        // Перевірка мови браузера
        if (isset($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
            $browserLang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
            if (in_array($browserLang, $this->availableLanguages)) {
                return $browserLang;
            }
        }
        
        return $this->defaultLanguage;
    }
    
    public function setLanguage($lang)
    {
        if (in_array($lang, $this->availableLanguages)) {
            setcookie('lang', $lang, time() + 86400 * 30, '/');
            $_COOKIE['lang'] = $lang;
            return true;
        }
        return false;
    }
    
    public function trans($key, $default = null)
    {
        return $this->translations[$key] ?? $default ?? $key;
    }
    
    public function getAvailableLanguages()
    {
        return $this->availableLanguages;
    }
}