<?php
// Services/EmailService.php

class EmailService {
    private $mail;
    
    public function __construct() {
        require_once __DIR__ . '/../phpmailer/PHPMailer.php';
        require_once __DIR__ . '/../phpmailer/SMTP.php';
        require_once __DIR__ . '/../phpmailer/Exception.php';
        
        $this->mail = new PHPMailer\PHPMailer\PHPMailer(true);
        $this->setupSMTP();
    }
    
    private function setupSMTP() {
        // Налаштування SMTP (змініть на ваші дані)
        $this->mail->isSMTP();
        $this->mail->Host = 'smtp.gmail.com';       // Ваш SMTP сервер
        $this->mail->SMTPAuth = true;
        $this->mail->Username = 'your_email@gmail.com';  // Ваш email
        $this->mail->Password = 'your_password';         // Ваш пароль
        $this->mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $this->mail->Port = 587;
        $this->mail->setFrom('your_email@gmail.com', 'Cosmetology Clinic');
        $this->mail->CharSet = 'UTF-8';
        $this->mail->isHTML(true);
    }
    
    public function sendBookingConfirmation($to, $name, $appointmentData) {
        try {
            $this->mail->clearAddresses();
            $this->mail->addAddress($to, $name);
            $this->mail->Subject = 'Підтвердження запису на процедуру';
            
            // Генеруємо PDF талон
            $pdfService = new PdfService();
            $pdfContent = $pdfService->generateAppointmentTicket($appointmentData);
            
            // Тіло листа
            $body = $this->getEmailBody($name, $appointmentData);
            $this->mail->Body = $body;
            $this->mail->AltBody = strip_tags($body);
            
            // Додаємо PDF як вкладення
            $this->mail->addStringAttachment($pdfContent, 'talon.pdf', 'base64', 'application/pdf');
            
            return $this->mail->send();
        } catch (Exception $e) {
            error_log("Email sending failed: " . $this->mail->ErrorInfo);
            return false;
        }
    }
    
    public function sendReminder($to, $name, $appointmentData) {
        try {
            $this->mail->clearAddresses();
            $this->mail->addAddress($to, $name);
            $this->mail->Subject = 'Нагадування про візит';
            
            $body = $this->getReminderBody($name, $appointmentData);
            $this->mail->Body = $body;
            $this->mail->AltBody = strip_tags($body);
            
            return $this->mail->send();
        } catch (Exception $e) {
            error_log("Email sending failed: " . $this->mail->ErrorInfo);
            return false;
        }
    }
    
    private function getEmailBody($name, $data) {
        return "
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #0d6efd; color: white; padding: 20px; text-align: center; border-radius: 10px 10px 0 0; }
                .content { background: #f8f9fa; padding: 20px; border-radius: 0 0 10px 10px; }
                .details { background: white; padding: 15px; border-radius: 8px; margin: 15px 0; }
                .detail-row { display: flex; padding: 8px 0; border-bottom: 1px solid #eee; }
                .detail-label { font-weight: bold; width: 120px; }
                .detail-value { flex: 1; }
                .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
                .btn { display: inline-block; padding: 10px 20px; background: #0d6efd; color: white; text-decoration: none; border-radius: 5px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h2>Підтвердження запису</h2>
                </div>
                <div class='content'>
                    <p>Шановний(а) <strong>{$name}</strong>!</p>
                    <p>Дякуємо, що обрали нашу косметологічну клініку. Ваш запис успішно підтверджено.</p>
                    
                    <div class='details'>
                        <div class='detail-row'>
                            <div class='detail-label'>Послуга:</div>
                            <div class='detail-value'>{$data['service_name']}</div>
                        </div>
                        <div class='detail-row'>
                            <div class='detail-label'>Дата:</div>
                            <div class='detail-value'>{$data['date']}</div>
                        </div>
                        <div class='detail-row'>
                            <div class='detail-label'>Час:</div>
                            <div class='detail-value'>{$data['time']}</div>
                        </div>
                        <div class='detail-row'>
                            <div class='detail-label'>Вартість:</div>
                            <div class='detail-value'>{$data['price']} грн</div>
                        </div>
                    </div>
                    
                    <p>До Вашої електронної пошти додається PDF-талон, який Ви можете роздрукувати або зберегти на телефоні.</p>
                    <p>Будь ласка, приходьте за 5-10 хвилин до початку процедури.</p>
                    
                    <hr>
                    <p>З повагою,<br>Команда косметологічної клініки</p>
                </div>
                <div class='footer'>
                    <p>Це повідомлення згенеровано автоматично. Будь ласка, не відповідайте на нього.</p>
                </div>
            </div>
        </body>
        </html>";
    }
    
    private function getReminderBody($name, $data) {
        return "
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #ffc107; color: #333; padding: 20px; text-align: center; border-radius: 10px 10px 0 0; }
                .content { background: #f8f9fa; padding: 20px; border-radius: 0 0 10px 10px; }
                .details { background: white; padding: 15px; border-radius: 8px; margin: 15px 0; }
                .detail-row { display: flex; padding: 8px 0; border-bottom: 1px solid #eee; }
                .detail-label { font-weight: bold; width: 120px; }
                .detail-value { flex: 1; }
                .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h2>⏰ Нагадування про візит</h2>
                </div>
                <div class='content'>
                    <p>Шановний(а) <strong>{$name}</strong>!</p>
                    <p>Нагадуємо, що у Вас заплановано візит до нашої клініки:</p>
                    
                    <div class='details'>
                        <div class='detail-row'>
                            <div class='detail-label'>Послуга:</div>
                            <div class='detail-value'>{$data['service_name']}</div>
                        </div>
                        <div class='detail-row'>
                            <div class='detail-label'>Дата:</div>
                            <div class='detail-value'>{$data['date']}</div>
                        </div>
                        <div class='detail-row'>
                            <div class='detail-label'>Час:</div>
                            <div class='detail-value'>{$data['time']}</div>
                        </div>
                    </div>
                    
                    <p>Чекаємо на Вас! Якщо Ви не зможете прийти, будь ласка, повідомте нас заздалегідь.</p>
                    
                    <hr>
                    <p>З повагою,<br>Команда косметологічної клініки</p>
                </div>
                <div class='footer'>
                    <p>Це повідомлення згенеровано автоматично. Будь ласка, не відповідайте на нього.</p>
                </div>
            </div>
        </body>
        </html>";
    }
}