<?php
// Services/PdfService.php

require_once __DIR__ . '/../vendor/autoload.php'; // для Dompdf

use Dompdf\Dompdf;
use Dompdf\Options;

class PdfService {
    private $dompdf;
    
    public function __construct() {
        $options = new Options();
        $options->set('defaultFont', 'DejaVu Sans');
        $options->set('isHtml5ParserEnabled', true);
        $options->set('isRemoteEnabled', true);
        $this->dompdf = new Dompdf($options);
    }
    
    public function generateAppointmentTicket($appointmentData) {
        $html = $this->getTicketHtml($appointmentData);
        $this->dompdf->loadHtml($html, 'UTF-8');
        $this->dompdf->setPaper('A6', 'portrait');
        $this->dompdf->render();
        return $this->dompdf->output();
    }
    
    private function getTicketHtml($data) {
        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <style>
                body {
                    font-family: 'DejaVu Sans', sans-serif;
                    margin: 0;
                    padding: 10px;
                    background: #f8f9fa;
                }
                .ticket {
                    background: white;
                    border-radius: 10px;
                    padding: 15px;
                    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                }
                .header {
                    text-align: center;
                    border-bottom: 2px dashed #0d6efd;
                    padding-bottom: 10px;
                    margin-bottom: 15px;
                }
                .header h2 {
                    color: #0d6efd;
                    margin: 0;
                    font-size: 18px;
                }
                .header p {
                    margin: 5px 0 0;
                    font-size: 10px;
                    color: #666;
                }
                .info {
                    margin: 15px 0;
                }
                .info-row {
                    display: flex;
                    margin-bottom: 8px;
                    font-size: 11px;
                }
                .info-label {
                    font-weight: bold;
                    width: 70px;
                }
                .info-value {
                    flex: 1;
                }
                .service-details {
                    background: #e9ecef;
                    padding: 10px;
                    border-radius: 8px;
                    margin: 15px 0;
                }
                .service-details h4 {
                    margin: 0 0 5px;
                    font-size: 12px;
                    color: #0d6efd;
                }
                .footer {
                    text-align: center;
                    border-top: 1px dashed #ddd;
                    padding-top: 10px;
                    margin-top: 15px;
                    font-size: 9px;
                    color: #666;
                }
                .barcode {
                    text-align: center;
                    margin: 10px 0;
                    font-family: monospace;
                    font-size: 14px;
                    letter-spacing: 2px;
                }
            </style>
        </head>
        <body>
            <div class='ticket'>
                <div class='header'>
                    <h2>🧴 КОСМЕТОЛОГІЧНА КЛІНІКА</h2>
                    <p>Талон на процедуру</p>
                </div>
                
                <div class='info'>
                    <div class='info-row'>
                        <div class='info-label'>№ талону:</div>
                        <div class='info-value'>{$data['ticket_number']}</div>
                    </div>
                    <div class='info-row'>
                        <div class='info-label'>Дата:</div>
                        <div class='info-value'>{$data['date']}</div>
                    </div>
                    <div class='info-row'>
                        <div class='info-label'>Час:</div>
                        <div class='info-value'>{$data['time']}</div>
                    </div>
                </div>
                
                <div class='service-details'>
                    <h4>📋 Інформація про послугу</h4>
                    <div class='info-row'>
                        <div class='info-label'>Послуга:</div>
                        <div class='info-value'><strong>{$data['service_name']}</strong></div>
                    </div>
                    <div class='info-row'>
                        <div class='info-label'>Тривалість:</div>
                        <div class='info-value'>{$data['duration']} хв</div>
                    </div>
                    <div class='info-row'>
                        <div class='info-label'>Вартість:</div>
                        <div class='info-value'>{$data['price']} грн</div>
                    </div>
                </div>
                
                <div class='info'>
                    <div class='info-row'>
                        <div class='info-label'>Клієнт:</div>
                        <div class='info-value'>{$data['client_name']}</div>
                    </div>
                    <div class='info-row'>
                        <div class='info-label'>Телефон:</div>
                        <div class='info-value'>{$data['client_phone']}</div>
                    </div>
                </div>
                
                <div class='barcode'>
                    ***** {$data['ticket_number']} *****
                </div>
                
                <div class='footer'>
                    <p>Будь ласка, пред'явіть цей талон при відвідуванні<br>
                    Приходьте за 5-10 хвилин до початку процедури</p>
                    <p>📍 вул. Косметологічна, 123 | 📞 +380 XX XXX XXXX</p>
                </div>
            </div>
        </body>
        </html>";
    }
}