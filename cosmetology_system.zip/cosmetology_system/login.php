<?php
session_start();
require_once 'includes/config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    
    // Шукаємо користувача
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    
    if ($user) {
        // Перевіряємо пароль
        if (password_verify($password, $user['password_hash'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['user_role'] = $user['role'];
            
            if ($user['role'] == 'admin') {
                header("Location: admin_dashboard.php");
            } elseif ($user['role'] == 'cosmetologist') {
                header("Location: doctor_cabinet.php");
            } else {
                header("Location: client_cabinet.php");
            }
            exit();
        } else {
            $error = "Невірний пароль! Спробуйте ще раз.";
        }
    } else {
        $error = "Користувача з таким email не знайдено!";
    }
}
?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>Вхід | Cosmology Beauty</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #f9f5f0, #fff);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .login-container {
            max-width: 400px;
            width: 90%;
            background: white;
            border-radius: 30px;
            padding: 40px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        }
        h1 { text-align: center; color: #c7a17a; margin-bottom: 10px; }
        .subtitle { text-align: center; color: #666; margin-bottom: 30px; }
        input {
            width: 100%;
            padding: 14px;
            margin: 10px 0;
            border: 2px solid #f0e6dc;
            border-radius: 15px;
            font-size: 15px;
        }
        button {
            width: 100%;
            background: #c7a17a;
            color: white;
            padding: 14px;
            border: none;
            border-radius: 15px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
        }
        .error {
            background: #fee;
            color: #e74c3c;
            padding: 10px;
            border-radius: 10px;
            margin-bottom: 20px;
            text-align: center;
        }
        .test-data {
            background: #f9f5f0;
            padding: 15px;
            border-radius: 15px;
            margin-top: 20px;
            font-size: 13px;
        }
        .test-data strong { color: #c7a17a; }
        a { color: #c7a17a; text-decoration: none; }
        hr { margin: 15px 0; }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>🌸 Cosmology Beauty</h1>
        <div class="subtitle">Введіть дані для входу</div>
        
        <?php if($error): ?>
            <div class="error">⚠️ <?= $error ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Пароль" required>
            <button type="submit">Увійти</button>
        </form>
        
        
            👤 Клієнт: <a href="register.php">Зареєструватися →</a>
            <hr>
            <a href="doctor_login.php">👩‍⚕️ Вхід для лікарів →</a>
        </div>
    </div>
</body>
</html>