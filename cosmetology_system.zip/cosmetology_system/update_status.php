<?php
require_once '../config.php';
$id = $_GET['id'] ?? 0;
$status = $_GET['status'] ?? '';

$allowed = ['confirmed', 'canceled', 'completed'];
if (in_array($status, $allowed)) {
    $stmt = $pdo->prepare("UPDATE appointments SET status = ? WHERE id = ?");
    $stmt->execute([$status, $id]);
}
header("Location: appointments.php");
?>