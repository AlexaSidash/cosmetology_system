// assets/js/theme.js

// Функція для ініціалізації теми
function initTheme() {
    const savedTheme = localStorage.getItem('theme');
    const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    
    if (savedTheme === 'dark' || (!savedTheme && systemPrefersDark)) {
        document.body.classList.add('dark-mode');
    } else {
        document.body.classList.remove('dark-mode');
    }
}

// Функція для перемикання теми
function toggleTheme() {
    if (document.body.classList.contains('dark-mode')) {
        document.body.classList.remove('dark-mode');
        localStorage.setItem('theme', 'light');
    } else {
        document.body.classList.add('dark-mode');
        localStorage.setItem('theme', 'dark');
    }
}

// Функція для підтвердження виходу
function confirmLogout() {
    if (confirm('Ви дійсно хочете вийти?')) {
        window.location.href = 'logout.php';
    }
    return false;
}

// Запуск ініціалізації при завантаженні сторінки
document.addEventListener('DOMContentLoaded', function() {
    initTheme();
    
    // Додаємо обробник для всіх посилань з класом .lang-link
    const langLinks = document.querySelectorAll('.lang-link');
    langLinks.forEach(function(link) {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const lang = this.getAttribute('data-lang');
            window.location.href = '/switch_language.php?lang=' + lang;
        });
    });
});