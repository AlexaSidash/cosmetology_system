// assets/js/calendar.js

let calendar = null;

function initCalendar() {
    const calendarEl = document.getElementById('calendar');
    if (!calendarEl) return;
    
    calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'timeGridWeek',
        locale: window.currentLang || 'uk',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        slotMinTime: '09:00:00',
        slotMaxTime: '20:00:00',
                allDaySlot: false,
        slotDuration: '00:30:00',
        slotLabelInterval: '01:00:00',
        height: 'auto',
        events: function(fetchInfo, successCallback, failureCallback) {
            fetch(`/api/calendar_events.php?start=${fetchInfo.startStr}&end=${fetchInfo.endStr}`)
                .then(response => response.json())
                .then(data => {
                    successCallback(data);
                })
                .catch(error => {
                    console.error('Error loading events:', error);
                    failureCallback(error);
                });
        },
        eventClick: function(info) {
            if (info.event.extendedProps.status === 'available') {
                // Відкриваємо модальне вікно для запису
                showBookingModal(info.event);
            } else {
                alert(window.translations.msg_time_taken || 'Цей час вже зайнятий');
            }
        },
        eventDidMount: function(info) {
            // Додаємо підказку
            const tooltip = info.event.extendedProps.status === 'available' 
                ? `📝 ${window.translations.click_to_book || 'Натисніть для запису'}: ${info.event.title}`
                : `❌ ${window.translations.already_booked || 'Вже заброньовано'}`;
            info.el.setAttribute('title', tooltip);
            
            // Змінюємо стиль курсора для вільних слотів
            if (info.event.extendedProps.status === 'available') {
                info.el.style.cursor = 'pointer';
            }
        },
        loading: function(isLoading) {
            const calendarEl = document.getElementById('calendar');
            if (isLoading) {
                calendarEl.style.opacity = '0.5';
            } else {
                calendarEl.style.opacity = '1';
            }
        }
    });
    
    calendar.render();
}

function showBookingModal(event) {
    const modalHtml = `
        <div class="modal fade" id="bookingModal" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">${window.translations.confirm_booking || 'Підтвердження запису'}</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <form id="booking-form">
                            <input type="hidden" name="service_id" value="${event.extendedProps.service_id}">
                            <input type="hidden" name="appointment_datetime" value="${event.startStr}">
                            
                            <div class="mb-3">
                                <label class="form-label">${window.translations.form_service || 'Послуга'}</label>
                                <input type="text" class="form-control" value="${event.title}" readonly>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">${window.translations.form_datetime || 'Дата та час'}</label>
                                <input type="text" class="form-control" value="${formatDateTime(event.startStr)}" readonly>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">${window.translations.form_full_name || 'ПІБ'} <span class="text-danger">*</span></label>
                                <input type="text" name="full_name" class="form-control" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">${window.translations.form_phone || 'Телефон'} <span class="text-danger">*</span></label>
                                <input type="tel" name="phone" class="form-control" pattern="\\+38[0-9]{10}" placeholder="+380XXXXXXXXX" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">${window.translations.form_email || 'Email'}</label>
                                <input type="email" name="email" class="form-control">
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">${window.translations.btn_cancel || 'Скасувати'}</button>
                        <button type="button" class="btn btn-primary" onclick="submitBookingFromModal()">${window.translations.btn_confirm || 'Підтвердити'}</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Видаляємо старе модальне вікно, якщо є
    const oldModal = document.getElementById('bookingModal');
    if (oldModal) {
        oldModal.remove();
    }
    
    // Додаємо нове модальне вікно
    document.body.insertAdjacentHTML('beforeend', modalHtml);
    
    // Показуємо модальне вікно
    const modal = new bootstrap.Modal(document.getElementById('bookingModal'));
    modal.show();
}

function formatDateTime(datetime) {
    const date = new Date(datetime);
    return date.toLocaleString('uk-UA', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function submitBookingFromModal() {
    const form = document.getElementById('booking-form');
    const formData = new FormData(form);
    
    fetch('/booking.php', {
        method: 'POST',
        body: formData,
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert(window.translations.msg_booking_success || 'Ви успішно записані!');
            const modal = bootstrap.Modal.getInstance(document.getElementById('bookingModal'));
            modal.hide();
            // Оновлюємо календар
            if (calendar) {
                calendar.refetchEvents();
            }
        } else {
            alert(data.error || window.translations.msg_booking_error || 'Помилка запису');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert(window.translations.msg_booking_error || 'Помилка запису');
    });
}

// Ініціалізація при завантаженні сторінки
document.addEventListener('DOMContentLoaded', function() {
    // Перевіряємо чи є контейнер календаря
    if (document.getElementById('calendar')) {
        // Завантажуємо FullCalendar CSS та JS
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = 'https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.css';
        document.head.appendChild(link);
        
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js';
        script.onload = function() {
            // Завантажуємо локалізацію
            const langScript = document.createElement('script');
            langScript.src = `https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/locales/${window.currentLang || 'uk'}.js`;
            langScript.onload = function() {
                initCalendar();
            };
            document.head.appendChild(langScript);
        };
        document.head.appendChild(script);
    }
});