<?php
session_start();
require_once 'includes/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Отримуємо список лікарів
$doctors = $pdo->query("
    SELECT u.id, u.full_name, u.email, u.phone, u.created_at,
           c.experience_years, c.rating, c.description 
    FROM users u 
    JOIN cosmetologists c ON u.id = c.user_id 
    WHERE u.role = 'cosmetologist'
    ORDER BY u.id DESC
")->fetchAll();

// Обробка видалення лікаря
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND role = 'cosmetologist'");
    $stmt->execute([$id]);
    header("Location: admin_doctors.php");
    exit();
}

// Обробка додавання лікаря
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_doctor'])) {
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $experience = (int)$_POST['experience'];
    $rating = (float)$_POST['rating'];
    $description = $_POST['description'];
    
    // Додаємо користувача
    $stmt = $pdo->prepare("INSERT INTO users (full_name, email, phone, password_hash, role, created_at) VALUES (?, ?, ?, ?, 'cosmetologist', NOW())");
    $stmt->execute([$full_name, $email, $phone, $password]);
    $user_id = $pdo->lastInsertId();
    
    // Додаємо деталі лікаря
    $stmt = $pdo->prepare("INSERT INTO cosmetologists (user_id, experience_years, rating, description, phone, email) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$user_id, $experience, $rating, $description, $phone, $email]);
    
    header("Location: admin_doctors.php");
    exit();
}

// Статистика
$stats = $pdo->query("
    SELECT 
        COUNT(*) as total,
        AVG(rating) as avg_rating,
        SUM(experience_years) as total_exp
    FROM cosmetologists
")->fetch();
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>Лікарі | Cosmology Beauty</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f0eb; }
        
        .sidebar {
            width: 260px;
            background: #2c2c2c;
            color: white;
            position: fixed;
            height: 100%;
            padding: 25px 20px;
        }
        .sidebar h3 { margin-bottom: 30px; color: #c7a17a; text-align: center; font-size: 24px; }
        .sidebar a {
            color: #ddd;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 15px;
            margin: 5px 0;
            border-radius: 12px;
            transition: all 0.3s;
        }
        .sidebar a:hover { background: #c7a17a; color: white; }
        .sidebar a.active { background: #c7a17a; color: white; }
        
        .content {
            margin-left: 260px;
            padding: 30px;
        }
        
        .stats-bar {
            display: flex;
            gap: 20px;
            margin-bottom: 25px;
            flex-wrap: wrap;
        }
        .stat-badge {
            background: white;
            padding: 15px 25px;
            border-radius: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        .stat-badge strong { font-size: 24px; color: #c7a17a; }
        
        .add-form {
            background: white;
            padding: 20px;
            border-radius: 20px;
            margin-bottom: 20px;
        }
        .add-form h3 { color: #c7a17a; margin-bottom: 15px; }
        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 2px solid #f0e6dc;
            border-radius: 10px;
        }
        .btn-add {
            background: #28a745;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            margin-top: 15px;
        }
        
        table {
            width: 100%;
            background: white;
            border-radius: 20px;
            border-collapse: collapse;
            overflow: hidden;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #f0e6dc;
        }
        th { background: #c7a17a; color: white; }
        
        .btn-edit {
            background: #c7a17a;
            color: white;
            padding: 5px 10px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 12px;
        }
        .btn-delete {
            background: #dc3545;
            color: white;
            padding: 5px 10px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 12px;
        }
        
        @media (max-width: 900px) {
            .sidebar { width: 80px; padding: 20px 10px; }
            .sidebar a span:not(.icon) { display: none; }
            .content { margin-left: 80px; }
        }
    </style>
</head>
<body>
  
    <div class="sidebar">
    <h3>✨ Cosmology</h3>
    <a href="admin_dashboard.php"><i class="bi bi-house-door-fill"></i><span>Головна</span></a>
    <a href="admin_clients.php"><i class="bi bi-people-fill"></i><span>Клієнти</span></a>
    <a href="admin_doctors.php" class="active"><i class="bi bi-person-badge-fill"></i><span>Лікарі</span></a>
    <a href="admin_services.php"><i class="bi bi-grid-3x3-gap-fill"></i><span>Послуги</span></a>
    <a href="admin_appointments.php"><i class="bi bi-calendar-check-fill"></i><span>Записи</span></a>
    <a href="admin_certificates.php"><i class="bi bi-patch-check-fill"></i><span>Сертифікати</span></a>
    <a href="admin_stock.php"><i class="bi bi-box-seam-fill"></i><span>Склад</span></a>
    <a href="admin_stock_orders.php"><i class="bi bi-cart-fill"></i><span>Замовлення</span></a>
    <a href="admin_reviews.php"><i class="bi bi-star-fill"></i><span>Відгуки</span></a>
    <a href="admin_finance.php"><i class="bi bi-graph-up"></i><span>Фінанси</span></a>
    <a href="logout.php"><i class="bi bi-box-arrow-right"></i><span>Вихід</span></a>
</div>
    
   
    
    <div class="content">
        <h1 style="margin-bottom: 10px;">👩‍⚕️ Управління лікарями</h1>
        
        <div class="stats-bar">
            <div class="stat-badge">📊 Всього лікарів: <strong><?= $stats['total'] ?? 0 ?></strong></div>
            <div class="stat-badge">⭐ Середній рейтинг: <strong><?= number_format($stats['avg_rating'] ?? 0, 1) ?></strong></div>
            <div class="stat-badge">📅 Загальний досвід: <strong><?= $stats['total_exp'] ?? 0 ?> років</strong></div>
        </div>
        
        <!-- Форма додавання лікаря -->
        <div class="add-form">
            <h3>➕ Додати нового лікаря</h3>
            <form method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <input type="text" name="full_name" placeholder="ПІБ" required>
                    </div>
                    <div class="form-group">
                        <input type="email" name="email" placeholder="Email" required>
                    </div>
                    <div class="form-group">
                        <input type="tel" name="phone" placeholder="Телефон" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <input type="password" name="password" placeholder="Пароль" required>
                    </div>
                    <div class="form-group">
                        <input type="number" name="experience" placeholder="Досвід (років)" required>
                    </div>
                    <div class="form-group">
                        <input type="number" step="0.1" name="rating" placeholder="Рейтинг (0-5)" value="5.0">
                    </div>
                </div>
                <div class="form-group">
                    <textarea name="description" placeholder="Опис, спеціалізація..." rows="2"></textarea>
                </div>
                <button type="submit" name="add_doctor" class="btn-add">➕ Додати лікаря</button>
            </form>
        </div>
        
        <!-- Таблиця лікарів -->
        <table>
            <thead>
                <tr><th>ID</th><th>ПІБ</th><th>Email</th><th>Телефон</th><th>Досвід</th><th>Рейтинг</th><th>Дата реєстрації</th><th>Дії</th></tr>
            </thead>
            <tbody>
                <?php foreach($doctors as $d): ?>
                <tr>
                    <td><?= $d['id'] ?></td>
                    <td><strong><?= htmlspecialchars($d['full_name']) ?></strong></td>
                    <td><?= htmlspecialchars($d['email']) ?></td>
                    <td><?= htmlspecialchars($d['phone']) ?></td>
                    <td><?= $d['experience_years'] ?> років</td>
                    <td>⭐ <?= $d['rating'] ?></td>
                    <td><?= date('d.m.Y', strtotime($d['created_at'])) ?></td>
                    <td>
                        <a href="admin_doctor_edit.php?id=<?= $d['id'] ?>" class="btn-edit">✏️</a>
                        <a href="?delete=<?= $d['id'] ?>" class="btn-delete" onclick="return confirm('Видалити лікаря?')">🗑️</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    
    <script>
    function confirmLogout() {
        if (confirm('Ви дійсно хочете вийти?')) {
            window.location.href = 'logout.php';
        }
    }
    </script>
</body>
</html>