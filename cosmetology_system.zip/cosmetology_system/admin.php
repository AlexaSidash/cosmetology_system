<?php
session_start();
require_once 'includes/config.php';

// Перевірка прав адміністратора
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Обробка підтвердження запису
if (isset($_GET['confirm'])) {
    $id = (int)$_GET['confirm'];
    $stmt = $pdo->prepare("UPDATE appointments SET status = 'confirmed' WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: admin_appointments.php");
    exit();
}

// Обробка скасування запису
if (isset($_GET['cancel'])) {
    $id = (int)$_GET['cancel'];
    $stmt = $pdo->prepare("UPDATE appointments SET status = 'canceled' WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: admin_appointments.php");
    exit();
}

// Обробка позначення "виконано"
if (isset($_GET['complete'])) {
    $id = (int)$_GET['complete'];
    $stmt = $pdo->prepare("UPDATE appointments SET status = 'completed' WHERE id = ?");
    $stmt->execute([$id]);
    
    // Нарахування бонусів клієнту
    $stmt = $pdo->prepare("
        SELECT a.client_id, s.price 
        FROM appointments a 
        JOIN services s ON a.service_id = s.id 
        WHERE a.id = ?
    ");
    $stmt->execute([$id]);
    $app = $stmt->fetch();
    if ($app) {
        $bonus = round($app['price'] * 0.05);
        $stmt = $pdo->prepare("UPDATE users SET bonus_points = bonus_points + ? WHERE id = ?");
        $stmt->execute([$bonus, $app['client_id']]);
    }
    header("Location: admin_appointments.php");
    exit();
}

// Отримуємо всі записи
$appointments = $pdo->query("
    SELECT a.*, 
           u.full_name as client_name, 
           u.phone as client_phone,
           s.name as service_name,
           doc.full_name as doctor_name
    FROM appointments a
    JOIN users u ON a.client_id = u.id
    JOIN services s ON a.service_id = s.id
    JOIN cosmetologists c ON a.cosmetologist_id = c.id
    JOIN users doc ON c.user_id = doc.id
    ORDER BY a.appointment_datetime DESC
")->fetchAll();

// Статистика
$stats = $pdo->query("
    SELECT 
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN status = 'confirmed' THEN 1 ELSE 0 END) as confirmed,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
        SUM(CASE WHEN status = 'canceled' THEN 1 ELSE 0 END) as canceled,
        COUNT(*) as total
    FROM appointments
")->fetch();
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>Управління записами | Cosmology Beauty</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f0eb; }
        
        .sidebar {
            width: 260px;
            background: #2c2c2c;
            color: white;
            position: fixed;
            height: 100%;
            padding: 20px;
        }
        .sidebar h3 { margin-bottom: 30px; color: #c7a17a; }
        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 12px;
            margin: 5px 0;
            border-radius: 10px;
        }
        .sidebar a:hover { background: #c7a17a; }
        .content {
            margin-left: 260px;
            padding: 30px;
        }
        
        .stats {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 15px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 15px;
            border-radius: 15px;
            text-align: center;
        }
        .stat-number { font-size: 28px; font-weight: bold; }
        .stat-pending .stat-number { color: #ffc107; }
        .stat-confirmed .stat-number { color: #28a745; }
        .stat-completed .stat-number { color: #17a2b8; }
        .stat-canceled .stat-number { color: #dc3545; }
        
        table {
            width: 100%;
            background: white;
            border-radius: 15px;
            border-collapse: collapse;
            overflow: hidden;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        th { background: #c7a17a; color: white; }
        
        .status-pending { color: #ffc107; font-weight: bold; }
        .status-confirmed { color: #28a745; font-weight: bold; }
        .status-completed { color: #17a2b8; }
        .status-canceled { color: #dc3545; }
        
        .btn {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 12px;
            margin: 2px;
        }
        .btn-confirm { background: #28a745; color: white; }
        .btn-cancel { background: #dc3545; color: white; }
        .btn-complete { background: #17a2b8; color: white; }
        
        h2 { margin-bottom: 20px; }
    </style>
</head>
<body>
 <div class="sidebar">
    <h3>✨ Cosmology</h3>
    
    <a href="admin_dashboard.php">
        <i class="bi bi-house-door"></i>
        <span>Головна</span>
    </a>
    
    <a href="admin_clients.php">
        <i class="bi bi-people"></i>
        <span>Клієнти</span>
    </a>
    
    <a href="admin_doctors.php">
        <i class="bi bi-person-badge"></i>
        <span>Лікарі</span>
    </a>
    
    <a href="admin_services.php">
        <i class="bi bi-grid-3x3-gap-fill"></i>
        <span>Послуги</span>
    </a>
    
    <a href="admin_appointments.php">
        <i class="bi bi-calendar-check"></i>
        <span>Записи</span>
        <span class="badge">17</span> <!-- цифра, як на одному зі скріншотів -->
    </a>
    
    <a href="admin_certificates.php">
        <i class="bi bi-patch-check"></i>
        <span>Сертифікати</span>
    </a>
    
    <a href="admin_stock.php">
        <i class="bi bi-box-seam"></i>
        <span>Склад</span>
    </a>
    
    <a href="admin_stock_orders.php">
        <i class="bi bi-cart"></i>
        <span>Замовлення</span>
    </a>
    
    <a href="logout.php">
        <i class="bi bi-box-arrow-right"></i>
        <span>Вихід</span>
    </a>
</div>
    
    <div class="content">
        <h2>📅 Управління записами</h2>
        
        <div class="stats">
            <div class="stat-card stat-pending">
                <div class="stat-number"><?= $stats['pending'] ?? 0 ?></div>
                <div>⏳ Очікують</div>
            </div>
            <div class="stat-card stat-confirmed">
                <div class="stat-number"><?= $stats['confirmed'] ?? 0 ?></div>
                <div>✅ Підтверджені</div>
            </div>
            <div class="stat-card stat-completed">
                <div class="stat-number"><?= $stats['completed'] ?? 0 ?></div>
                <div>✔️ Виконані</div>
            </div>
            <div class="stat-card stat-canceled">
                <div class="stat-number"><?= $stats['canceled'] ?? 0 ?></div>
                <div>❌ Скасовані</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= $stats['total'] ?? 0 ?></div>
                <div>📋 Всього</div>
            </div>
        </div>
        
        <table>
            <thead>
                <tr><th>ID</th><th>Клієнт</th><th>Телефон</th><th>Лікар</th><th>Послуга</th><th>Дата та час</th><th>Статус</th><th>Дії</th></tr>
            </thead>
            <tbody>
                <?php foreach($appointments as $a): ?>
                <tr>
                    <td><?= $a['id'] ?></td>
                    <td><?= htmlspecialchars($a['client_name']) ?></td>
                    <td><?= htmlspecialchars($a['client_phone']) ?></td>
                    <td><?= htmlspecialchars($a['doctor_name']) ?></td>
                    <td><?= htmlspecialchars($a['service_name']) ?></td>
                    <td><?= date('d.m.Y H:i', strtotime($a['appointment_datetime'])) ?></td>
                    <td class="status-<?= $a['status'] ?>">
                        <?php if($a['status'] == 'pending'): ?>⏳ Очікує
                        <?php elseif($a['status'] == 'confirmed'): ?>✅ Підтверджено
                        <?php elseif($a['status'] == 'completed'): ?>✔️ Виконано
                        <?php else: ?>❌ Скасовано
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($a['status'] == 'pending'): ?>
                            <a href="?confirm=<?= $a['id'] ?>" class="btn btn-confirm">✅ Підтвердити</a>
                            <a href="?cancel=<?= $a['id'] ?>" class="btn btn-cancel" onclick="return confirm('Скасувати запис?')">❌ Скасувати</a>
                        <?php elseif($a['status'] == 'confirmed'): ?>
                            <a href="?complete=<?= $a['id'] ?>" class="btn btn-complete">✔️ Виконано</a>
                            <a href="?cancel=<?= $a['id'] ?>" class="btn btn-cancel" onclick="return confirm('Скасувати запис?')">❌ Скасувати</a>
                        <?php elseif($a['status'] == 'completed'): ?>
                            <span>✅ Виконано</span>
                        <?php else: ?>
                            <span>❌ Скасовано</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>