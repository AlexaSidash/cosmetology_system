<?php
// admin_login.php
session_start();
require_once 'includes/config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    
    // Отримуємо адміністратора
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND role = 'admin'");
    $stmt->execute([$email]);
    $admin = $stmt->fetch();
    
    if ($admin && password_verify($password, $admin['password_hash'])) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_name'] = $admin['full_name'];
        $_SESSION['user_name'] = $admin['full_name'];
        $_SESSION['user_role'] = 'admin';
        header('Location: admin_dashboard.php');
        exit;
    } else {
        $error = 'Невірний email або пароль';
    }
}
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вхід в адмін-панель | Cosmology Beauty</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f9f5f0 0%, #e8ddd0 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-card {
            background: white;
            border-radius: 24px;
            padding: 40px;
            width: 100%;
            max-width: 420px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        }
        .logo {
            text-align: center;
            font-size: 28px;
            font-weight: bold;
            color: #c7a17a;
            margin-bottom: 30px;
        }
        .logo span {
            color: #2c2c2c;
        }
        .btn-login {
            background: #c7a17a;
            color: white;
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 12px;
            font-weight: 600;
        }
        .btn-login:hover {
            background: #a67c52;
        }
        .alert {
            border-radius: 12px;
        }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="logo">
            Cosmology <span>Beauty</span>
        </div>
        <h3 class="text-center mb-4">🔐 Вхід в адмін-панель</h3>
        
        <?php if($error): ?>
            <div class="alert alert-danger">❌ <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">📧 Email</label>
                <input type="email" name="email" class="form-control" value="admin@cosmology.com" required>
            </div>
            <div class="mb-3">
                <label class="form-label">🔒 Пароль</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <button type="submit" class="btn-login">Увійти</button>
        </form>
        
        <div class="mt-4 text-center">
            <a href="index.php" class="text-muted">← Повернутися на сайт</a>
        </div>
    </div>
</body>
</html>