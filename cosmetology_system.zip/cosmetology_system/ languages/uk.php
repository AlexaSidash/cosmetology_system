<?php
return [
    // Навігація
    'nav_home' => 'Головна',
    'nav_services' => 'Послуги',
    'nav_booking' => 'Запис',
    'nav_reviews' => 'Відгуки',
    'nav_admin' => 'Адмін-панель',
    'nav_login' => 'Вхід',
    'nav_logout' => 'Вихід',
    
    // Кнопки
    'btn_book' => 'Записатися',
    'btn_save' => 'Зберегти',
    'btn_cancel' => 'Скасувати',
    'btn_edit' => 'Редагувати',
    'btn_delete' => 'Видалити',
    'btn_confirm' => 'Підтвердити',
    'btn_back' => 'Назад',
    'btn_filter' => 'Фільтрувати',
    'btn_reset' => 'Скинути',
    
    // Форми
    'form_full_name' => 'Прізвище, ім\'я, по батькові',
    'form_phone' => 'Номер телефону',
    'form_email' => 'Електронна пошта',
    'form_service' => 'Послуга',
    'form_date' => 'Дата',
    'form_time' => 'Час',
    'form_rating' => 'Оцінка',
    'form_comment' => 'Коментар',
    
    // Повідомлення
    'msg_booking_success' => 'Ви успішно записані на процедуру!',
    'msg_booking_error' => 'Помилка запису. Спробуйте пізніше.',
    'msg_time_taken' => 'Обраний час вже зайнятий',
    'msg_invalid_phone' => 'Невірний формат телефону',
    'msg_invalid_email' => 'Невірний формат email',
    'msg_required_field' => 'Заповніть обов\'язкове поле',
    'msg_login_success' => 'Вхід виконано успішно',
    'msg_login_error' => 'Невірний email або пароль',
    'msg_review_added' => 'Дякуємо за відгук! Він буде опублікований після модерації.',
    
    // Заголовки сторінок
    'title_home' => 'Косметологічна клініка | Головна',
    'title_services' => 'Наші послуги',
    'title_booking' => 'Запис на процедуру',
    'title_reviews' => 'Відгуки клієнтів',
    'title_admin' => 'Адміністративна панель',
    
    // Таблиці
    'table_id' => 'ID',
    'table_client' => 'Клієнт',
    'table_service' => 'Послуга',
    'table_datetime' => 'Дата та час',
    'table_status' => 'Статус',
    'table_actions' => 'Дії',
    
    // Статуси
    'status_scheduled' => 'Заплановано',
    'status_completed' => 'Виконано',
    'status_cancelled' => 'Скасовано',
    
    // Фільтри
    'filter_all' => 'Всі',
    'filter_today' => 'Сьогодні',
    'filter_tomorrow' => 'Завтра',
    'filter_week' => 'Цей тиждень',
    
    // Додатково
    'footer_copyright' => 'Всі права захищені',
    'contact_us' => 'Зв\'язатися з нами',
];
// Додати в languages/uk.php
'total_bookings' => 'Всього записів',
'total_clients' => 'Всього клієнтів',
'total_revenue' => 'Виручка',
'booking_dynamics' => 'Динаміка записів',
'bookings_by_status' => 'Записи за статусами',
'popular_services' => 'Найпопулярніші послуги',
'revenue_by_service' => 'Виручка по послугах',
'recent_bookings' => 'Останні записи',
'bookings_per_day' => 'Записів за день',
'number_of_bookings' => 'Кількість записів',
'revenue_grn' => 'Виручка (грн)',
'loading' => 'Завантаження...',
'no_data' => 'Немає даних',
'this_year' => 'Цей рік',

// Додати в languages/en.php
'total_bookings' => 'Total Bookings',
'total_clients' => 'Total Clients',
'total_revenue' => 'Revenue',
'booking_dynamics' => 'Booking Dynamics',
'bookings_by_status' => 'Bookings by Status',
'popular_services' => 'Popular Services',
'revenue_by_service' => 'Revenue by Service',
'recent_bookings' => 'Recent Bookings',
'bookings_per_day' => 'Bookings per Day',
'number_of_bookings' => 'Number of Bookings',
'revenue_grn' => 'Revenue (UAH)',
'loading' => 'Loading...',
'no_data' => 'No data available',
'this_year' => 'This Year',