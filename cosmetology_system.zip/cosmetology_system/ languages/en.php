<?php
return [
    // Navigation
    'nav_home' => 'Home',
    'nav_services' => 'Services',
    'nav_booking' => 'Booking',
    'nav_reviews' => 'Reviews',
    'nav_admin' => 'Admin Panel',
    'nav_login' => 'Login',
    'nav_logout' => 'Logout',
    
    // Buttons
    'btn_book' => 'Book Now',
    'btn_save' => 'Save',
    'btn_cancel' => 'Cancel',
    'btn_edit' => 'Edit',
    'btn_delete' => 'Delete',
    'btn_confirm' => 'Confirm',
    'btn_back' => 'Back',
    'btn_filter' => 'Filter',
    'btn_reset' => 'Reset',
    
    // Forms
    'form_full_name' => 'Full name',
    'form_phone' => 'Phone number',
    'form_email' => 'Email address',
    'form_service' => 'Service',
    'form_date' => 'Date',
    'form_time' => 'Time',
    'form_rating' => 'Rating',
    'form_comment' => 'Comment',
    
    // Messages
    'msg_booking_success' => 'You have successfully booked the procedure!',
    'msg_booking_error' => 'Booking error. Please try again later.',
    'msg_time_taken' => 'The selected time is already taken',
    'msg_invalid_phone' => 'Invalid phone format',
    'msg_invalid_email' => 'Invalid email format',
    'msg_required_field' => 'Please fill in this required field',
    'msg_login_success' => 'Login successful',
    'msg_login_error' => 'Invalid email or password',
    'msg_review_added' => 'Thank you for your review! It will be published after moderation.',
    
    // Page titles
    'title_home' => 'Cosmetology Clinic | Home',
    'title_services' => 'Our Services',
    'title_booking' => 'Book a Procedure',
    'title_reviews' => 'Client Reviews',
    'title_admin' => 'Admin Panel',
    
    // Tables
    'table_id' => 'ID',
    'table_client' => 'Client',
    'table_service' => 'Service',
    'table_datetime' => 'Date & Time',
    'table_status' => 'Status',
    'table_actions' => 'Actions',
    
    // Statuses
    'status_scheduled' => 'Scheduled',
    'status_completed' => 'Completed',
    'status_cancelled' => 'Cancelled',
    
    // Filters
    'filter_all' => 'All',
    'filter_today' => 'Today',
    'filter_tomorrow' => 'Tomorrow',
    'filter_week' => 'This week',
    
    // Additional
    'footer_copyright' => 'All rights reserved',
    'contact_us' => 'Contact us',
];
// Додати в languages/uk.php
'total_bookings' => 'Всього записів',
'total_clients' => 'Всього клієнтів',
'total_revenue' => 'Виручка',
'booking_dynamics' => 'Динаміка записів',
'bookings_by_status' => 'Записи за статусами',
'popular_services' => 'Найпопулярніші послуги',
'revenue_by_service' => 'Виручка по послугах',
'recent_bookings' => 'Останні записи',
'bookings_per_day' => 'Записів за день',
'number_of_bookings' => 'Кількість записів',
'revenue_grn' => 'Виручка (грн)',
'loading' => 'Завантаження...',
'no_data' => 'Немає даних',
'this_year' => 'Цей рік',

// Додати в languages/en.php
'total_bookings' => 'Total Bookings',
'total_clients' => 'Total Clients',
'total_revenue' => 'Revenue',
'booking_dynamics' => 'Booking Dynamics',
'bookings_by_status' => 'Bookings by Status',
'popular_services' => 'Popular Services',
'revenue_by_service' => 'Revenue by Service',
'recent_bookings' => 'Recent Bookings',
'bookings_per_day' => 'Bookings per Day',
'number_of_bookings' => 'Number of Bookings',
'revenue_grn' => 'Revenue (UAH)',
'loading' => 'Loading...',
'no_data' => 'No data available',
'this_year' => 'This Year',