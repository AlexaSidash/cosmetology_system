<?php
session_start();
header('Content-Type: application/json');

// ПЕРЕВІРКА: чи авторизований користувач
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Необхідно авторизуватися для запису']);
    exit;
}

require_once '../includes/config.php';

$client_id = $_SESSION['user_id'];
$service_id = $_POST['service_id'] ?? 0;
$cosmetologist_id = $_POST['cosmetologist_id'] ?? 0;
$appointment_datetime = $_POST['appointment_datetime'] ?? '';

if (!$service_id || !$cosmetologist_id || !$appointment_datetime) {
    echo json_encode(['success' => false, 'error' => 'Не всі дані передані']);
    exit;
}

// Перевірка, чи не зайнятий слот
$stmt = $pdo->prepare("
    SELECT id FROM appointments 
    WHERE cosmetologist_id = ? AND appointment_datetime = ? 
    AND status NOT IN ('canceled', 'no_show')
");
$stmt->execute([$cosmetologist_id, $appointment_datetime]);
if ($stmt->fetch()) {
    echo json_encode(['success' => false, 'error' => 'Цей час вже зайнято']);
    exit;
}

// Створення запису
$stmt = $pdo->prepare("
    INSERT INTO appointments (client_id, cosmetologist_id, service_id, appointment_datetime, status, created_at)
    VALUES (?, ?, ?, ?, 'pending', NOW())
");
$success = $stmt->execute([$client_id, $cosmetologist_id, $service_id, $appointment_datetime]);

if ($success) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'Помилка створення запису']);
}
?>