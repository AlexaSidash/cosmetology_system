<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Запускаємо сесію
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Підключення до БД
$host = 'localhost';
$dbname = 'cosmetology_db';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Помилка підключення до БД: " . $e->getMessage());
}

// ПЕРЕВІРКА АВТОРИЗАЦІЇ
$isLoggedIn = false;
$userId = null;
$userEmail = '';
$userPhone = '';

if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) {
    try {
        // Отримуємо дані користувача
        $stmt = $pdo->prepare("SELECT id, email, phone FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
        
        if ($user) {
            $isLoggedIn = true;
            $userId = $user['id'];
            $userEmail = $user['email'] ?? '';
            $userPhone = $user['phone'] ?? '';
        } else {
            session_destroy();
            $isLoggedIn = false;
        }
    } catch (PDOException $e) {
        $isLoggedIn = false;
    }
}

// Обробка AJAX-запитів
$isAjax = ($_SERVER['REQUEST_METHOD'] === 'POST' && 
           isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
           $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest');

if ($isAjax) {
    if (!$isLoggedIn) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Будь ласка, увійдіть в акаунт', 'redirect' => 'login.php']);
        exit;
    }
    
    header('Content-Type: application/json');
    $action = $_POST['action'] ?? '';
    
    // Отримання вільних слотів
    if ($action === 'get_slots') {
        $cosmetologist_id = (int)$_POST['cosmetologist_id'];
        $date = $_POST['date'];
        $service_id = (int)$_POST['service_id'];
        
        $stmt = $pdo->prepare("SELECT duration_minutes FROM services WHERE id = ?");
        $stmt->execute([$service_id]);
        $service = $stmt->fetch();
        $duration = $service ? $service['duration_minutes'] : 60;
        
        $work_start = 10;
        $work_end = 20;
        $dayOfWeek = date('N', strtotime($date));
        
        if ($dayOfWeek == 6) {
            $work_end = 15;
        } elseif ($dayOfWeek == 7) {
            echo json_encode(['slots' => []]);
            exit;
        }
        
        $allSlots = [];
        $current = $work_start * 60;
        $end = $work_end * 60;
        
        while ($current + $duration <= $end) {
            $hour = floor($current / 60);
            $minute = $current % 60;
            $allSlots[] = sprintf("%02d:%02d", $hour, $minute);
            $current += 30;
        }
        
        $stmt = $pdo->prepare("
            SELECT TIME(appointment_datetime) as slot_time 
            FROM appointments 
            WHERE cosmetologist_id = ? 
            AND DATE(appointment_datetime) = ? 
            AND status NOT IN ('canceled', 'no_show')
        ");
        $stmt->execute([$cosmetologist_id, $date]);
        $bookedSlots = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);
        
        $freeSlots = array_diff($allSlots, $bookedSlots);
        echo json_encode(['slots' => array_values($freeSlots)]);
        exit;
    }
    
    // Створення запису
    if ($action === 'create_booking') {
        $service_id = (int)$_POST['service_id'];
        $cosmetologist_id = (int)$_POST['cosmetologist_id'];
        $appointment_datetime = $_POST['appointment_datetime'];
        $client_id = $userId;
        $phone = $_POST['phone'] ?? $userPhone;
        $email = $_POST['email'] ?? $userEmail;
        
        if (!$service_id || !$cosmetologist_id || !$appointment_datetime) {
            echo json_encode(['success' => false, 'error' => 'Заповніть всі поля']);
            exit;
        }
        
        try {
            $stmt = $pdo->prepare("SELECT id FROM appointments WHERE cosmetologist_id = ? AND appointment_datetime = ? AND status NOT IN ('canceled', 'no_show')");
            $stmt->execute([$cosmetologist_id, $appointment_datetime]);
            
            if ($stmt->fetch()) {
                echo json_encode(['success' => false, 'error' => 'Цей час вже зайнятий']);
                exit;
            }
            
            $stmt = $pdo->prepare("SELECT price FROM services WHERE id = ?");
            $stmt->execute([$service_id]);
            $service = $stmt->fetch();
            $price = $service ? $service['price'] : 0;
            
            $stmt = $pdo->prepare("
                INSERT INTO appointments (client_id, cosmetologist_id, service_id, appointment_datetime, status, price, created_at) 
                VALUES (?, ?, ?, ?, 'pending', ?, NOW())
            ");
            $stmt->execute([$client_id, $cosmetologist_id, $service_id, $appointment_datetime, $price]);
            $appointment_id = $pdo->lastInsertId();
            
            $ticket_number = str_pad($appointment_id, 8, '0', STR_PAD_LEFT);
            
            echo json_encode([
                'success' => true,
                'message' => 'Ви успішно записані!',
                'appointment_id' => $appointment_id,
                'ticket_number' => $ticket_number
            ]);
            
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'error' => 'Помилка: ' . $e->getMessage()]);
        }
        exit;
    }
    
    echo json_encode(['success' => false, 'error' => 'Невідома дія']);
    exit;
}

// GET запит - отримуємо дані з БД
$masters = [];
$services = [];

try {
    $stmt = $pdo->query("
        SELECT id, email, experience_years, rating 
        FROM cosmetologists
    ");
    $masters = $stmt->fetchAll();
    
    foreach ($masters as &$m) {
        $m['name'] = !empty($m['email']) ? explode('@', $m['email'])[0] : 'Майстер #' . $m['id'];
        $m['name'] = ucfirst($m['name']);
        $m['rating'] = $m['rating'] ?? 5.0;
        $m['experience_years'] = $m['experience_years'] ?? 0;
    }
    
    $stmt = $pdo->query("
        SELECT id, name, duration_minutes, price 
        FROM services 
        WHERE is_active = 1
    ");
    $services = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $error_message = $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Онлайн-запис - Cosmology Beauty</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/main.min.css" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f9f5f0; }
        
        .top-bar { background: #2c2c2c; color: white; padding: 8px 0; text-align: center; font-size: 14px; }
        .header { background: white; box-shadow: 0 2px 15px rgba(0,0,0,0.08); padding: 15px 20px; }
        .nav-container { max-width: 1300px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; }
        .logo { font-size: 28px; font-weight: bold; color: #c7a17a; }
        .logo span { color: #2c2c2c; }
        .nav-menu { display: flex; list-style: none; gap: 25px; flex-wrap: wrap; }
        .nav-menu a { text-decoration: none; color: #2c2c2c; font-weight: 500; }
        .nav-menu a:hover { color: #c7a17a; }
        .btn-book { background: #c7a17a; color: white !important; padding: 10px 25px; border-radius: 30px; }
        .auth-buttons { display: flex; gap: 15px; align-items: center; }
        
        .container { max-width: 1400px; margin: 40px auto; padding: 0 20px; }
        .booking-header { text-align: center; margin-bottom: 30px; }
        .booking-header h1 { font-size: 42px; color: #2c2c2c; font-weight: 300; }
        .booking-header h1 span { color: #c7a17a; font-weight: 600; }
        
        .booking-layout {
            display: grid;
            grid-template-columns: 350px 1fr;
            gap: 30px;
        }
        
        @media (max-width: 992px) {
            .booking-layout { grid-template-columns: 1fr; }
        }
        
        .booking-card, .calendar-card {
            background: white;
            border-radius: 25px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-weight: 600; color: #2c2c2c; margin-bottom: 8px; }
        .form-group select, .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #f0e6dc;
            border-radius: 12px;
            font-size: 14px;
        }
        .form-group select:focus, .form-group input:focus {
            outline: none;
            border-color: #c7a17a;
        }
        
        .slots-container { margin-top: 20px; }
        .slots-title { font-weight: 600; color: #2c2c2c; margin-bottom: 15px; }
        .slots-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            max-height: 300px;
            overflow-y: auto;
        }
        .slot-btn {
            background: #f0e6dc;
            padding: 10px 20px;
            border-radius: 30px;
            cursor: pointer;
            border: none;
            font-size: 14px;
            transition: all 0.3s;
        }
        .slot-btn:hover { background: #c7a17a; color: white; }
        .slot-btn.selected { background: #c7a17a; color: white; }
        
        .btn-submit {
            background: #c7a17a;
            color: white;
            border: none;
            padding: 14px 30px;
            border-radius: 40px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            width: 100%;
            margin-top: 20px;
            transition: all 0.3s;
        }
        .btn-submit:hover:not(:disabled) { background: #a67c52; transform: scale(1.02); }
        .btn-submit:disabled { opacity: 0.5; cursor: not-allowed; }
        
        .selected-info {
            background: #f9f5f0;
            padding: 20px;
            border-radius: 15px;
            margin-top: 20px;
        }
        .selected-info h4 { color: #c7a17a; margin-bottom: 15px; }
        .selected-info p { margin: 8px 0; }
        
        .message {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1000;
            padding: 15px 20px;
            border-radius: 10px;
            animation: slideIn 0.3s ease;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }
        .message.success { background: #d4edda; color: #155724; border-left: 4px solid #28a745; }
        .message.error { background: #f8d7da; color: #721c24; border-left: 4px solid #dc3545; }
        
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        .footer { background: #1a1a1a; color: #999; padding: 40px 20px; margin-top: 40px; text-align: center; }
        
        /* Стилі для календаря */
        #calendar {
            height: 550px;
            width: 100%;
        }
        .fc-day-today {
            background-color: #f9f5f0 !important;
        }
        .fc-daygrid-day-number {
            font-size: 14px;
            color: #2c2c2c;
        }
        .fc .fc-button-primary {
            background-color: #c7a17a;
            border-color: #c7a17a;
        }
        .fc .fc-button-primary:hover {
            background-color: #a67c52;
            border-color: #a67c52;
        }
        .fc .fc-button-primary:disabled {
            background-color: #c7a17a;
        }
        
        .user-welcome {
            background: #f9f5f0;
            padding: 10px 20px;
            border-radius: 30px;
            font-size: 14px;
        }
        .user-welcome span {
            color: #c7a17a;
            font-weight: bold;
        }
        
        .spinner {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 2px solid #fff;
            border-radius: 50%;
            border-top-color: transparent;
            animation: spin 0.6s linear infinite;
        }
        @keyframes spin { to { transform: rotate(360deg); } }
    </style>
</head>
<body>
    <div class="top-bar">✨ Нова клієнтка отримує знижку 20% на перший візит ✨</div>
    
    <div class="header">
        <div class="nav-container">
            <div class="logo">Cosmology <span>Beauty</span></div>
            <ul class="nav-menu">
                <li><a href="index.php">Головна</a></li>
                <li><a href="about.php">Про нас</a></li>
                <li><a href="loyalty.php">Програма лояльності</a></li>
                <li><a href="doctors.php">Лікарі</a></li>
                <li><a href="booking.php" class="btn-book">Записатися</a></li>
            </ul>
            <div class="auth-buttons">
                <?php if ($isLoggedIn): ?>
                    <div class="user-welcome">
                        👋 Вітаємо, <span><?= htmlspecialchars(explode('@', $userEmail)[0]) ?></span>
                    </div>
                    <a href="client_cabinet.php">📋 Кабінет</a>
                    <a href="logout.php">🚪 Вихід</a>
                <?php else: ?>
                    <a href="login.php">🔑 Вхід</a>
                    <a href="register.php">📝 Реєстрація</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="container">
        <div class="booking-header">
            <h1>Запис до <span>косметолога</span></h1>
            <p>Оберіть послугу, майстра, зручну дату та час</p>
        </div>
        
        <?php if (!$isLoggedIn): ?>
            <div class="booking-card" style="max-width: 500px; margin: 0 auto;">
                <div class="auth-required" style="text-align: center; padding: 40px;">
                    <h2 style="color: #c7a17a; margin-bottom: 20px;">🔒 Для запису потрібна авторизація</h2>
                    <p>Щоб записатися на процедуру, будь ласка, увійдіть в акаунт або зареєструйтесь.</p>
                    <div style="display: flex; gap: 20px; justify-content: center; margin-top: 30px;">
                        <a href="login.php" style="padding: 12px 30px; border-radius: 40px; text-decoration: none; font-weight: bold; background: #c7a17a; color: white; border: 2px solid #c7a17a;">🔑 Увійти</a>
                        <a href="register.php" style="padding: 12px 30px; border-radius: 40px; text-decoration: none; font-weight: bold; background: transparent; color: #c7a17a; border: 2px solid #c7a17a;">📝 Зареєструватися</a>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="booking-layout">
                <div class="booking-card">
                    <div class="form-group">
                        <label>💆‍♀️ Послуга</label>
                        <select id="serviceSelect">
                            <option value="">-- Оберіть послугу --</option>
                            <?php foreach($services as $s): ?>
                                <option value="<?= $s['id'] ?>" data-price="<?= $s['price'] ?>" data-duration="<?= $s['duration_minutes'] ?>">
                                    <?= htmlspecialchars($s['name']) ?> — <?= number_format($s['price'], 0, ',', ' ') ?> грн (<?= $s['duration_minutes'] ?> хв)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>👩‍⚕️ Майстер</label>
                        <select id="masterSelect">
                            <option value="">-- Оберіть майстра --</option>
                            <?php foreach($masters as $m): ?>
                                <option value="<?= $m['id'] ?>" data-rating="<?= $m['rating'] ?>" data-experience="<?= $m['experience_years'] ?>">
                                    <?= htmlspecialchars($m['name']) ?> ⭐ <?= $m['rating'] ?> (<?= $m['experience_years'] ?> р.)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>📱 Телефон</label>
                        <input type="tel" id="phoneInput" value="<?= htmlspecialchars($userPhone) ?>" placeholder="+38 (XXX) XXX-XX-XX">
                    </div>
                    
                    <div class="form-group">
                        <label>📧 Email</label>
                        <input type="email" id="emailInput" value="<?= htmlspecialchars($userEmail) ?>" placeholder="your@email.com">
                    </div>
                    
                    <div class="slots-container" id="slotsContainer" style="display: none;">
                        <div class="slots-title">⏰ Доступний час на <span id="selectedDateLabel"></span></div>
                        <div id="slotsGrid" class="slots-grid"></div>
                    </div>
                    
                    <button class="btn-submit" id="submitBtn" disabled>📝 Підтвердити запис</button>
                    
                    <div class="selected-info">
                        <h4>📋 Ваш вибір</h4>
                        <p>💆‍♀️ Послуга: <span id="selectedService">—</span></p>
                        <p>👩‍⚕️ Майстер: <span id="selectedMaster">—</span></p>
                        <p>📅 Дата та час: <span id="selectedDateTime">—</span></p>
                        <p>💰 Вартість: <span id="selectedPrice">—</span></p>
                        <p>⏱️ Тривалість: <span id="selectedDuration">—</span></p>
                    </div>
                </div>
                
                <div class="calendar-card">
                    <div id="calendar"></div>
                </div>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="footer">
        <p>© 2026 Cosmology Beauty. Всі права захищено.</p>
        <p>м. Дніпро, вул. Хмельницького, 15 | Тел: (098) 123-45-67</p>
    </div>
    
    <?php if ($isLoggedIn): ?>
    <!-- jQuery та FullCalendar -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/index.global.min.js"></script>
    
    <script>
    $(document).ready(function() {
        let selectedDate = null;
        let selectedTime = null;
        let calendar = null;
        
        function showMessage(message, type) {
            $('.message').remove();
            let msg = $('<div class="message ' + type + '">' + message + '</div>');
            $('body').append(msg);
            setTimeout(function() { msg.fadeOut(300, function() { $(this).remove(); }); }, 5000);
        }
        
        function loadSlots(date) {
            let serviceId = $('#serviceSelect').val();
            let masterId = $('#masterSelect').val();
            
            if (!serviceId || !masterId || !date) {
                $('#slotsContainer').hide();
                return;
            }
            
            $('#selectedDateLabel').text(date);
            
            $.ajax({
                url: window.location.href,
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                data: {
                    action: 'get_slots',
                    cosmetologist_id: masterId,
                    service_id: serviceId,
                    date: date
                },
                dataType: 'json',
                success: function(response) {
                    if (response.slots !== undefined) {
                        if (response.slots.length === 0) {
                            $('#slotsGrid').html('<p style="color:#999; text-align:center; padding:20px;">❌ Немає вільних слотів на цей день</p>');
                        } else {
                            let html = '';
                            for (let i = 0; i < response.slots.length; i++) {
                                let slot = response.slots[i];
                                let selectedClass = (selectedTime === slot) ? 'selected' : '';
                                html += '<button class="slot-btn ' + selectedClass + '" data-time="' + slot + '">' + slot + '</button>';
                            }
                            $('#slotsGrid').html(html);
                            
                            $('.slot-btn').off('click').on('click', function() {
                                $('.slot-btn').removeClass('selected');
                                $(this).addClass('selected');
                                selectedTime = $(this).data('time');
                                updateSelectedInfo();
                                let phone = $('#phoneInput').val();
                                $('#submitBtn').prop('disabled', !phone);
                            });
                        }
                        $('#slotsContainer').slideDown();
                    }
                },
                error: function(xhr, status, error) {
                    console.log('Помилка:', error);
                    showMessage('Помилка завантаження слотів', 'error');
                }
            });
        }
        
        function updateSelectedInfo() {
            let service = $('#serviceSelect option:selected');
            let master = $('#masterSelect option:selected');
            
            $('#selectedService').text(service.text().split(' —')[0] || '—');
            $('#selectedMaster').text(master.text().split(' ⭐')[0] || '—');
            $('#selectedDateTime').text((selectedDate && selectedTime) ? selectedDate + ' ' + selectedTime : '—');
            $('#selectedPrice').text(service.data('price') ? Number(service.data('price')).toLocaleString() + ' грн' : '—');
            $('#selectedDuration').text(service.data('duration') ? service.data('duration') + ' хв' : '—');
        }
        
        function createBooking() {
            let serviceId = $('#serviceSelect').val();
            let masterId = $('#masterSelect').val();
            let phone = $('#phoneInput').val();
            let email = $('#emailInput').val();
            
            if (!selectedDate || !selectedTime) {
                showMessage('Оберіть дату та час', 'error');
                return;
            }
            
            if (!phone) {
                showMessage('Введіть номер телефону', 'error');
                return;
            }
            
            let datetime = selectedDate + ' ' + selectedTime + ':00';
            
            $('#submitBtn').prop('disabled', true).html('<span class="spinner"></span> Запис...');
            
            $.ajax({
                url: window.location.href,
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                data: {
                    action: 'create_booking',
                    service_id: serviceId,
                    cosmetologist_id: masterId,
                    appointment_datetime: datetime,
                    phone: phone,
                    email: email
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        showMessage('✅ ' + response.message + ' Номер талону: ' + response.ticket_number, 'success');
                        selectedTime = null;
                        $('#slotsContainer').hide();
                        $('#submitBtn').prop('disabled', true);
                        $('.slot-btn').removeClass('selected');
                        updateSelectedInfo();
                        if (calendar) calendar.refetchEvents();
                    } else {
                        showMessage(response.error, 'error');
                        $('#submitBtn').prop('disabled', false);
                    }
                    $('#submitBtn').html('📝 Підтвердити запис');
                },
                error: function() {
                    showMessage('Помилка при створенні запису', 'error');
                    $('#submitBtn').prop('disabled', false).html('📝 Підтвердити запис');
                }
            });
        }
        
        // Ініціалізація календаря
        let calendarEl = document.getElementById('calendar');
        calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            locale: 'uk',
            firstDay: 1,
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,dayGridWeek'
            },
            buttonText: {
                today: 'Сьогодні',
                month: 'Місяць',
                week: 'Тиждень'
            },
            dateClick: function(info) {
                let serviceId = $('#serviceSelect').val();
                let masterId = $('#masterSelect').val();
                
                if (!serviceId) {
                    showMessage('Спочатку оберіть послугу', 'error');
                    return;
                }
                if (!masterId) {
                    showMessage('Спочатку оберіть майстра', 'error');
                    return;
                }
                
                let date = new Date(info.dateStr + 'T12:00:00');
                let dayOfWeek = date.getDay();
                
                if (dayOfWeek === 0) {
                    showMessage('У неділю клініка не працює! Оберіть іншу дату.', 'error');
                    return;
                }
                
                selectedDate = info.dateStr;
                selectedTime = null;
                loadSlots(selectedDate);
                updateSelectedInfo();
                $('#submitBtn').prop('disabled', true);
                calendar.unselect();
                calendar.select(info.dateStr, info.dateStr);
            }
        });
        
        calendar.render();
        
        // Обробники подій
        $('#serviceSelect, #masterSelect').on('change', function() {
            selectedDate = null;
            selectedTime = null;
            $('#slotsContainer').hide();
            $('#submitBtn').prop('disabled', true);
            updateSelectedInfo();
            if (calendar) calendar.refetchEvents();
        });
        
        $('#phoneInput, #emailInput').on('input', function() {
            let phone = $('#phoneInput').val();
            let hasSelection = selectedDate && selectedTime;
            $('#submitBtn').prop('disabled', !(hasSelection && phone));
        });
        
        $('#submitBtn').on('click', createBooking);
    });
    </script>
    <?php endif; ?>
</body>
</html>