<?php
// switch_language.php
$lang = $_GET['lang'] ?? 'uk';
setcookie('lang', $lang, time() + 86400 * 30, '/');
header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? 'index.php'));
exit;