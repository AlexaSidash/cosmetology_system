<?php
session_start();
require_once 'includes/config.php';

// Отримуємо список майстрів з БД
$stmt = $pdo->query("
    SELECT 
        c.id,
        c.phone,
        c.email,
        c.experience_years, 
        c.rating, 
        c.description, 
        c.photo_url
    FROM cosmetologists c
");
$doctors = $stmt->fetchAll();

// Гарні фото для лікарів (замість емодзі)
$defaultPhotos = [
    'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=400&h=400&fit=crop',
    'https://images.pexels.com/photos/5214961/pexels-photo-5214961.jpeg?w=400&h=400&fit=crop',
    'https://i.pinimg.com/736x/6c/6e/d7/6c6ed7f4011b7f926b3f1505475aba16.jpg',
    'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=400&h=400&fit=crop',
    'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=400&h=400&fit=crop',
    'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop',
    'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=400&h=400&fit=crop',
    'https://randomuser.me/api/portraits/men/91.jpg'
];
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Наші лікарі - Cosmology Beauty</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #fafafa; }
        
        .top-bar { background: #2c2c2c; color: white; padding: 8px 0; text-align: center; font-size: 14px; }
        .header { background: white; box-shadow: 0 2px 15px rgba(0,0,0,0.08); position: sticky; top: 0; z-index: 1000; }
        .nav-container { max-width: 1300px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; padding: 15px 20px; flex-wrap: wrap; gap: 15px; }
        .logo { font-size: 28px; font-weight: bold; color: #c7a17a; }
        .logo span { color: #2c2c2c; }
        .nav-menu { display: flex; list-style: none; gap: 25px; flex-wrap: wrap; }
        .nav-menu a { text-decoration: none; color: #2c2c2c; font-weight: 500; }
        .nav-menu a:hover { color: #c7a17a; }
        .dropdown { position: relative; }
        .dropdown-content { display: none; position: absolute; background: white; min-width: 220px; box-shadow: 0 8px 16px rgba(0,0,0,0.1); border-radius: 8px; top: 100%; left: 0; z-index: 1; }
        .dropdown:hover .dropdown-content { display: block; }
        .dropdown-content a { display: block; padding: 12px 20px; color: #333; border-bottom: 1px solid #eee; }
        .dropdown-content a:hover { background: #f9f5f0; color: #c7a17a; }
        .btn-book { background: #c7a17a; color: white !important; padding: 10px 25px; border-radius: 30px; }
        .auth-buttons { display: flex; gap: 15px; align-items: center; }
        .auth-link { color: #2c2c2c; text-decoration: none; }
        
        .doctors-hero {
            background: linear-gradient(135deg, #f9f5f0 0%, #fff 100%);
            padding: 60px 20px;
            text-align: center;
        }
        .doctors-hero h1 { font-size: 48px; color: #2c2c2c; margin-bottom: 15px; }
        .doctors-hero p { color: #666; font-size: 18px; }
        
        .doctors-grid {
            max-width: 1300px;
            margin: 50px auto;
            padding: 0 20px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 40px;
        }
        
        .doctor-card {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            transition: transform 0.3s, box-shadow 0.3s;
            text-align: center;
        }
        
        .doctor-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 35px rgba(0,0,0,0.15);
        }
        
        .doctor-photo {
            width: 100%;
            height: 320px;
            overflow: hidden;
            position: relative;
            background: linear-gradient(135deg, #c7a17a40, #f9f5f0);
        }
        
        .doctor-photo img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s;
        }
        
        .doctor-card:hover .doctor-photo img {
            transform: scale(1.05);
        }
        
        .doctor-info {
            padding: 25px;
        }
        
        .doctor-info h3 {
            font-size: 24px;
            color: #2c2c2c;
            margin-bottom: 5px;
        }
        
        .doctor-specialty {
            color: #c7a17a;
            font-weight: 600;
            margin-bottom: 15px;
            font-size: 14px;
            letter-spacing: 1px;
        }
        
        .doctor-experience {
            color: #666;
            margin-bottom: 8px;
            font-size: 14px;
        }
        
        .doctor-rating {
            color: #ffc107;
            font-size: 18px;
            margin: 15px 0;
        }
        
        .doctor-description {
            color: #777;
            line-height: 1.6;
            margin: 15px 0;
            font-size: 14px;
        }
        
        .btn-doctor {
            background: #c7a17a;
            color: white;
            padding: 12px 35px;
            border-radius: 40px;
            text-decoration: none;
            display: inline-block;
            margin-top: 15px;
            transition: background 0.3s, transform 0.2s;
            font-weight: 600;
            letter-spacing: 1px;
        }
        
        .btn-doctor:hover {
            background: #a67c52;
            transform: scale(1.02);
        }
        
        .footer {
            background: #1a1a1a;
            color: #999;
            padding: 50px 20px 30px;
            margin-top: 60px;
        }
        .footer-content {
            max-width: 1300px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
        }
        .footer-column h4 { color: white; margin-bottom: 20px; }
        .footer-column a { color: #999; text-decoration: none; display: block; margin-bottom: 10px; }
        .footer-column a:hover { color: #c7a17a; }
        .footer-bottom {
            text-align: center;
            padding-top: 30px;
            margin-top: 30px;
            border-top: 1px solid #333;
        }
        
        @media (max-width: 768px) {
            .nav-container { flex-direction: column; }
            .nav-menu { justify-content: center; }
            .doctors-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="top-bar">
        ✨ Нова клієнтка отримує знижку 20% на перший візит ✨
    </div>
    
    <div class="header">
        <div class="nav-container">
            <div class="logo">
                Cosmology <span>Beauty</span>
            </div>
            <ul class="nav-menu">
                <li><a href="index.php">Головна</a></li>
                <li><a href="about.php">Про нас</a></li>
                <li class="dropdown">
                    <a href="#">Прайс ▼</a>
                    <div class="dropdown-content">
                        <a href="category.php?cat=injection">Ін'єкційна косметологія</a>
                        <a href="category.php?cat=apparatus">Апаратна косметологія</a>
                        <a href="category.php?cat=laser">Лазерна косметологія</a>
                        <a href="category.php?cat=epilation">Лазерна епіляція</a>
                        <a href="category.php?cat=intimate">Інтимна косметологія</a>
                        <a href="category.php?cat=care">Доглядові процедури</a>
                        <a href="category.php?cat=dermatology">Дерматологія</a>
                    </div>
                </li>
                <li><a href="loyalty.php">Програма лояльності</a></li>
                <li><a href="doctors.php">Лікарі</a></li>
                <li><a href="booking.php" class="btn-book">Записатися</a></li>
            </ul>
            <div class="auth-buttons">
                <?php if(isset($_SESSION['user_id'])): ?>
                    <a href="client_cabinet.php" class="auth-link">👤 <?= htmlspecialchars($_SESSION['user_name'] ?? 'Користувач') ?></a>
                    <a href="logout.php" class="auth-link">🚪 Вихід</a>
                <?php else: ?>
                    <a href="login.php" class="auth-link">🔑 Вхід</a>
                    <a href="register.php" class="auth-link">📝 Реєстрація</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="doctors-hero">
        <h1>Наші спеціалісти</h1>
        <p>Досвідчені лікарі, яким ви можете довірити свою красу</p>
    </div>
    
    <div class="doctors-grid">
        <?php if(count($doctors) > 0): ?>
            <?php 
            $index = 0;
            foreach($doctors as $doctor): 
                // Отримуємо фото (якщо є в БД - беремо звідти, якщо ні - гарне фото за замовчуванням)
                $photoUrl = $doctor['photo_url'];
                if (empty($photoUrl)) {
                    $photoUrl = $defaultPhotos[$index % count($defaultPhotos)];
                }
                
                // Ім'я з email
                $name = !empty($doctor['email']) ? explode('@', $doctor['email'])[0] : 'Майстер #' . $doctor['id'];
                $name = ucfirst(str_replace(['.', '_', '-'], ' ', $name));
                
                // Спеціалізація
                $specializations = ['Косметолог-дерматолог', 'Пластичний хірург', 'Косметолог-естетист', 'Дерматокосметолог', 'Лазерний терапевт'];
                $specialty = $specializations[$index % count($specializations)];
            ?>
            <div class="doctor-card">
                <div class="doctor-photo">
                    <img src="<?= htmlspecialchars($photoUrl) ?>" alt="<?= htmlspecialchars($name) ?>" loading="lazy">
                </div>
                <div class="doctor-info">
                    <h3><?= htmlspecialchars($name) ?></h3>
                    <div class="doctor-specialty"><?= $specialty ?></div>
                    <div class="doctor-experience">📅 Досвід: <?= (int)$doctor['experience_years'] ?> років</div>
                    <div class="doctor-rating">
                        <?php 
                        $rating = round((float)$doctor['rating'], 1);
                        $fullStars = floor($rating);
                        for($i = 1; $i <= 5; $i++):
                            if($i <= $fullStars):
                                echo "★";
                            else:
                                echo "☆";
                            endif;
                        endfor;
                        echo " " . $rating;
                        ?>
                    </div>
                    <div class="doctor-description">
                        <?= htmlspecialchars($doctor['description'] ?? 'Сертифікований фахівець, постійно підвищує кваліфікацію на міжнародних курсах.') ?>
                    </div>
                    <a href="booking.php" class="btn-doctor">Записатися →</a>
                </div>
            </div>
            <?php 
            $index++;
            endforeach; 
            ?>
        <?php else: ?>
            <div style="text-align: center; grid-column: 1/-1; padding: 50px;">
                <p>Інформація про лікарів оновлюється. Завітайте пізніше!</p>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="footer">
        <div class="footer-content">
            <div class="footer-column">
                <h4>Cosmology Beauty</h4>
                <p>Ваша краса - наша турбота. Професійна косметологія з використанням сучасних методик та преміальних засобів.</p>
            </div>
            <div class="footer-column">
                <h4>Контакти</h4>
                <p>📍 м. Дніпро, вул. Хрещатик, 15</p>
                <p>📞 (098) 123-45-67</p>
                <p>📞 (099) 123-45-67</p>
                <p>✉️ info@cosmology-beauty.com</p>
            </div>
            <div class="footer-column">
                <h4>Години роботи</h4>
                <p>Пн-Пт: 9:00 - 20:00</p>
                <p>Сб: 10:00 - 18:00</p>
                <p>Нд: Вихідний</p>
            </div>
            <div class="footer-column">
                <h4>Соціальні мережі</h4>
                <a href="#">📷 Instagram</a>
                <a href="#">📘 Facebook</a>
                <a href="#">📱 Telegram</a>
                <a href="#">🎥 TikTok</a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>© 2026 Cosmology Beauty. Всі права захищено.</p>
            <p>м. Дніпро, вул. Хрещатик, 15 | Тел: (098) 123-45-67</p>
        </div>
    </div>
</body>
</html>