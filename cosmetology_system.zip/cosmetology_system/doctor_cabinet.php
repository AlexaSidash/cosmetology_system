<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'includes/config.php';

// Перевірка авторизації
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'cosmetologist') {
    header("Location: doctor_login.php");
    exit();
}

$doctor_id = $_SESSION['doctor_id'] ?? 0;
$user_id = $_SESSION['user_id'];
$active_tab = $_GET['tab'] ?? 'dashboard';
$selected_patient_id = isset($_GET['patient_id']) ? (int)$_GET['patient_id'] : 0;

// Отримуємо інформацію про лікаря
$stmt = $pdo->prepare("SELECT u.*, c.id as doctor_id, c.experience_years, c.rating, c.description, c.commission_percent, c.bonus FROM users u JOIN cosmetologists c ON u.id = c.user_id WHERE u.id = ?");
$stmt->execute([$user_id]);
$doctor = $stmt->fetch();

// Статистика
$stmt = $pdo->prepare("SELECT COUNT(DISTINCT client_id) as total_patients, COUNT(*) as total_appointments, SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed, SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled, SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending, SUM(CASE WHEN DATE(appointment_datetime) = CURDATE() THEN 1 ELSE 0 END) as today, SUM(CASE WHEN MONTH(appointment_datetime) = MONTH(CURDATE()) THEN 1 ELSE 0 END) as this_month FROM appointments WHERE cosmetologist_id = ?");
$stmt->execute([$doctor_id]);
$stats = $stmt->fetch();

// Виручка за місяць
$stmt = $pdo->prepare("SELECT SUM(s.price) as monthly_revenue FROM appointments a JOIN services s ON a.service_id = s.id WHERE a.cosmetologist_id = ? AND a.status = 'completed' AND MONTH(a.appointment_datetime) = MONTH(CURDATE()) AND YEAR(a.appointment_datetime) = YEAR(CURDATE())");
$stmt->execute([$doctor_id]);
$monthly_revenue = $stmt->fetch()['monthly_revenue'] ?? 0;

// Дані для графіка
$chart_data = [];
for ($i = 11; $i >= 0; $i--) {
    $month = date('Y-m', strtotime("-$i months"));
    $month_name = date('M', strtotime("-$i months"));
    $stmt = $pdo->prepare("SELECT COUNT(*) as count, COALESCE(SUM(s.price), 0) as revenue FROM appointments a JOIN services s ON a.service_id = s.id WHERE a.cosmetologist_id = ? AND a.status = 'completed' AND DATE_FORMAT(a.appointment_datetime, '%Y-%m') = ?");
    $stmt->execute([$doctor_id, $month]);
    $data = $stmt->fetch();
    $chart_data[] = ['month' => $month_name, 'count' => (int)$data['count'], 'revenue' => (float)$data['revenue']];
}

// Сьогоднішні записи
$stmt = $pdo->prepare("SELECT a.*, u.full_name as client_name, u.phone as client_phone, u.email as client_email, s.name as service_name, s.price FROM appointments a JOIN users u ON a.client_id = u.id JOIN services s ON a.service_id = s.id WHERE a.cosmetologist_id = ? AND DATE(a.appointment_datetime) = CURDATE() AND a.status NOT IN ('cancelled') ORDER BY a.appointment_datetime ASC");
$stmt->execute([$doctor_id]);
$today_appointments = $stmt->fetchAll();

// Майбутні записи
$stmt = $pdo->prepare("SELECT a.*, u.full_name as client_name, u.phone as client_phone, u.email as client_email, s.name as service_name, s.price FROM appointments a JOIN users u ON a.client_id = u.id JOIN services s ON a.service_id = s.id WHERE a.cosmetologist_id = ? AND a.appointment_datetime > NOW() AND a.status = 'confirmed' ORDER BY a.appointment_datetime ASC LIMIT 20");
$stmt->execute([$doctor_id]);
$upcoming_appointments = $stmt->fetchAll();

// Список пацієнтів
$stmt = $pdo->prepare("SELECT DISTINCT u.id, u.full_name, u.phone, u.email, u.birth_date, COUNT(a.id) as visits_count, SUM(s.price) as total_spent, MAX(a.appointment_datetime) as last_visit, MIN(a.appointment_datetime) as first_visit FROM appointments a JOIN users u ON a.client_id = u.id JOIN services s ON a.service_id = s.id WHERE a.cosmetologist_id = ? AND a.status IN ('completed', 'confirmed') GROUP BY u.id ORDER BY last_visit DESC");
$stmt->execute([$doctor_id]);
$patients_list = $stmt->fetchAll();

// Отримуємо відгуки про лікаря
$stmt = $pdo->prepare("
    SELECT r.*, u.full_name as client_name, s.name as service_name, a.appointment_datetime
    FROM reviews r
    JOIN users u ON r.client_id = u.id
    LEFT JOIN appointments a ON r.appointment_id = a.id
    LEFT JOIN services s ON a.service_id = s.id
    WHERE r.doctor_id = ?
    ORDER BY r.created_at DESC
");
$stmt->execute([$doctor_id]);
$doctor_reviews = $stmt->fetchAll();
// Статистика відгуків
$stmt = $pdo->prepare("
    SELECT 
        COUNT(*) as total_reviews,
        AVG(rating) as avg_rating,
        COUNT(*) as approved_reviews,
        0 as pending_reviews
    FROM reviews
    WHERE doctor_id = ?
");
$stmt->execute([$doctor_id]);
$review_stats = $stmt->fetch();

// Нотатки пацієнта
$patient_notes = [];
$patient_photos = [];
$treatment_plans = [];
$procedure_products = [];

if ($selected_patient_id > 0) {
    // Інформація про пацієнта
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND role = 'client'");
    $stmt->execute([$selected_patient_id]);
    $selected_patient = $stmt->fetch();
    
    // Історія візитів
    $stmt = $pdo->prepare("SELECT a.*, s.name as service_name, s.price FROM appointments a JOIN services s ON a.service_id = s.id WHERE a.cosmetologist_id = ? AND a.client_id = ? ORDER BY a.appointment_datetime DESC");
    $stmt->execute([$doctor_id, $selected_patient_id]);
    $patient_history = $stmt->fetchAll();
    
    // Нотатки
    $stmt = $pdo->prepare("SELECT * FROM patient_notes WHERE patient_id = ? AND doctor_id = ? ORDER BY created_at DESC");
    $stmt->execute([$selected_patient_id, $doctor_id]);
    $patient_notes = $stmt->fetchAll();
    
    // Фото
    $stmt = $pdo->prepare("SELECT * FROM patient_photos WHERE patient_id = ? AND doctor_id = ? ORDER BY created_at DESC");
    $stmt->execute([$selected_patient_id, $doctor_id]);
    $patient_photos = $stmt->fetchAll();
    
    // План лікування
    $stmt = $pdo->prepare("SELECT tp.*, s.name as service_name, s.price FROM treatment_plans tp LEFT JOIN services s ON tp.service_id = s.id WHERE tp.patient_id = ? AND tp.doctor_id = ? ORDER BY tp.planned_date ASC");
    $stmt->execute([$selected_patient_id, $doctor_id]);
    $treatment_plans = $stmt->fetchAll();
}

// Препарати для процедур
$stmt = $pdo->prepare("SELECT pp.*, s.name as service_name FROM procedure_products pp JOIN services s ON pp.service_id = s.id ORDER BY s.name");
$stmt->execute();
$procedure_products = $stmt->fetchAll();

// Обробка POST запитів
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Додавання нотатки
    if (isset($_POST['add_note'])) {
        $note = $_POST['note'];
        $stmt = $pdo->prepare("INSERT INTO patient_notes (patient_id, doctor_id, note) VALUES (?, ?, ?)");
        $stmt->execute([$selected_patient_id, $doctor_id, $note]);
        header("Location: doctor_dashboard.php?tab=patients&patient_id=$selected_patient_id");
        exit();
    }
    
    // Додавання фото
    if (isset($_POST['add_photo']) && isset($_FILES['photo'])) {
        $photo_type = $_POST['photo_type'];
        $description = $_POST['description'];
        $target_dir = "uploads/patient_photos/";
        if (!file_exists($target_dir)) mkdir($target_dir, 0777, true);
        $file_name = time() . "_" . basename($_FILES["photo"]["name"]);
        $target_file = $target_dir . $file_name;
        if (move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file)) {
            $stmt = $pdo->prepare("INSERT INTO patient_photos (patient_id, doctor_id, photo_url, photo_type, description) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$selected_patient_id, $doctor_id, $target_file, $photo_type, $description]);
        }
        header("Location: doctor_dashboard.php?tab=patients&patient_id=$selected_patient_id");
        exit();
    }
    
    // Додавання плану лікування
    if (isset($_POST['add_treatment'])) {
        $service_id = $_POST['service_id'];
        $planned_date = $_POST['planned_date'];
        $notes = $_POST['notes'];
        $stmt = $pdo->prepare("INSERT INTO treatment_plans (patient_id, doctor_id, service_id, planned_date, notes) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$selected_patient_id, $doctor_id, $service_id, $planned_date, $notes]);
        header("Location: doctor_dashboard.php?tab=patients&patient_id=$selected_patient_id");
        exit();
    }
    
    // Оновлення статусу плану
    if (isset($_POST['update_status'])) {
        $plan_id = $_POST['plan_id'];
        $status = $_POST['status'];
        $stmt = $pdo->prepare("UPDATE treatment_plans SET status = ? WHERE id = ?");
        $stmt->execute([$status, $plan_id]);
        header("Location: doctor_dashboard.php?tab=patients&patient_id=$selected_patient_id");
        exit();
    }
    
    // Додавання шаблону
    if (isset($_POST['add_template'])) {
        $template_name = $_POST['template_name'];
        $template_text = $_POST['template_text'];
        $stmt = $pdo->prepare("INSERT INTO note_templates (doctor_id, template_name, template_text) VALUES (?, ?, ?)");
        $stmt->execute([$doctor_id, $template_name, $template_text]);
        header("Location: doctor_dashboard.php?tab=templates");
        exit();
    }
    
    // Відповідь на відгук
    if (isset($_POST['respond_to_review'])) {
        $review_id = $_POST['review_id'];
        $response = $_POST['doctor_response'];
        $stmt = $pdo->prepare("UPDATE reviews SET doctor_response = ?, response_date = NOW() WHERE id = ? AND doctor_id = ?");
        $stmt->execute([$response, $review_id, $doctor_id]);
        header("Location: doctor_dashboard.php?tab=reviews");
        exit();
    }
}

// Шаблони
$stmt = $pdo->prepare("SELECT * FROM note_templates WHERE doctor_id = ? ORDER BY template_name");
$stmt->execute([$doctor_id]);
$templates = $stmt->fetchAll();

// Топ послуг
$stmt = $pdo->prepare("SELECT s.name, COUNT(*) as count, SUM(s.price) as total FROM appointments a JOIN services s ON a.service_id = s.id WHERE a.cosmetologist_id = ? AND a.status = 'completed' GROUP BY s.id ORDER BY count DESC LIMIT 5");
$stmt->execute([$doctor_id]);
$top_services = $stmt->fetchAll();

// Досягнення
$completed_count = $stats['completed'] ?? 0;
$total_patients = $stats['total_patients'] ?? 0;
$rating = $doctor['rating'] ?? 0;
$achievements = [
    ['name' => '🎯 Перший прийом', 'earned' => $completed_count >= 1, 'icon' => '🎯'],
    ['name' => '🏅 10 прийомів', 'earned' => $completed_count >= 10, 'icon' => '🏅'],
    ['name' => '🎖️ 50 прийомів', 'earned' => $completed_count >= 50, 'icon' => '🎖️'],
    ['name' => '🏆 100 прийомів', 'earned' => $completed_count >= 100, 'icon' => '🏆'],
    ['name' => '👤 Перший пацієнт', 'earned' => $total_patients >= 1, 'icon' => '👤'],
    ['name' => '👥 10 пацієнтів', 'earned' => $total_patients >= 10, 'icon' => '👥'],
    ['name' => '👪 20 пацієнтів', 'earned' => $total_patients >= 20, 'icon' => '👪'],
    ['name' => '⭐ Рейтинг 4.5+', 'earned' => $rating >= 4.5, 'icon' => '⭐'],
];

// Отримуємо всі послуги для плану
$services_list = $pdo->query("SELECT id, name, price FROM services WHERE is_active = 1")->fetchAll();
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Кабінет лікаря | Cosmology Beauty</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f0f4f8; }
        
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, #1a5f7a 0%, #0d3b4f 100%);
            color: white;
            position: fixed;
            height: 100%;
            padding: 25px 0;
            overflow-y: auto;
            z-index: 100;
        }
        .sidebar-header { text-align: center; padding: 0 20px 20px; border-bottom: 1px solid rgba(255,255,255,0.1); margin-bottom: 20px; }
        .sidebar-header h3 { font-size: 22px; color: #ffc107; margin-bottom: 5px; }
        .sidebar-header p { font-size: 12px; opacity: 0.7; }
        
        .sidebar-nav { padding: 0 15px; }
        .sidebar-nav a {
            color: #ddd; text-decoration: none; display: flex; align-items: center; gap: 12px;
            padding: 12px 15px; margin: 5px 0; border-radius: 12px; transition: all 0.3s;
        }
        .sidebar-nav a:hover, .sidebar-nav a.active { background: rgba(255,255,255,0.15); color: white; }
        .sidebar-nav .icon { font-size: 20px; width: 30px; }
        .sidebar-nav .badge { background: #ffc107; color: #333; border-radius: 20px; padding: 2px 8px; font-size: 10px; margin-left: auto; }
        
        .content { margin-left: 280px; padding: 30px; }
        
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: white; padding: 25px; border-radius: 20px; text-align: center; box-shadow: 0 2px 10px rgba(0,0,0,0.05); transition: transform 0.2s; cursor: pointer; }
        .stat-card:hover { transform: translateY(-3px); background: #f0f4f8; }
        .stat-number { font-size: 32px; font-weight: bold; color: #1a5f7a; }
        .stat-label { color: #666; margin-top: 8px; font-size: 13px; }
        
        .chart-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 30px; }
        .chart-card { background: white; border-radius: 20px; padding: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .chart-card h3 { color: #1a5f7a; margin-bottom: 15px; font-size: 16px; }
        canvas { max-height: 300px; width: 100% !important; }
        
        .section-card { background: white; border-radius: 20px; padding: 25px; margin-bottom: 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .section-card h3 { color: #1a5f7a; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; }
        
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #e0e0e0; }
        th { background: #1a5f7a20; color: #1a5f7a; font-weight: 600; }
        
        .patient-card { display: flex; justify-content: space-between; align-items: center; padding: 15px; border-bottom: 1px solid #e0e0e0; cursor: pointer; transition: background 0.3s; }
        .patient-card:hover { background: #f0f4f8; }
        
        .btn-complete, .btn-primary, .btn-danger, .btn-warning, .btn-response {
            color: white; border: none; padding: 8px 16px; border-radius: 8px; cursor: pointer; font-size: 13px; text-decoration: none; display: inline-block;
        }
        .btn-complete { background: #28a745; }
        .btn-primary { background: #1a5f7a; }
        .btn-danger { background: #dc3545; }
        .btn-warning { background: #ffc107; color: #333; }
        .btn-response { background: #c7a17a; }
        
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        
        .achievements-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 15px; }
        .achievement { background: #f9f5f0; padding: 15px; border-radius: 15px; text-align: center; font-size: 14px; }
        .achievement.earned { background: #d4edda; color: #155724; border-left: 3px solid #28a745; }
        .achievement:not(.earned) { opacity: 0.5; }
        
        .photo-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 15px; margin-top: 15px; }
        .photo-item { background: #f9f5f0; border-radius: 15px; padding: 10px; text-align: center; }
        .photo-item img { width: 100%; height: 120px; object-fit: cover; border-radius: 10px; cursor: pointer; }
        
        .note-item { background: #f9f5f0; padding: 12px; border-radius: 10px; margin-bottom: 10px; border-left: 3px solid #1a5f7a; }
        .note-date { font-size: 11px; color: #999; margin-bottom: 5px; }
        
        .treatment-item { display: flex; justify-content: space-between; align-items: center; padding: 12px; border-bottom: 1px solid #e0e0e0; cursor: move; }
        .treatment-item.completed { opacity: 0.6; text-decoration: line-through; }
        
        /* Стилі для відгуків */
        .review-item {
            border-bottom: 1px solid #e0e0e0;
            padding: 20px 0;
        }
        .review-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            margin-bottom: 15px;
        }
        .review-rating {
            color: #ffc107;
            font-size: 18px;
        }
        .review-date {
            color: #999;
            font-size: 12px;
        }
        .review-comment {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 10px;
            margin: 10px 0;
            color: #555;
            line-height: 1.5;
        }
        .review-status {
            padding: 3px 10px;
            border-radius: 12px;
            font-size: 11px;
            display: inline-block;
        }
        .status-approved {
            background: #d4edda;
            color: #155724;
        }
        .status-pending {
            background: #fff3cd;
            color: #856404;
        }
        .doctor-response-box {
            background: #fef3e8;
            padding: 12px;
            border-radius: 10px;
            margin-top: 10px;
            border-left: 3px solid #c7a17a;
        }
        .response-form {
            margin-top: 10px;
            display: none;
        }
        .response-form textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 8px;
            margin: 10px 0;
            font-family: inherit;
        }
        
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); justify-content: center; align-items: center; z-index: 1000; }
        .modal-content { background: white; border-radius: 20px; padding: 30px; width: 500px; max-width: 90%; max-height: 80%; overflow-y: auto; }
        
        .product-tooltip { position: relative; cursor: help; border-bottom: 1px dashed #1a5f7a; }
        .product-tooltip .tooltip-text { visibility: hidden; background: #1a5f7a; color: white; text-align: center; padding: 8px 12px; border-radius: 8px; position: absolute; z-index: 1; bottom: 125%; left: 50%; transform: translateX(-50%); width: 250px; font-size: 12px; opacity: 0; transition: opacity 0.3s; }
        .product-tooltip:hover .tooltip-text { visibility: visible; opacity: 1; }
        
        @media (max-width: 900px) {
            .sidebar { width: 80px; }
            .sidebar-nav a span:not(.icon) { display: none; }
            .content { margin-left: 80px; }
            .chart-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
<div class="sidebar">
    <div class="sidebar-header"><h3>👩‍⚕️ Cosmology</h3><p>Кабінет лікаря</p></div>
    <div class="sidebar-nav">
        <a href="?tab=dashboard" class="<?= $active_tab == 'dashboard' ? 'active' : '' ?>"><span class="icon">📊</span><span>Головна</span></a>
        <a href="?tab=today" class="<?= $active_tab == 'today' ? 'active' : '' ?>"><span class="icon">📅</span><span>Сьогодні</span><?php if(count($today_appointments) > 0): ?><span class="badge"><?= count($today_appointments) ?></span><?php endif; ?></a>
        <a href="?tab=upcoming" class="<?= $active_tab == 'upcoming' ? 'active' : '' ?>"><span class="icon">⏳</span><span>Майбутні записи</span></a>
        <a href="?tab=patients" class="<?= $active_tab == 'patients' ? 'active' : '' ?>"><span class="icon">👥</span><span>Мої пацієнти</span><span class="badge"><?= count($patients_list) ?></span></a>
        <a href="?tab=reviews" class="<?= $active_tab == 'reviews' ? 'active' : '' ?>"><span class="icon">⭐</span><span>Відгуки</span><span class="badge"><?= $review_stats['pending_reviews'] ?? 0 ?></span></a>
        <a href="?tab=templates" class="<?= $active_tab == 'templates' ? 'active' : '' ?>"><span class="icon">📝</span><span>Шаблони нотаток</span></a>
        <a href="?tab=products" class="<?= $active_tab == 'products' ? 'active' : '' ?>"><span class="icon">💊</span><span>Препарати</span></a>
        <a href="?tab=analytics" class="<?= $active_tab == 'analytics' ? 'active' : '' ?>"><span class="icon">📈</span><span>Аналітика</span></a>
        <a href="?tab=finance" class="<?= $active_tab == 'finance' ? 'active' : '' ?>"><span class="icon">💰</span><span>Фінанси</span></a>
        <a href="?tab=top_services" class="<?= $active_tab == 'top_services' ? 'active' : '' ?>"><span class="icon">💆</span><span>Популярні послуги</span></a>
        <a href="?tab=achievements" class="<?= $active_tab == 'achievements' ? 'active' : '' ?>"><span class="icon">🏆</span><span>Досягнення</span></a>
        <a href="logout.php"><span class="icon">🚪</span><span>Вихід</span></a>
    </div>
</div>

<div class="content">
    <!-- ГОЛОВНА ВКЛАДКА -->
    <div id="dashboardTab" class="tab-content <?= $active_tab == 'dashboard' ? 'active' : '' ?>">
        <h1 style="margin-bottom: 10px;">📊 Головна панель</h1>
        <p style="margin-bottom: 25px;">Вітаємо, д-р <?= htmlspecialchars($doctor['full_name']) ?>!</p>
        <div class="stats-grid">
            <div class="stat-card" onclick="window.location.href='?tab=patients'"><div class="stat-number"><?= $stats['total_patients'] ?? 0 ?></div><div class="stat-label">👥 Мої пацієнти</div></div>
            <div class="stat-card" onclick="window.location.href='?tab=today'"><div class="stat-number"><?= $stats['today'] ?? 0 ?></div><div class="stat-label">📅 Сьогодні записів</div></div>
            <div class="stat-card" onclick="window.location.href='?tab=analytics'"><div class="stat-number"><?= $stats['completed'] ?? 0 ?></div><div class="stat-label">✅ Виконано процедур</div></div>
            <div class="stat-card" onclick="window.location.href='?tab=analytics'"><div class="stat-number">⭐ <?= number_format($doctor['rating'] ?? 0, 1) ?></div><div class="stat-label">Мій рейтинг</div></div>
            <div class="stat-card" onclick="window.location.href='?tab=analytics'"><div class="stat-number">📊 <?= $stats['this_month'] ?? 0 ?></div><div class="stat-label">Прийомів за місяць</div></div>
            <div class="stat-card" onclick="window.location.href='?tab=finance'"><div class="stat-number">💰 <?= number_format($monthly_revenue, 0) ?> ₴</div><div class="stat-label">Виручка за місяць</div></div>
        </div>
        <div class="chart-grid">
            <div class="chart-card"><h3>📈 Динаміка прийомів</h3><canvas id="appointmentsChart"></canvas></div>
            <div class="chart-card"><h3>💰 Динаміка виручки</h3><canvas id="revenueChart"></canvas></div>
        </div>
        <div class="section-card">
            <h3>📋 Сьогоднішні записи (<?= date('d.m.Y') ?>)</h3>
            <?php if(count($today_appointments) > 0): ?>
                </table><thead><tr><th>Час</th><th>Пацієнт</th><th>Послуга</th><th>Ціна</th><th>Дія</th></tr></thead>
                <tbody><?php foreach($today_appointments as $app): ?>
                    <tr>
                        <td><?= date('H:i', strtotime($app['appointment_datetime'])) ?></td>
                        <td><a href="?tab=patients&patient_id=<?= $app['client_id'] ?>"><?= htmlspecialchars($app['client_name']) ?></a></td>
                        <td><?= htmlspecialchars($app['service_name']) ?></td>
                        <td><?= number_format($app['price'], 0) ?> ₴</span>
                        <td><button class="btn-complete" onclick="completeAppointment(<?= $app['id'] ?>)">✅ Виконано</button></td>
                    </tr>
                <?php endforeach; ?></tbody></table>
            <?php else: ?><p>✅ Сьогодні записів немає</p><?php endif; ?>
        </div>
    </div>
    
    <!-- СЬОГОДНІ -->
    <div id="todayTab" class="tab-content <?= $active_tab == 'today' ? 'active' : '' ?>">
        <div class="section-card"><h3>📋 Записи на сьогодні</h3>
            <?php if(count($today_appointments) > 0): ?>
                <table><thead><tr><th>Час</th><th>Пацієнт</th><th>Телефон</th><th>Послуга</th><th>Ціна</th><th>Дія</th></tr></thead>
                <tbody><?php foreach($today_appointments as $app): ?>
                    <tr>
                        <td><?= date('H:i', strtotime($app['appointment_datetime'])) ?></td>
                        <td><a href="?tab=patients&patient_id=<?= $app['client_id'] ?>"><?= htmlspecialchars($app['client_name']) ?></a></td>
                        <td><?= htmlspecialchars($app['client_phone']) ?></td>
                        <td><?= htmlspecialchars($app['service_name']) ?></td>
                        <td><?= number_format($app['price'], 0) ?> ₴</span>
                        <td><button class="btn-complete" onclick="completeAppointment(<?= $app['id'] ?>)">✅ Виконано</button></td>
                    </tr>
                <?php endforeach; ?></tbody></table>
            <?php else: ?><p>Сьогодні записів немає</p><?php endif; ?>
        </div>
    </div>
    
    <!-- МАЙБУТНІ ЗАПИСИ -->
    <div id="upcomingTab" class="tab-content <?= $active_tab == 'upcoming' ? 'active' : '' ?>">
        <div class="section-card">
            <h3>📅 Найближчі записи</h3>
            <?php if(count($upcoming_appointments) > 0): ?>
                <table>
                    <thead><tr><th>Дата та час</th><th>Пацієнт</th><th>Телефон</th><th>Послуга</th><th>Ціна</th></tr></thead>
                    <tbody>
                        <?php foreach($upcoming_appointments as $app): ?>
                        <tr>
                            <td><?= date('d.m.Y H:i', strtotime($app['appointment_datetime'])) ?></td>
                            <td><a href="?tab=patients&patient_id=<?= $app['client_id'] ?>"><?= htmlspecialchars($app['client_name']) ?></a></td>
                            <td><?= htmlspecialchars($app['client_phone']) ?></td>
                            <td><?= htmlspecialchars($app['service_name']) ?></td>
                            <td><?= number_format($app['price'], 0) ?> ₴</span>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>Найближчих записів немає</p>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- ВІДГУКИ ПРО ЛІКАРЯ -->
    <div id="reviewsTab" class="tab-content <?= $active_tab == 'reviews' ? 'active' : '' ?>">
        <div class="section-card">
                       <h3>⭐ Відгуки про мене</h3>
            
            <!-- Статистика відгуків -->
            <div class="stats-grid" style="margin-bottom: 20px;">
                <div class="stat-card">
                    <div class="stat-number"><?= number_format($review_stats['avg_rating'] ?? 0, 1) ?></div>
                    <div class="stat-label">⭐ Середній рейтинг</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?= $review_stats['total_reviews'] ?? 0 ?></div>
                    <div class="stat-label">📝 Всього відгуків</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?= $review_stats['approved_reviews'] ?? 0 ?></div>
                    <div class="stat-label">✅ Опубліковано</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?= $review_stats['pending_reviews'] ?? 0 ?></div>
                    <div class="stat-label">⏳ На модерації</div>
                </div>
            </div>
            
            <?php if(count($doctor_reviews) > 0): ?>
                <?php foreach($doctor_reviews as $review): ?>
                <div class="review-item">
                    <div class="review-header">
                        <div>
                            <strong><?= htmlspecialchars($review['client_name']) ?></strong>
                            <?php if($review['service_name']): ?>
                                <div style="font-size: 12px; color: #888;">Послуга: <?= htmlspecialchars($review['service_name']) ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="review-rating">
                            <?php for($i = 1; $i <= 5; $i++): ?>
                                <?= $i <= $review['rating'] ? '★' : '☆' ?>
                            <?php endfor; ?>
                        </div>
                        <div>
                          <span class="review-status status-approved">
    ✅ Опубліковано
</span>
                            <div class="review-date"><?= date('d.m.Y H:i', strtotime($review['created_at'])) ?></div>
                        </div>
                    </div>
                    
                    <div class="review-comment">
                        <?= nl2br(htmlspecialchars($review['comment'])) ?>
                    </div>
                    
                    <?php if(!empty($review['doctor_response'])): ?>
                        <div class="doctor-response-box">
                            <strong>💬 Ваша відповідь:</strong><br>
                            <?= nl2br(htmlspecialchars($review['doctor_response'])) ?>
                            <div style="font-size: 12px; color: #888; margin-top: 5px;">
                                <?= date('d.m.Y', strtotime($review['response_date'])) ?>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="response-form" id="responseForm_<?= $review['id'] ?>">
                            <form method="POST">
                                <input type="hidden" name="review_id" value="<?= $review['id'] ?>">
                                <textarea name="doctor_response" rows="3" placeholder="Ваша відповідь на відгук..." required></textarea>
                                <button type="submit" name="respond_to_review" class="btn-response">📤 Надіслати відповідь</button>
                                <button type="button" class="btn-complete" onclick="hideResponseForm(<?= $review['id'] ?>)">Скасувати</button>
                            </form>
                        </div>
                        <button class="btn-response" onclick="showResponseForm(<?= $review['id'] ?>)">💬 Відповісти на відгук</button>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Ще немає відгуків. Вони з'являться тут, коли клієнти залишать свої враження.</p>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- ПАЦІЄНТИ З ПОВНОЮ КАРТКОЮ -->
    <div id="patientsTab" class="tab-content <?= $active_tab == 'patients' ? 'active' : '' ?>">
        <?php if($selected_patient_id > 0 && isset($selected_patient) && $selected_patient): ?>
        <!-- ДЕТАЛЬНА КАРТКА ПАЦІЄНТА -->
        <div class="section-card">
            <h3>
                👤 <?= htmlspecialchars($selected_patient['full_name']) ?>
                <div>
                    <button class="btn-warning" onclick="exportToPDF()">📄 Експорт в PDF</button>
                    <a href="?tab=patients" class="btn-primary" style="padding: 8px 16px; text-decoration:none;">← Назад до списку</a>
                </div>
            </h3>
            <div class="stats-grid" style="margin-bottom: 20px;">
                <div class="stat-card">
                    <div class="stat-number" style="font-size: 20px;">📞 <?= htmlspecialchars($selected_patient['phone']) ?></div>
                    <div class="stat-label" style="font-size: 11px;">Телефон</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number" style="font-size: 16px;">📧 <?= htmlspecialchars($selected_patient['email'] ?: '-') ?></div>
                    <div class="stat-label" style="font-size: 11px;">Email</div>
                </div>
                <div class="stat-card"><div class="stat-number">📅 <?= $patient_history ? count($patient_history) : 0 ?></div><div class="stat-label">Всього візитів</div></div>
                <div class="stat-card"><div class="stat-number">💰 <?= number_format(array_sum(array_column($patient_history, 'price')), 0) ?> ₴</div><div class="stat-label">Загальна сума</div></div>
            </div>
            
            <!-- Вкладки всередині картки пацієнта -->
            <div style="display: flex; gap: 10px; margin-bottom: 20px; flex-wrap: wrap; border-bottom: 1px solid #e0e0e0; padding-bottom: 10px;">
                <button class="btn-primary" onclick="showPatientTab('history')">📋 Історія</button>
                <button class="btn-primary" onclick="showPatientTab('notes')">📝 Нотатки</button>
                <button class="btn-primary" onclick="showPatientTab('photos')">📸 Фотопротокол</button>
                <button class="btn-primary" onclick="showPatientTab('treatment')">💊 План лікування</button>
            </div>
            
            <!-- ІСТОРІЯ ВІЗИТІВ -->
            <div id="historyTab" class="patient-subtab">
                <h4 style="color:#1a5f7a;">📋 Історія візитів</h4>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr><th>Дата</th><th>Послуга</th><th>Ціна</th><th>Статус</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach($patient_history as $visit): ?>
                            <tr>
                                <td><?= date('d.m.Y H:i', strtotime($visit['appointment_datetime'])) ?></td>
                                <td><?= htmlspecialchars($visit['service_name']) ?>
                                    <?php 
                                    $stmt = $pdo->prepare("SELECT product_name, quantity_needed FROM procedure_products WHERE service_id = ?");
                                    $stmt->execute([$visit['service_id']]);
                                    $products = $stmt->fetchAll();
                                    if($products): ?>
                                    <div class="product-tooltip" style="display:inline-block; margin-left:8px;">
                                        <span class="btn-warning" style="padding:2px 6px; font-size:10px;">💊</span>
                                        <div class="tooltip-text">
                                            <strong>Необхідні препарати:</strong><br>
                                            <?php foreach($products as $p): ?>
                                            • <?= htmlspecialchars($p['product_name']) ?> - <?= htmlspecialchars($p['quantity_needed']) ?><br>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </td>
                                <td><?= number_format($visit['price'], 0) ?> ₴</span>
                                <td><?= $visit['status'] ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- НОТАТКИ ПРО ПАЦІЄНТА -->
            <div id="notesTab" class="patient-subtab" style="display:none;">
                <h4 style="color:#1a5f7a;">📝 Нотатки про пацієнта</h4>
                
                <form method="POST" style="margin-bottom: 20px;">
                    <textarea name="note" class="form-control" rows="3" placeholder="Введіть нотатку після прийому..." style="width:100%; padding:10px; border-radius:10px; border:1px solid #ddd; margin-bottom:10px;"></textarea>
                    <div style="display:flex; gap:10px;">
                        <select id="templateSelect" class="form-control" style="flex:1;" onchange="applyTemplate()">
                            <option value="">📋 Використати шаблон...</option>
                            <?php foreach($templates as $template): ?>
                                <option value="<?= htmlspecialchars($template['template_text']) ?>"><?= htmlspecialchars($template['template_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit" name="add_note" class="btn-complete">💾 Зберегти нотатку</button>
                    </div>
                </form>
                
                <?php if(count($patient_notes) > 0): ?>
                    <?php foreach($patient_notes as $note): ?>
                    <div class="note-item">
                        <div class="note-date">📅 <?= date('d.m.Y H:i', strtotime($note['created_at'])) ?></div>
                        <div><?= nl2br(htmlspecialchars($note['note'])) ?></div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>Немає нотаток. Додайте першу нотатку після прийому.</p>
                <?php endif; ?>
            </div>
            
            <!-- ФОТОПРОТОКОЛ -->
            <div id="photosTab" class="patient-subtab" style="display:none;">
                <h4 style="color:#1a5f7a;">📸 Фотопротокол</h4>
                
                <form method="POST" enctype="multipart/form-data" style="background:#f9f5f0; padding:20px; border-radius:15px; margin-bottom:20px;">
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:15px;">
                        <div>
                            <label>Фото:</label>
                            <input type="file" name="photo" class="form-control" accept="image/*" required>
                        </div>
                        <div>
                            <label>Тип фото:</label>
                            <select name="photo_type" class="form-control">
                                <option value="before">ДО процедури</option>
                                <option value="after">ПІСЛЯ процедури</option>
                                <option value="other">Інше</option>
                            </select>
                        </div>
                        <div style="grid-column:span 2;">
                            <label>Опис:</label>
                            <input type="text" name="description" class="form-control" placeholder="Наприклад: Чистка обличчя, до/після">
                        </div>
                    </div>
                    <button type="submit" name="add_photo" class="btn-complete" style="margin-top:15px;">📤 Завантажити фото</button>
                </form>
                
                <div class="photo-grid">
                    <?php if(count($patient_photos) > 0): ?>
                        <?php foreach($patient_photos as $photo): ?>
                        <div class="photo-item">
                            <img src="<?= htmlspecialchars($photo['photo_url']) ?>" alt="Фото" onclick="openPhotoModal('<?= $photo['photo_url'] ?>')">
                            <div><span class="badge" style="background:#1a5f7a; color:white;"><?= $photo['photo_type'] == 'before' ? 'ДО' : ($photo['photo_type'] == 'after' ? 'ПІСЛЯ' : 'ІНШЕ') ?></span></div>
                            <small><?= htmlspecialchars($photo['description']) ?></small>
                            <div><small><?= date('d.m.Y', strtotime($photo['created_at'])) ?></small></div>
                        </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p>Немає фото. Завантажте перше фото пацієнта.</p>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- ПЛАН ЛІКУВАННЯ -->
            <div id="treatmentTab" class="patient-subtab" style="display:none;">
                <h4 style="color:#1a5f7a;">💊 План лікування</h4>
                
                <form method="POST" style="background:#f9f5f0; padding:20px; border-radius:15px; margin-bottom:20px;">
                    <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:15px;">
                        <div>
                            <label>Послуга:</label>
                            <select name="service_id" class="form-control" required>
                                <option value="">Виберіть послугу</option>
                                <?php foreach($services_list as $service): ?>
                                    <option value="<?= $service['id'] ?>"><?= htmlspecialchars($service['name']) ?> (<?= $service['price'] ?> ₴)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label>Запланована дата:</label>
                            <input type="date" name="planned_date" class="form-control" required>
                        </div>
                        <div style="grid-column:span 3;">
                            <label>Нотатки:</label>
                            <textarea name="notes" class="form-control" rows="2" placeholder="Додаткові інструкції..."></textarea>
                        </div>
                    </div>
                    <button type="submit" name="add_treatment" class="btn-complete" style="margin-top:15px;">➕ Додати в план</button>
                </form>
                
                <div id="treatmentList" class="treatment-list">
                    <?php if(count($treatment_plans) > 0): ?>
                        <?php foreach($treatment_plans as $plan): ?>
                        <div class="treatment-item <?= $plan['status'] == 'completed' ? 'completed' : '' ?>" draggable="true" data-id="<?= $plan['id'] ?>">
                            <div style="flex:2;">
                                <strong><?= htmlspecialchars($plan['service_name']) ?></strong><br>
                                <small>📅 <?= date('d.m.Y', strtotime($plan['planned_date'])) ?></small>
                                <?php if($plan['notes']): ?>
                                    <br><small>📝 <?= htmlspecialchars($plan['notes']) ?></small>
                                <?php endif; ?>
                            </div>
                            <div>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="plan_id" value="<?= $plan['id'] ?>">
                                    <select name="status" class="form-control" style="width:120px; display:inline-block; margin-right:10px;" onchange="this.form.submit()">
                                        <option value="pending" <?= $plan['status'] == 'pending' ? 'selected' : '' ?>>⏳ Очікує</option>
                                        <option value="completed" <?= $plan['status'] == 'completed' ? 'selected' : '' ?>>✅ Виконано</option>
                                        <option value="cancelled" <?= $plan['status'] == 'cancelled' ? 'selected' : '' ?>>❌ Скасовано</option>
                                    </select>
                                    <input type="hidden" name="update_status">
                                </form>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p>Немає запланованих процедур. Додайте перший пункт в план лікування.</p>
                    <?php endif; ?>
                </div>
                
                <div style="margin-top: 15px; padding: 10px; background: #f0f4f8; border-radius: 10px; font-size: 12px; text-align: center;">
                    💡 Підказка: Перетягуйте пункти плану мишкою, щоб змінити їх порядок!
                </div>
            </div>
        </div>
        
        <script>
        function showPatientTab(tabName) {
            document.querySelectorAll('.patient-subtab').forEach(el => el.style.display = 'none');
            document.getElementById(tabName + 'Tab').style.display = 'block';
        }
        
        function applyTemplate() {
            const select = document.getElementById('templateSelect');
            const textarea = document.querySelector('textarea[name="note"]');
            if(select.value) {
                textarea.value = select.value;
                select.value = '';
            }
        }
        
        function openPhotoModal(photoUrl) {
            const modal = document.getElementById('photoModal');
            const img = document.getElementById('modalPhoto');
            img.src = photoUrl;
            modal.style.display = 'flex';
        }
        
        function exportToPDF() {
            const element = document.getElementById('historyTab');
            const opt = {
                margin: [10, 10, 10, 10],
                filename: 'patient_<?= $selected_patient['id'] ?>_history.pdf',
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 2 },
                jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
            };
            html2pdf().set(opt).from(element).save();
        }
        
        function showResponseForm(id) {
            const form = document.getElementById('responseForm_' + id);
            if(form) form.style.display = 'block';
        }
        
        function hideResponseForm(id) {
            const form = document.getElementById('responseForm_' + id);
            if(form) form.style.display = 'none';
        }
        </script>
        <?php else: ?>
        <!-- СПИСОК ПАЦІЄНТІВ -->
        <div class="section-card">
            <h3>👥 Мої пацієнти (<?= count($patients_list) ?>)</h3>
            <?php foreach($patients_list as $patient): ?>
                <div class="patient-card" onclick="window.location.href='?tab=patients&patient_id=<?= $patient['id'] ?>'">
                    <div>
                        <strong><?= htmlspecialchars($patient['full_name']) ?></strong><br>
                        <small>📞 <?= htmlspecialchars($patient['phone']) ?></small>
                    </div>
                    <div style="text-align: right;">
                        <div>📋 Візитів: <?= $patient['visits_count'] ?></div>
                        <div>💰 Витрачено: <?= number_format($patient['total_spent'], 0) ?> ₴</div>
                        <div>📅 Останній: <?= date('d.m.Y', strtotime($patient['last_visit'])) ?></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
    
    <!-- ШАБЛОНИ НОТАТОК -->
    <div id="templatesTab" class="tab-content <?= $active_tab == 'templates' ? 'active' : '' ?>">
        <div class="section-card">
            <h3>📝 Шаблони нотаток</h3>
            <form method="POST" style="margin-bottom: 30px;">
                <div style="display:grid; grid-template-columns:1fr 2fr; gap:15px;">
                    <input type="text" name="template_name" class="form-control" placeholder="Назва шаблону (наприклад: Після чистки)" required>
                    <textarea name="template_text" class="form-control" rows="2" placeholder="Текст шаблону..." required></textarea>
                </div>
                <button type="submit" name="add_template" class="btn-complete" style="margin-top:15px;">➕ Додати шаблон</button>
            </form>
            
            <h4>📋 Мої шаблони</h4>
            <div class="photo-grid">
                <?php foreach($templates as $template): ?>
                <div class="photo-item" style="text-align:left;">
                    <strong><?= htmlspecialchars($template['template_name']) ?></strong>
                    <p style="font-size:12px; margin-top:8px;"><?= nl2br(htmlspecialchars(substr($template['template_text'], 0, 100))) ?>...</p>
                    <button class="btn-primary" style="margin-top:10px; width:100%;" onclick="copyToClipboard('<?= addslashes($template['template_text']) ?>')">📋 Скопіювати</button>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    
    <!-- ПРЕПАРАТИ ДЛЯ ПРОЦЕДУР -->
    <div id="productsTab" class="tab-content <?= $active_tab == 'products' ? 'active' : '' ?>">
        <div class="section-card">
            <h3>💊 Підказки: які препарати потрібні для процедур</h3>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr><th>Процедура</th><th>Необхідні препарати</th><th>Кількість</th><th>Інструкція</th></tr>
                    </thead>
                    <tbody>
                        <?php 
                        $current_service = '';
                        foreach($procedure_products as $product): 
                            if($current_service != $product['service_name']):
                                $current_service = $product['service_name'];
                        ?>
                        <tr>
                            <td rowspan="<?= count(array_filter($procedure_products, function($p) use ($current_service) { return $p['service_name'] == $current_service; })) ?>">
                                <strong><?= htmlspecialchars($product['service_name']) ?></strong>
                            </td>
                            <tr><?= htmlspecialchars($product['product_name']) ?></td>
                            <td><?= htmlspecialchars($product['quantity_needed']) ?></td>
                            <td><?= htmlspecialchars($product['instructions']) ?></td>
                        </tr>
                        <?php else: ?>
                        <tr>
                            <td><?= htmlspecialchars($product['product_name']) ?></td>
                            <td><?= htmlspecialchars($product['quantity_needed']) ?></td>
                            <td><?= htmlspecialchars($product['instructions']) ?></td>
                        </tr>
                        <?php endif; endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- АНАЛІТИКА -->
    <div id="analyticsTab" class="tab-content <?= $active_tab == 'analytics' ? 'active' : '' ?>">
        <div class="section-card">
            <h3>📊 Детальна аналітика</h3>
            <div class="stats-grid">
                <div class="stat-card"><div class="stat-number"><?= $stats['total_appointments'] ?? 0 ?></div><div class="stat-label">📋 Всього прийомів</div></div>
                <div class="stat-card"><div class="stat-number"><?= $stats['completed'] ?? 0 ?></div><div class="stat-label">✅ Виконано</div></div>
                <div class="stat-card"><div class="stat-number"><?= $stats['pending'] ?? 0 ?></div><div class="stat-label">⏳ Очікує</div></div>
                <div class="stat-card"><div class="stat-number"><?= $stats['cancelled'] ?? 0 ?></div><div class="stat-label">❌ Скасовано</div></div>
            </div>
        </div>
        <div class="chart-grid">
            <div class="chart-card"><h3>📈 Динаміка прийомів</h3><canvas id="appointmentsChart2"></canvas></div>
            <div class="chart-card"><h3>💰 Динаміка виручки</h3><canvas id="revenueChart2"></canvas></div>
        </div>
    </div>
    
    <!-- ФІНАНСИ -->
    <div id="financeTab" class="tab-content <?= $active_tab == 'finance' ? 'active' : '' ?>">
        <div class="section-card">
            <h3>💰 Фінансова звітність</h3>
            <div class="salary-box" style="margin-bottom: 20px; text-align: center; padding: 30px;">
                <div class="stat-number"><?= number_format(($monthly_revenue * ($doctor['commission_percent'] ?? 30) / 100) + ($doctor['bonus'] ?? 0), 0) ?> ₴</div>
                <div class="stat-label">Ваша заробітна плата за цей місяць</div>
                <div style="font-size: 12px; margin-top: 5px;">(<?= $doctor['commission_percent'] ?? 30 ?>% від виручки <?= number_format($monthly_revenue, 0) ?> ₴ + премія <?= number_format($doctor['bonus'] ?? 0, 0) ?> ₴)</div>
            </div>
        </div>
    </div>
    
    <!-- ПОПУЛЯРНІ ПОСЛУГИ -->
    <div id="top_servicesTab" class="tab-content <?= $active_tab == 'top_services' ? 'active' : '' ?>">
        <div class="section-card">
            <h3>💆 Найпопулярніші послуги</h3>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr><th>Послуга</th><th>Кількість виконань</th><th>Загальна виручка</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach($top_services as $service): ?>
                        <tr>
                            <td><?= htmlspecialchars($service['name']) ?></td>
                            <td><?= $service['count'] ?> разів</span>
                            <td><?= number_format($service['total'], 0) ?> ₴</span>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- ДОСЯГНЕННЯ -->
    <div id="achievementsTab" class="tab-content <?= $active_tab == 'achievements' ? 'active' : '' ?>">
        <div class="section-card">
            <h3>🏆 Мої досягнення</h3>
            <div class="achievements-grid">
                <?php foreach($achievements as $ach): ?>
                    <div class="achievement <?= $ach['earned'] ? 'earned' : '' ?>">
                        <div style="font-size: 32px; margin-bottom: 8px;"><?= $ach['icon'] ?></div>
                        <?= $ach['name'] ?>
                        <?php if($ach['earned']): ?>
                            <div style="font-size: 11px; margin-top: 5px;">✅ Отримано</div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<!-- Модальне вікно для фото -->
<div id="photoModal" class="modal" onclick="this.style.display='none'">
    <div class="modal-content" onclick="event.stopPropagation()" style="text-align:center;">
        <img id="modalPhoto" src="" style="max-width:100%; max-height:70vh; border-radius:10px;">
        <br><br>
        <button class="btn-primary" onclick="document.getElementById('photoModal').style.display='none'">Закрити</button>
    </div>
</div>

<script>
function copyToClipboard(text) {
    navigator.clipboard.writeText(text);
    alert('✅ Шаблон скопійовано!');
}

function completeAppointment(id) {
    if(confirm('Підтвердити виконання процедури?')) {
        fetch('api/complete_appointment.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'appointment_id=' + id
        }).then(response => response.json()).then(data => {
            if(data.success) location.reload();
            else alert('Помилка: ' + data.error);
        });
    }
}

function showResponseForm(id) {
    const form = document.getElementById('responseForm_' + id);
    if(form) form.style.display = 'block';
}

function hideResponseForm(id) {
    const form = document.getElementById('responseForm_' + id);
    if(form) form.style.display = 'none';
}

const chartData = <?= json_encode($chart_data) ?>;
const months = chartData.map(d => d.month);
const counts = chartData.map(d => d.count);
const revenues = chartData.map(d => d.revenue);

const ctx1 = document.getElementById('appointmentsChart')?.getContext('2d');
if(ctx1) new Chart(ctx1, {
    type: 'line', data: { labels: months, datasets: [{ label: 'Кількість прийомів', data: counts, borderColor: '#1a5f7a', fill: true, tension: 0.4 }] }
});
const ctx2 = document.getElementById('revenueChart')?.getContext('2d');
if(ctx2) new Chart(ctx2, {
    type: 'bar', data: { labels: months, datasets: [{ label: 'Виручка (грн)', data: revenues, backgroundColor: '#28a745' }] }
});
const ctx3 = document.getElementById('appointmentsChart2')?.getContext('2d');
if(ctx3) new Chart(ctx3, {
    type: 'line', data: { labels: months, datasets: [{ label: 'Кількість прийомів', data: counts, borderColor: '#1a5f7a', fill: true, tension: 0.4 }] }
});
const ctx4 = document.getElementById('revenueChart2')?.getContext('2d');
if(ctx4) new Chart(ctx4, {
    type: 'line', data: { labels: months, datasets: [{ label: 'Виручка (грн)', data: revenues, borderColor: '#28a745', fill: true }] }
});
</script>
</body>
</html>