<?php
// Вмикаємо показ помилок для діагностики
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// ========== ПІДКЛЮЧЕННЯ ДО ВАШОЇ БАЗИ ДАНИХ ==========
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'cosmetology_db';

// Створюємо з'єднання
$conn = mysqli_connect($host, $user, $password, $database);

// Перевіряємо підключення
if (!$conn) {
    die("Помилка підключення до бази даних: " . mysqli_connect_error());
}

// Встановлюємо кодування
mysqli_set_charset($conn, "utf8mb4");

// ========== ФУНКЦІЯ ПЕРЕКЛАДУ ==========
function __($key) {
    $translations = [
        'certificates_title' => 'Сертифікати та кваліфікації лікарів',
        'back_to_dashboard' => '← Назад до панелі',
        'doctor' => 'Лікар',
        'certificates_count' => 'Кількість сертифікатів',
        'certificates_list' => 'Сертифікати (термін дії)',
        'qualification_status' => 'Статус кваліфікації',
        'no_certificates' => 'Немає сертифікатів',
        'expired_qualification' => '❗ ПОТРІБНО ПРОЙТИ КВАЛІФІКАЦІЮ!',
        'valid_qualification' => '✅ Кваліфікація дійсна',
        'expired_label' => 'ПРОСТРОЧЕНО'
    ];
    return $translations[$key] ?? $key;
}

// ========== ОТРИМУЄМО СТРУКТУРУ ТАБЛИЦІ cosmetologists ==========
// Дізнаємось, які колонки є в таблиці cosmetologists
$columns_query = "SHOW COLUMNS FROM cosmetologists";
$columns_result = mysqli_query($conn, $columns_query);
$existing_columns = [];
while($col = mysqli_fetch_assoc($columns_result)) {
    $existing_columns[] = $col['Field'];
}

// Формуємо SELECT частину запиту в залежності від наявних колонок
$select_fields = "c.id as doctor_id";
if(in_array('user_id', $existing_columns)) {
    $select_fields .= ", c.user_id";
}
if(in_array('phone', $existing_columns)) {
    $select_fields .= ", c.phone";
}
if(in_array('specialization', $existing_columns)) {
    $select_fields .= ", c.specialization";
}

// ========== ОТРИМУЄМО ДАНИХ З БД ==========

// Отримуємо всіх лікарів з їх сертифікатами
$doctors_query = "SELECT 
    $select_fields,
    u.id as user_id,
    u.full_name,
    u.email,
    COUNT(dc.id) as certificates_count,
    GROUP_CONCAT(CONCAT(IFNULL(dc.certificate_name, ''), '||', IFNULL(dc.expiry_date, '')) ORDER BY dc.expiry_date ASC SEPARATOR ';;') as certificates_data
FROM cosmetologists c
LEFT JOIN users u ON c.user_id = u.id
LEFT JOIN doctor_certificates dc ON c.id = dc.doctor_id
GROUP BY c.id
ORDER BY u.full_name";

$doctors_result = mysqli_query($conn, $doctors_query);

if (!$doctors_result) {
    die("Помилка SQL: " . mysqli_error($conn));
}

// Перевіряємо наявність таблиці doctor_training
$training_table_exists = false;
$check_training = mysqli_query($conn, "SHOW TABLES LIKE 'doctor_training'");
if(mysqli_num_rows($check_training) > 0) {
    $training_table_exists = true;
}
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Сертифікати лікарів - Cosmology</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f0eb;
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: 260px;
            background: linear-gradient(135deg, #2c1810 0%, #3d2a1f 100%);
            color: #fff;
            padding: 25px 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
        }
        .sidebar h3 {
            text-align: center;
            font-size: 24px;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            letter-spacing: 1px;
        }
        .sidebar a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px 25px;
            color: #e8d9d0;
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 15px;
        }
        .sidebar a i { font-size: 20px; width: 24px; }
        .sidebar a:hover {
            background-color: rgba(255, 255, 255, 0.1);
            color: #fff;
            padding-left: 30px;
        }
        .sidebar a.active {
            background-color: #c7a17a;
            color: #fff;
            border-left: 4px solid #fff;
        }
        .main-content {
            flex: 1;
            margin-left: 260px;
            padding: 30px;
        }
        h1 {
            color: #2c1810;
            margin-bottom: 20px;
            font-size: 28px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #c7a17a;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
        }
        .back-link:hover {
            color: #2c1810;
            text-decoration: underline;
        }
        .table-container {
            overflow-x: auto;
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #e0d6ce;
            padding: 14px 12px;
            text-align: left;
            vertical-align: top;
        }
        th {
            background-color: #c7a17a;
            color: white;
            font-weight: 600;
            font-size: 14px;
        }
        td {
            font-size: 14px;
        }
        .expired { background-color: #ffebee !important; }
        .expired td { background-color: #ffebee; }
        .status-expired {
            color: #c62828;
            font-weight: bold;
            display: inline-block;
            padding: 5px 10px;
            background: #ffcdd2;
            border-radius: 5px;
            font-size: 12px;
        }
        .status-valid {
            color: #2e7d32;
            font-weight: bold;
            display: inline-block;
            padding: 5px 10px;
            background: #c8e6c9;
            border-radius: 5px;
            font-size: 12px;
        }
        .certificate-item {
            margin-bottom: 8px;
            padding: 5px;
            border-bottom: 1px dashed #eee;
        }
        .certificate-item:last-child { border-bottom: none; }
        .certificate-name { font-weight: 500; }
        .certificate-date { font-size: 11px; color: #666; }
        .expired-cert {
            color: #c62828;
            font-size: 11px;
            font-weight: bold;
            margin-left: 5px;
        }
        .badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: bold;
        }
        .badge-danger { background: #ffcdd2; color: #c62828; }
        .badge-success { background: #c8e6c9; color: #2e7d32; }
        .empty-state {
            text-align: center;
            padding: 40px;
            color: #666;
        }
        @media (max-width: 768px) {
            .sidebar { width: 70px; }
            .sidebar span { display: none; }
            .sidebar a { justify-content: center; padding: 14px 0; }
            .sidebar a i { font-size: 24px; margin: 0; }
            .sidebar h3 { font-size: 14px; }
            .main-content { margin-left: 70px; padding: 15px; }
            th, td { padding: 8px; font-size: 12px; }
        }
    </style>
</head>
<body>


    
    
    
    
    
   <div class="sidebar">
    <h3>✨ Cosmology</h3>
    <a href="admin_dashboard.php"><i class="bi bi-house-door-fill"></i><span>Головна</span></a>
    <a href="admin_clients.php"><i class="bi bi-people-fill"></i><span>Клієнти</span></a>
    <a href="admin_doctors.php"><i class="bi bi-person-badge-fill"></i><span>Лікарі</span></a>
    <a href="admin_services.php"><i class="bi bi-grid-3x3-gap-fill"></i><span>Послуги</span></a>
    <a href="admin_appointments.php"><i class="bi bi-calendar-check-fill"></i><span>Записи</span></a>
    <a href="admin_certificates.php" class="active" style="background: #c7a17a; color: white;"><i class="bi bi-patch-check-fill"></i><span>Сертифікати</span></a>
    <a href="admin_stock.php"><i class="bi bi-box-seam-fill"></i><span>Склад</span></a>
    <a href="admin_stock_orders.php"><i class="bi bi-cart-fill"></i><span>Замовлення</span></a>
    <a href="admin_reviews.php"><i class="bi bi-star-fill"></i><span>Відгуки</span></a>
    <a href="admin_finance.php"><i class="bi bi-graph-up"></i><span>Фінанси</span></a>
    <a href="logout.php"><i class="bi bi-box-arrow-right"></i><span>Вихід</span></a>
</div>

<!-- Main Content -->
<div class="main-content">
    <h1><i class="bi bi-patch-check" style="color: #c7a17a;"></i> 📋 <?php echo __('certificates_title'); ?></h1>
    
    <a href="admin_dashboard.php" class="back-link"><i class="bi bi-arrow-left"></i> <?php echo __('back_to_dashboard'); ?></a>

    <div class="table-container">
        <?php if(mysqli_num_rows($doctors_result) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th><?php echo __('doctor'); ?></th>
                    <th><?php echo __('certificates_count'); ?></th>
                    <th><?php echo __('certificates_list'); ?></th>
                    <th><?php echo __('qualification_status'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php while($doctor = mysqli_fetch_assoc($doctors_result)): 
                    $doctor_id = isset($doctor['doctor_id']) ? intval($doctor['doctor_id']) : 0;
                    $expired_count = 0;
                    
                    // Перевіряємо прострочені обов'язкові навчання
                    if($training_table_exists && $doctor_id > 0) {
                        $training_check = "SELECT COUNT(*) as expired_count FROM doctor_training dt 
                                           WHERE dt.doctor_id = $doctor_id 
                                           AND dt.is_mandatory = 1 
                                           AND dt.valid_until < CURDATE()";
                        $training_result = mysqli_query($conn, $training_check);
                        if($training_result) {
                            $expired_trainings = mysqli_fetch_assoc($training_result);
                            $expired_count = $expired_trainings['expired_count'];
                        }
                    }
                    $row_class = ($expired_count > 0) ? 'expired' : '';
                ?>
                <tr class="<?php echo $row_class; ?>">
                    <td>
                        <strong><?php echo htmlspecialchars($doctor['full_name'] ?? 'Невідомо'); ?></strong>
                        <?php if(isset($doctor['specialization']) && !empty($doctor['specialization'])): ?>
                            <br><small style="color:#666;"><?php echo htmlspecialchars($doctor['specialization']); ?></small>
                        <?php endif; ?>
                        <?php if(isset($doctor['phone']) && !empty($doctor['phone'])): ?>
                            <br><small style="color:#999;">📞 <?php echo htmlspecialchars($doctor['phone']); ?></small>
                        <?php endif; ?>
                    </td>
                    <td style="text-align: center;">
                        <span class="badge <?php echo ($doctor['certificates_count'] ?? 0) > 0 ? 'badge-success' : 'badge-danger'; ?>">
                            <?php echo $doctor['certificates_count'] ?? 0; ?>
                        </span>
                    </td>
                    <td>
                        <?php if(!empty($doctor['certificates_data'])): ?>
                            <?php 
                            $certificates = explode(';;', $doctor['certificates_data']);
                            foreach($certificates as $cert):
                                if(empty($cert)) continue;
                                $parts = explode('||', $cert);
                                $cert_name = $parts[0] ?? 'Невідомо';
                                $expiry_date = $parts[1] ?? null;
                                $is_expired = $expiry_date && $expiry_date != '' && (strtotime($expiry_date) < time());
                            ?>
                                <div class="certificate-item">
                                    <div class="certificate-name">• <?php echo htmlspecialchars($cert_name); ?></div>
                                    <?php if($expiry_date && $expiry_date != ''): ?>
                                        <div class="certificate-date">
                                            Дійсний до: <?php echo htmlspecialchars($expiry_date); ?>
                                            <?php if($is_expired): ?>
                                                <span class="expired-cert">(<?php echo __('expired_label'); ?>)</span>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <em style="color: #999;"><?php echo __('no_certificates'); ?></em>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($expired_count > 0): ?>
                            <span class="status-expired">
                                <i class="bi bi-exclamation-triangle"></i> 
                                <?php echo __('expired_qualification'); ?>
                            </span>
                        <?php else: ?>
                            <span class="status-valid">
                                <i class="bi bi-check-circle"></i> 
                                <?php echo __('valid_qualification'); ?>
                            </span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <?php else: ?>
            <div class="empty-state">
                <i class="bi bi-folder2-open" style="font-size: 48px; color: #ccc;"></i>
                <p style="margin-top: 15px;">Немає даних про лікарів або сертифікатів</p>
                <p style="font-size: 12px; color: #999;">
                    Переконайтеся, що в таблиці <strong>cosmetologists</strong> є лікарі,<br>
                    а в таблиці <strong>doctor_certificates</strong> є сертифікати
                </p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php
// Закриваємо підключення до БД
mysqli_close($conn);
?>
</body>
</html>