<?php
session_start();
require_once 'includes/config.php';

// Перевірка прав адміністратора
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Обробка зміни статусу
if (isset($_GET['confirm'])) {
    $id = (int)$_GET['confirm'];
    $stmt = $pdo->prepare("UPDATE appointments SET status = 'confirmed' WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: admin_appointments.php");
    exit();
}

if (isset($_GET['cancel'])) {
    $id = (int)$_GET['cancel'];
    $stmt = $pdo->prepare("UPDATE appointments SET status = 'canceled' WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: admin_appointments.php");
    exit();
}

if (isset($_GET['complete'])) {
    $id = (int)$_GET['complete'];
    $stmt = $pdo->prepare("UPDATE appointments SET status = 'completed' WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: admin_appointments.php");
    exit();
}

// Фільтрація за статусом
$status_filter = $_GET['status'] ?? 'all';
$status_condition = "";
if ($status_filter != 'all') {
    $status_condition = "WHERE a.status = '" . $status_filter . "'";
}

// Отримуємо всі записи з фільтрацією
$appointments = $pdo->query("
    SELECT a.*, 
           u.full_name as client_name, 
           u.phone as client_phone,
           u.email as client_email,
           s.name as service_name,
           s.price,
           doc.full_name as doctor_name
    FROM appointments a
    JOIN users u ON a.client_id = u.id
    JOIN services s ON a.service_id = s.id
    JOIN cosmetologists c ON a.cosmetologist_id = c.id
    JOIN users doc ON c.user_id = doc.id
    $status_condition
    ORDER BY a.appointment_datetime DESC
")->fetchAll();

// Статистика
$stats = $pdo->query("
    SELECT 
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN status = 'confirmed' THEN 1 ELSE 0 END) as confirmed,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
        SUM(CASE WHEN status = 'canceled' THEN 1 ELSE 0 END) as canceled,
        COUNT(*) as total
    FROM appointments
")->fetch();

// Отримуємо всі записи для календаря (без фільтрації)
$all_appointments = $pdo->query("
    SELECT a.*, 
           u.full_name as client_name,
           s.name as service_name
    FROM appointments a
    JOIN users u ON a.client_id = u.id
    JOIN services s ON a.service_id = s.id
    ORDER BY a.appointment_datetime
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управління записами | Cosmology Beauty</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f0eb; }
        
        .sidebar {
            width: 260px;
            background: #2c2c2c;
            color: white;
            position: fixed;
            height: 100%;
            padding: 20px;
            overflow-y: auto;
            z-index: 100;
        }
        .sidebar h3 { margin-bottom: 30px; color: #c7a17a; text-align: center; }
        .sidebar a {
            color: #ddd;
            text-decoration: none;
            display: block;
            padding: 12px;
            margin: 5px 0;
            border-radius: 10px;
            transition: all 0.3s;
        }
        .sidebar a:hover { background: #c7a17a; color: white; }
        .sidebar a.active { background: #c7a17a; color: white; }
        
        .content {
            margin-left: 260px;
            padding: 30px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 15px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 15px;
            text-align: center;
            cursor: pointer;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .stat-number { font-size: 32px; font-weight: bold; }
        .stat-label { font-size: 13px; color: #666; margin-top: 5px; }
        .stat-pending .stat-number { color: #ffc107; }
        .stat-confirmed .stat-number { color: #28a745; }
        .stat-completed .stat-number { color: #17a2b8; }
        .stat-canceled .stat-number { color: #dc3545; }
        .stat-total .stat-number { color: #c7a17a; }
        
        .filter-buttons {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        .filter-btn {
            background: white;
            border: 2px solid #c7a17a;
            padding: 8px 20px;
            border-radius: 30px;
            cursor: pointer;
            transition: all 0.3s;
            color: #c7a17a;
            font-weight: 500;
        }
        .filter-btn.active, .filter-btn:hover {
            background: #c7a17a;
            color: white;
        }
        
        .tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
        .tab-btn {
            background: white;
            border: none;
            padding: 10px 25px;
            border-radius: 30px;
            cursor: pointer;
            font-size: 16px;
            transition: all 0.3s;
        }
        .tab-btn.active {
            background: #c7a17a;
            color: white;
        }
        
        .table-card {
            background: white;
            border-radius: 20px;
            padding: 20px;
            overflow-x: auto;
            display: none;
        }
        .table-card.active { display: block; }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #f0e6dc;
        }
        th { background: #c7a17a20; color: #c7a17a; }
        
        .status-pending { color: #ffc107; font-weight: bold; }
        .status-confirmed { color: #28a745; font-weight: bold; }
        .status-completed { color: #17a2b8; font-weight: bold; }
        .status-canceled { color: #dc3545; font-weight: bold; text-decoration: line-through; }
        
        .btn {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 12px;
            margin: 2px;
            border: none;
            cursor: pointer;
        }
        .btn-confirm { background: #28a745; color: white; }
        .btn-cancel { background: #dc3545; color: white; }
        .btn-complete { background: #17a2b8; color: white; }
        
        /* Стилі календаря */
        .calendar-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .calendar-nav {
            display: flex;
            gap: 15px;
        }
        .calendar-nav button {
            background: #c7a17a;
            border: none;
            padding: 8px 15px;
            border-radius: 25px;
            color: white;
            cursor: pointer;
            font-size: 16px;
        }
        .calendar-nav button:hover {
            background: #a67c52;
        }
        .current-month {
            font-size: 24px;
            font-weight: bold;
            color: #2c2c2c;
        }
        .calendar-grid {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 10px;
        }
        .calendar-weekday {
            background: #c7a17a20;
            padding: 12px;
            text-align: center;
            font-weight: bold;
            color: #c7a17a;
            border-radius: 10px;
        }
        .calendar-day {
            background: white;
            border-radius: 12px;
            padding: 12px;
            min-height: 110px;
            cursor: pointer;
            transition: all 0.3s;
            border: 1px solid #f0e6dc;
        }
        .calendar-day:hover {
            transform: scale(1.02);
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }
        .calendar-day.today {
            background: #c7a17a20;
            border: 2px solid #c7a17a;
        }
        .calendar-day.other-month {
            background: #f9f5f0;
            opacity: 0.5;
        }
        .day-number {
            font-weight: bold;
            font-size: 16px;
            margin-bottom: 8px;
        }
        .event {
            background: #c7a17a;
            color: white;
            padding: 4px 8px;
            border-radius: 8px;
            font-size: 10px;
            margin-bottom: 4px;
            cursor: pointer;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .event:hover {
            opacity: 0.9;
        }
        .event.pending { background: #ffc107; color: #333; }
        .event.confirmed { background: #28a745; }
        .event.completed { background: #17a2b8; }
        .event.canceled { background: #dc3545; text-decoration: line-through; opacity: 0.7; }
        
        @media (max-width: 900px) {
            .sidebar { width: 80px; }
            .sidebar a span:not(.icon) { display: none; }
            .content { margin-left: 80px; }
        }
        
        @media (max-width: 700px) {
            .calendar-day { min-height: 80px; padding: 6px; }
            .event { font-size: 8px; padding: 2px 4px; }
            .day-number { font-size: 12px; }
        }
    </style>
</head>
<body>

 
    <div class="sidebar">
    <h3>✨ Cosmology</h3>
    <a href="admin_dashboard.php"><i class="bi bi-house-door-fill"></i><span>Головна</span></a>
    <a href="admin_clients.php"><i class="bi bi-people-fill"></i><span>Клієнти</span></a>
    <a href="admin_doctors.php"><i class="bi bi-person-badge-fill"></i><span>Лікарі</span></a>
    <a href="admin_services.php"><i class="bi bi-grid-3x3-gap-fill"></i><span>Послуги</span></a>
    <a href="admin_appointments.php" class="active" style="background: #c7a17a; color: white;"><i class="bi bi-calendar-check-fill"></i><span>Записи</span></a>
    <a href="admin_certificates.php"><i class="bi bi-patch-check-fill"></i><span>Сертифікати</span></a>
    <a href="admin_stock.php"><i class="bi bi-box-seam-fill"></i><span>Склад</span></a>
    <a href="admin_stock_orders.php"><i class="bi bi-cart-fill"></i><span>Замовлення</span></a>
    <a href="admin_reviews.php"><i class="bi bi-star-fill"></i><span>Відгуки</span></a>
    <a href="admin_finance.php"><i class="bi bi-graph-up"></i><span>Фінанси</span></a>
    <a href="logout.php"><i class="bi bi-box-arrow-right"></i><span>Вихід</span></a>
</div>
    
    
    
    
   
  
    
<div class="content">
    <h1 style="margin-bottom: 20px;">📅 Управління записами</h1>
    
    <!-- Статистика -->
    <div class="stats-grid">
        <div class="stat-card stat-pending" onclick="filterByStatus('pending')">
            <div class="stat-number"><?= $stats['pending'] ?? 0 ?></div>
            <div class="stat-label">⏳ Очікують</div>
        </div>
        <div class="stat-card stat-confirmed" onclick="filterByStatus('confirmed')">
            <div class="stat-number"><?= $stats['confirmed'] ?? 0 ?></div>
            <div class="stat-label">✅ Підтверджені</div>
        </div>
        <div class="stat-card stat-completed" onclick="filterByStatus('completed')">
            <div class="stat-number"><?= $stats['completed'] ?? 0 ?></div>
            <div class="stat-label">✔️ Виконані</div>
        </div>
        <div class="stat-card stat-canceled" onclick="filterByStatus('canceled')">
            <div class="stat-number"><?= $stats['canceled'] ?? 0 ?></div>
            <div class="stat-label">❌ Скасовані</div>
        </div>
        <div class="stat-card stat-total" onclick="filterByStatus('all')">
            <div class="stat-number"><?= $stats['total'] ?? 0 ?></div>
            <div class="stat-label">📋 Всього</div>
        </div>
    </div>
    
    <!-- Фільтри -->
    <div class="filter-buttons">
        <button class="filter-btn <?= $status_filter == 'all' ? 'active' : '' ?>" onclick="filterByStatus('all')">Всі</button>
        <button class="filter-btn <?= $status_filter == 'pending' ? 'active' : '' ?>" onclick="filterByStatus('pending')">Очікують</button>
        <button class="filter-btn <?= $status_filter == 'confirmed' ? 'active' : '' ?>" onclick="filterByStatus('confirmed')">Підтверджені</button>
        <button class="filter-btn <?= $status_filter == 'completed' ? 'active' : '' ?>" onclick="filterByStatus('completed')">Виконані</button>
        <button class="filter-btn <?= $status_filter == 'canceled' ? 'active' : '' ?>" onclick="filterByStatus('canceled')">Скасовані</button>
    </div>
    
    <!-- Вкладки -->
    <div class="tabs">
        <button class="tab-btn active" onclick="showTab('list')">📋 Список записів</button>
        <button class="tab-btn" onclick="showTab('calendar')">📆 Календар записів</button>
    </div>
    
    <!-- Список записів -->
    <div id="listTab" class="table-card active">
        <table>
            <thead>
                <tr><th>ID</th><th>Клієнт</th><th>Телефон</th><th>Лікар</th><th>Послуга</th><th>Сума</th><th>Дата та час</th><th>Статус</th><th>Дії</th></tr>
            </thead>
            <tbody>
                <?php foreach($appointments as $a): ?>
                <tr>
                    <td><?= $a['id'] ?></td>
                    <td><?= htmlspecialchars($a['client_name']) ?></td>
                    <td><?= htmlspecialchars($a['client_phone']) ?></td>
                    <td><?= htmlspecialchars($a['doctor_name']) ?></td>
                    <td><?= htmlspecialchars($a['service_name']) ?></td>
                    <td><?= number_format($a['price'], 0) ?> ₴</td>
                    <td><?= date('d.m.Y H:i', strtotime($a['appointment_datetime'])) ?></td>
                    <td class="status-<?= $a['status'] ?>">
                        <?php
                        $statusLabels = [
                            'pending' => '⏳ Очікує',
                            'confirmed' => '✅ Підтверджено',
                            'completed' => '✔️ Виконано',
                            'canceled' => '❌ Скасовано'
                        ];
                        echo $statusLabels[$a['status']] ?? $a['status'];
                        ?>
                    </td>
                    <td>
                        <?php if($a['status'] == 'pending'): ?>
                            <a href="?confirm=<?= $a['id'] ?>&status=<?= $status_filter ?>" class="btn btn-confirm" title="Підтвердити">✅</a>
                            <a href="?cancel=<?= $a['id'] ?>&status=<?= $status_filter ?>" class="btn btn-cancel" title="Скасувати" onclick="return confirm('Скасувати запис?')">❌</a>
                        <?php elseif($a['status'] == 'confirmed'): ?>
                            <a href="?complete=<?= $a['id'] ?>&status=<?= $status_filter ?>" class="btn btn-complete" title="Виконано">✔️</a>
                            <a href="?cancel=<?= $a['id'] ?>&status=<?= $status_filter ?>" class="btn btn-cancel" title="Скасувати" onclick="return confirm('Скасувати запис?')">❌</a>
                        <?php elseif($a['status'] == 'completed'): ?>
                            <span style="color:#17a2b8;">✔️ Виконано</span>
                        <?php else: ?>
                            <span style="color:#dc3545;">❌ Скасовано</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    
    <!-- Календар записів -->
    <div id="calendarTab" class="table-card">
        <div id="calendar"></div>
    </div>
</div>

<script>
// Дані для календаря (вбудовані прямо в JS)
const appointmentsData = <?php 
    $calendar_data = [];
    foreach($all_appointments as $a) {
        $date = date('Y-m-d', strtotime($a['appointment_datetime']));
        $time = date('H:i', strtotime($a['appointment_datetime']));
        $calendar_data[] = [
            'id' => $a['id'],
            'date' => $date,
            'time' => $time,
            'client_name' => $a['client_name'],
            'service_name' => $a['service_name'],
            'status' => $a['status']
        ];
    }
    echo json_encode($calendar_data);
?>;

let currentYear = new Date().getFullYear();
let currentMonth = new Date().getMonth();

function filterByStatus(status) {
    window.location.href = 'admin_appointments.php?status=' + status;
}

function showTab(tab) {
    const listTab = document.getElementById('listTab');
    const calendarTab = document.getElementById('calendarTab');
    const tabs = document.querySelectorAll('.tab-btn');
    
    if (tab === 'list') {
        listTab.classList.add('active');
        calendarTab.classList.remove('active');
        tabs[0].classList.add('active');
        tabs[1].classList.remove('active');
    } else {
        listTab.classList.remove('active');
        calendarTab.classList.add('active');
        tabs[0].classList.remove('active');
        tabs[1].classList.add('active');
        renderCalendar();
    }
}

function renderCalendar() {
    const firstDay = new Date(currentYear, currentMonth, 1);
    const lastDay = new Date(currentYear, currentMonth + 1, 0);
    const startingDay = firstDay.getDay();
    const daysInMonth = lastDay.getDate();
    const today = new Date();
    
    let calendarHtml = `
        <div class="calendar-header">
            <div class="current-month">${getMonthName(currentMonth)} ${currentYear}</div>
            <div class="calendar-nav">
                <button onclick="prevMonth()">◀ Попередній</button>
                <button onclick="nextMonth()">Наступний ▶</button>
            </div>
        </div>
        <div class="calendar-grid">
    `;
    
    // Дні тижня
    const weekDays = ['ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ', 'НД'];
    for (let i = 0; i < 7; i++) {
        calendarHtml += `<div class="calendar-weekday">${weekDays[i]}</div>`;
    }
    
    // Порожні клітинки для початку місяця
    let startOffset = startingDay === 0 ? 6 : startingDay - 1;
    for (let i = 0; i < startOffset; i++) {
        calendarHtml += '<div class="calendar-day other-month"></div>';
    }
    
    // Дні місяця
    for (let day = 1; day <= daysInMonth; day++) {
        const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        const isToday = (today.getDate() === day && today.getMonth() === currentMonth && today.getFullYear() === currentYear);
        const dayClass = isToday ? 'calendar-day today' : 'calendar-day';
        
        // Записи на цей день
        const dayAppointments = appointmentsData.filter(a => a.date === dateStr);
        
        calendarHtml += `<div class="${dayClass}">
            <div class="day-number">${day}</div>`;
        
        dayAppointments.forEach(app => {
            const statusClass = app.status;
            let statusIcon = '';
            if (app.status === 'pending') statusIcon = '⏳';
            else if (app.status === 'confirmed') statusIcon = '✅';
            else if (app.status === 'completed') statusIcon = '✔️';
            else if (app.status === 'canceled') statusIcon = '❌';
            
            calendarHtml += `<div class="event ${statusClass}" onclick="event.stopPropagation(); showAppointmentDetails(${app.id})" title="${app.client_name} - ${app.service_name}">
                ${statusIcon} ${app.time} ${app.client_name.substring(0, 12)}${app.client_name.length > 12 ? '...' : ''}
            </div>`;
        });
        
        calendarHtml += `</div>`;
    }
    
    calendarHtml += '</div>';
    document.getElementById('calendar').innerHTML = calendarHtml;
}

function getMonthName(month) {
    const months = ['Січень', 'Лютий', 'Березень', 'Квітень', 'Травень', 'Червень', 
                    'Липень', 'Серпень', 'Вересень', 'Жовтень', 'Листопад', 'Грудень'];
    return months[month];
}

function prevMonth() {
    if (currentMonth === 0) {
        currentMonth = 11;
        currentYear--;
    } else {
        currentMonth--;
    }
    renderCalendar();
}

function nextMonth() {
    if (currentMonth === 11) {
        currentMonth = 0;
        currentYear++;
    } else {
        currentMonth++;
    }
    renderCalendar();
}

function showAppointmentDetails(id) {
    const appointment = appointmentsData.find(a => a.id === id);
    if (appointment) {
        let statusText = '';
        switch(appointment.status) {
            case 'pending': statusText = '⏳ Очікує'; break;
            case 'confirmed': statusText = '✅ Підтверджено'; break;
            case 'completed': statusText = '✔️ Виконано'; break;
            case 'canceled': statusText = '❌ Скасовано'; break;
        }
        alert(`📅 Запис #${appointment.id}\n👤 Клієнт: ${appointment.client_name}\n💇 Послуга: ${appointment.service_name}\n⏰ Час: ${appointment.time}\n📌 Статус: ${statusText}`);
    }
}

// Ініціалізація календаря при завантаженні
document.addEventListener('DOMContentLoaded', function() {
    renderCalendar();
});
</script>

</body>
</html>