<?php
// api/calendar_events.php
header('Content-Type: application/json');
require_once '../config.php';
require_once '../includes/db.php';

$start = $_GET['start'] ?? date('Y-m-d');
$end = $_GET['end'] ?? date('Y-m-d', strtotime('+30 days'));

$response = [];

// Отримуємо всі послуги
$services_query = "SELECT * FROM services WHERE is_active = 1";
$services_result = $conn->query($services_query);

// Отримуємо всі записи
$bookings_query = "SELECT * FROM appointments WHERE appointment_datetime BETWEEN '$start' AND '$end'";
$bookings_result = $conn->query($bookings_query);
$bookings = [];
while ($row = $bookings_result->fetch_assoc()) {
    $bookings[$row['appointment_datetime'] . '_' . $row['service_id']] = $row;
}

// Генерація слотів
while ($service = $services_result->fetch_assoc()) {
    $duration = $service['duration'] ?? 30; // хвилини
    $current = new DateTime($start);
    $end_date = new DateTime($end);
    $work_start = new DateTime('09:00');
    $work_end = new DateTime('20:00');
    
    while ($current <= $end_date) {
        $slot_start = clone $current;
        $slot_start->setTime($work_start->format('H'), $work_start->format('i'));
        
        while ($slot_start < $work_end) {
            $slot_end = clone $slot_start;
            $slot_end->add(new DateInterval("PT{$duration}M"));
            
            if ($slot_end <= $work_end) {
                $datetime = $slot_start->format('Y-m-d H:i:s');
                $key = $datetime . '_' . $service['id'];
                $is_booked = isset($bookings[$key]);
                
                $response[] = [
                    'id' => uniqid(),
                    'title' => $is_booked ? 'Зайнято' : $service['name'],
                    'start' => $datetime,
                    'end' => $slot_end->format('Y-m-d H:i:s'),
                    'status' => $is_booked ? 'booked' : 'available',
                    'service_id' => $service['id'],
                    'service_name' => $service['name'],
                    'service_price' => $service['price'],
                    'service_duration' => $duration,
                    'backgroundColor' => $is_booked ? '#dc3545' : '#28a745',
                    'borderColor' => $is_booked ? '#dc3545' : '#28a745'
                ];
            }
            
            $slot_start->add(new DateInterval("PT{$duration}M"));
        }
        
        $current->add(new DateInterval('P1D'));
    }
}

echo json_encode($response);
?>