<?php
session_start();
require_once '../includes/config.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] != 'admin' && $_SESSION['user_role'] != 'client')) {
    header("Location: ../login.php");
    exit();
}

$id = $_GET['id'] ?? 0;
if ($id) {
    $stmt = $pdo->prepare("UPDATE appointments SET status = 'canceled' WHERE id = ?");
    $stmt->execute([$id]);
}

// Повернення назад
$referer = $_SERVER['HTTP_REFERER'] ?? '../admin_appointments.php';
header("Location: " . $referer);
?>