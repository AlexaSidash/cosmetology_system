<?php
session_start();
require_once '../includes/config.php';

header('Content-Type: application/json');

// Перевірка прав адміністратора
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    echo json_encode(['success' => false, 'message' => 'Немає прав доступу']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Невірний метод']);
    exit();
}

$id = $_POST['id'] ?? 0;
$action = $_POST['action'] ?? '';

if (!$id) {
    echo json_encode(['success' => false, 'message' => 'ID відгуку не вказано']);
    exit();
}

switch ($action) {
    case 'approve':
        $stmt = $pdo->prepare("UPDATE reviews SET is_approved = 1 WHERE id = ?");
        $result = $stmt->execute([$id]);
        
        if ($result) {
            // Отримуємо дані для email сповіщення
            $stmt = $pdo->prepare("
                SELECT r.*, u.email, u.full_name 
                FROM reviews r
                JOIN clients c ON r.client_id = c.id
                JOIN users u ON c.user_id = u.id
                WHERE r.id = ?
            ");
            $stmt->execute([$id]);
            $review = $stmt->fetch();
            
            if ($review) {
                // Відправляємо сповіщення клієнту
                $subject = "Ваш відгук схвалено";
                $message = "Вітаємо, {$review['full_name']}!<br>Ваш відгук опубліковано на сайті.<br>Дякуємо за зворотній зв'язок!";
                sendEmailNotification($review['email'], $subject, $message);
            }
            
            echo json_encode(['success' => true, 'message' => 'Відгук схвалено']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Помилка при схваленні']);
        }
        break;
        
    case 'delete':
        $stmt = $pdo->prepare("DELETE FROM reviews WHERE id = ?");
        $result = $stmt->execute([$id]);
        echo json_encode(['success' => $result, 'message' => $result ? 'Відгук видалено' : 'Помилка видалення']);
        break;
        
    case 'respond':
        $response = $_POST['response'] ?? '';
        if (!$response) {
            echo json_encode(['success' => false, 'message' => 'Введіть текст відповіді']);
            exit();
        }
        
        $stmt = $pdo->prepare("UPDATE reviews SET doctor_response = ?, response_date = NOW() WHERE id = ?");
        $result = $stmt->execute([$response, $id]);
        
        if ($result) {
            // Отримуємо дані для email сповіщення
            $stmt = $pdo->prepare("
                SELECT r.*, u.email, u.full_name 
                FROM reviews r
                JOIN clients c ON r.client_id = c.id
                JOIN users u ON c.user_id = u.id
                WHERE r.id = ?
            ");
            $stmt->execute([$id]);
            $review = $stmt->fetch();
            
            if ($review) {
                $subject = "Відповідь лікаря на ваш відгук";
                $message = "Шановний(а) {$review['full_name']}!<br>Лікар відповів на ваш відгук:<br><br>\"{$response}\"<br><br>Дякуємо, що залишаєтесь з нами!";
                sendEmailNotification($review['email'], $subject, $message);
            }
            
            echo json_encode(['success' => true, 'message' => 'Відповідь збережено']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Помилка при збереженні відповіді']);
        }
        break;
        
    default:
        echo json_encode(['success' => false, 'message' => 'Невідома дія']);
}
?>