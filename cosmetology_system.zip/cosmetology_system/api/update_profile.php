<?php
session_start();
require_once '../includes/config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Не авторизовано']);
    exit;
}

$user_id = $_SESSION['user_id'];
$full_name = $_POST['full_name'] ?? '';
$email = $_POST['email'] ?? '';
$phone = $_POST['phone'] ?? '';

if (empty($full_name) || empty($email) || empty($phone)) {
    echo json_encode(['success' => false, 'error' => 'Всі поля обов\'язкові']);
    exit;
}

$stmt = $pdo->prepare("UPDATE users SET full_name = ?, email = ?, phone = ? WHERE id = ?");
$stmt->execute([$full_name, $email, $phone, $user_id]);

$_SESSION['user_name'] = $full_name;
$_SESSION['user_email'] = $email;

echo json_encode(['success' => true]);
?>