<?php
require_once '../includes/config.php';

header('Content-Type: application/json');

$date = $_GET['date'] ?? '';
$doctor_id = (int)$_GET['doctor_id'] ?? 0;
$service_id = (int)$_GET['service_id'] ?? 0;

if (!$date || !$doctor_id || !$service_id) {
    echo json_encode(['times' => []]);
    exit();
}

// Отримуємо тривалість послуги
$stmt = $pdo->prepare("SELECT duration_minutes FROM services WHERE id = ?");
$stmt->execute([$service_id]);
$duration = $stmt->fetch()['duration_minutes'] ?? 60;

// Визначаємо день тижня
$dayOfWeek = date('N', strtotime($date));

// Графік роботи
if ($dayOfWeek == 6) { // Субота
    $start = 10;
    $end = 15;
} elseif ($dayOfWeek == 7) { // Неділя
    echo json_encode(['times' => []]);
    exit();
} else { // Пн-Пт
    $start = 10;
    $end = 20;
}

// Отримуємо зайняті слоти
$stmt = $pdo->prepare("
    SELECT appointment_datetime FROM appointments 
    WHERE cosmetologist_id = ? AND DATE(appointment_datetime) = ? AND status NOT IN ('canceled')
");
$stmt->execute([$doctor_id, $date]);
$booked = $stmt->fetchAll();

$booked_times = [];
foreach ($booked as $b) {
    $booked_times[] = date('H:i', strtotime($b['appointment_datetime']));
}

// Генеруємо вільні слоти
$times = [];
$current = strtotime("$date $start:00");
$end_time = strtotime("$date $end:00");

while ($current + $duration * 60 <= $end_time) {
    $time_slot = date('H:i', $current);
    if (!in_array($time_slot, $booked_times)) {
        $times[] = $time_slot;
    }
    $current += $duration * 60;
}

echo json_encode(['times' => $times]);
?>