<?php
session_start();
require_once '../includes/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    header("Location: ../login.php");
    exit();
}

$client_id = $_POST['client_id'] ?? 0;
$doctor_id = $_POST['doctor_id'] ?? 0;
$service_id = $_POST['service_id'] ?? 0;
$date = $_POST['date'] ?? '';
$time = $_POST['time'] ?? '';
$payment_method = $_POST['payment_method'] ?? '';
$requires_tests = $_POST['requires_tests'] ?? 0;

if (!$client_id || !$doctor_id || !$service_id || !$date || !$time) {
    header("Location: ../admin_dashboard.php?msg=error");
    exit();
}

$datetime = $date . ' ' . $time . ':00';

// Перевірка, чи не зайнятий слот
$stmt = $pdo->prepare("SELECT id FROM appointments WHERE cosmetologist_id = ? AND appointment_datetime = ? AND status NOT IN ('canceled')");
$stmt->execute([$doctor_id, $datetime]);
if ($stmt->fetch()) {
    header("Location: ../admin_dashboard.php?msg=slot_taken");
    exit();
}

// Створення запису
$stmt = $pdo->prepare("
    INSERT INTO appointments (client_id, cosmetologist_id, service_id, appointment_datetime, status, created_at, payment_method, requires_tests) 
    VALUES (?, ?, ?, ?, 'confirmed', NOW(), ?, ?)
");
$stmt->execute([$client_id, $doctor_id, $service_id, $datetime, $payment_method, $requires_tests]);

// Отримуємо телефон клієнта для SMS
$stmt = $pdo->prepare("SELECT phone, full_name FROM users WHERE id = ?");
$stmt->execute([$client_id]);
$client = $stmt->fetch();

// Отримуємо інформацію про послугу
$stmt = $pdo->prepare("SELECT name, price FROM services WHERE id = ?");
$stmt->execute([$service_id]);
$service = $stmt->fetch();

// Отримуємо інформацію про лікаря
$stmt = $pdo->prepare("
    SELECT u.full_name FROM cosmetologists c 
    JOIN users u ON c.user_id = u.id 
    WHERE c.id = ?
");
$stmt->execute([$doctor_id]);
$doctor = $stmt->fetch();

// Надсилаємо SMS-нагадування (симуляція)
$message = "Шановний(а) {$client['full_name']}! Ви записані на {$service['name']} до лікаря {$doctor['full_name']} на {$date} о {$time}. Вартість: {$service['price']} грн. Чекаємо на Вас! Cosmology Beauty.";

// Тут можна додати реальну відправку SMS через API

header("Location: ../admin_dashboard.php?msg=appointment_created");
?>