<?php
session_start();
require_once '../includes/config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Не авторизовано']);
    exit;
}

$appointment_id = $_POST['appointment_id'] ?? 0;
$rating = (int)$_POST['rating'] ?? 5;
$comment = $_POST['comment'] ?? '';

if (!$appointment_id) {
    echo json_encode(['success' => false, 'error' => 'Не вказано ID запису']);
    exit;
}

// Отримуємо doctor_id та перевіряємо, чи запис належить клієнту
$stmt = $pdo->prepare("
    SELECT a.cosmetologist_id, a.client_id 
    FROM appointments a 
    WHERE a.id = ? AND a.client_id = ?
");
$stmt->execute([$appointment_id, $_SESSION['user_id']]);
$app = $stmt->fetch();

if (!$app) {
    echo json_encode(['success' => false, 'error' => 'Запис не знайдено']);
    exit;
}

$stmt = $pdo->prepare("INSERT INTO reviews (client_id, appointment_id, doctor_id, rating, comment) VALUES (?, ?, ?, ?, ?)");
$stmt->execute([$_SESSION['user_id'], $appointment_id, $app['cosmetologist_id'], $rating, $comment]);

// Оновлюємо середній рейтинг лікаря
$stmt = $pdo->prepare("
    UPDATE cosmetologists c 
    SET rating = (SELECT AVG(rating) FROM reviews WHERE doctor_id = ?) 
    WHERE c.id = ?
");
$stmt->execute([$app['cosmetologist_id'], $app['cosmetologist_id']]);

echo json_encode(['success' => true]);
?>