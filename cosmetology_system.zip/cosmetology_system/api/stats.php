<?php
// api/stats.php
header('Content-Type: application/json');
require_once '../config.php';
require_once '../includes/db.php';

$period = $_GET['period'] ?? 'month';
$year = date('Y');
$month = date('m');

switch ($period) {
    case 'week':
        $start = date('Y-m-d', strtotime('-7 days'));
        $end = date('Y-m-d');
        break;
    case 'year':
        $start = date('Y-01-01');
        $end = date('Y-12-31');
        break;
    default: // month
        $start = date('Y-m-01');
        $end = date('Y-m-t');
}

$stats = [];

// 1. Загальна кількість записів
$query = "SELECT COUNT(*) as total FROM appointments WHERE appointment_datetime BETWEEN '$start' AND '$end'";
$result = $conn->query($query);
$stats['total_bookings'] = $result->fetch_assoc()['total'];

// 2. Кількість записів за статусами
$query = "SELECT status, COUNT(*) as count FROM appointments WHERE appointment_datetime BETWEEN '$start' AND '$end' GROUP BY status";
$result = $conn->query($query);
$stats['by_status'] = [];
while ($row = $result->fetch_assoc()) {
    $stats['by_status'][$row['status']] = $row['count'];
}

// 3. Найпопулярніші послуги
$query = "SELECT s.name, COUNT(a.id) as count, SUM(s.price) as revenue 
          FROM appointments a 
          JOIN services s ON a.service_id = s.id 
          WHERE a.appointment_datetime BETWEEN '$start' AND '$end'
          GROUP BY a.service_id 
          ORDER BY count DESC LIMIT 5";
$result = $conn->query($query);
$stats['popular_services'] = [];
while ($row = $result->fetch_assoc()) {
    $stats['popular_services'][] = $row;
}

// 4. Загальна виручка
$query = "SELECT SUM(s.price) as revenue 
          FROM appointments a 
          JOIN services s ON a.service_id = s.id 
          WHERE a.appointment_datetime BETWEEN '$start' AND '$end' AND a.status = 'completed'";
$result = $conn->query($query);
$stats['total_revenue'] = $result->fetch_assoc()['revenue'] ?? 0;

// 5. Динаміка записів по днях
$query = "SELECT DATE(appointment_datetime) as date, COUNT(*) as count 
          FROM appointments 
          WHERE appointment_datetime BETWEEN '$start' AND '$end'
          GROUP BY DATE(appointment_datetime)
          ORDER BY date";
$result = $conn->query($query);
$stats['daily_stats'] = [];
while ($row = $result->fetch_assoc()) {
    $stats['daily_stats'][] = $row;
}

// 6. Кількість клієнтів
$query = "SELECT COUNT(DISTINCT client_name, phone) as total_clients 
          FROM appointments 
          WHERE appointment_datetime BETWEEN '$start' AND '$end'";
$result = $conn->query($query);
$stats['total_clients'] = $result->fetch_assoc()['total_clients'];

echo json_encode($stats);
?>