<?php
session_start();
header('Content-Type: application/json');

require_once '../includes/config.php';

$appointment_id = $_POST['appointment_id'] ?? 0;

if (!$appointment_id) {
    echo json_encode(['success' => false, 'error' => 'Не вказано ID запису']);
    exit;
}

if ($_SESSION['user_role'] != 'cosmetologist' && $_SESSION['user_role'] != 'admin') {
    echo json_encode(['success' => false, 'error' => 'Немає прав']);
    exit;
}

$stmt = $pdo->prepare("UPDATE appointments SET status = 'completed' WHERE id = ?");
$stmt->execute([$appointment_id]);

echo json_encode(['success' => true]);
?>