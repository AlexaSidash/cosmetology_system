<?php
session_start();
require_once '../includes/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    echo json_encode(['success' => false, 'error' => 'Немає прав']);
    exit();
}

$room_id = $_POST['room_id'] ?? 0;
$patient_id = $_POST['patient_id'] ?? 0;
$doctor_id = $_POST['doctor_id'] ?? 0;
$service_id = $_POST['service_id'] ?? 0;
$date = $_POST['date'] ?? '';
$start_time = $_POST['start_time'] ?? '';
$end_time = $_POST['end_time'] ?? '';

if (!$room_id || !$patient_id || !$doctor_id || !$service_id || !$date || !$start_time) {
    echo json_encode(['success' => false, 'error' => 'Всі поля обов\'язкові']);
    exit();
}

// Перевірка на конфлікт часу в кабінеті
$stmt = $pdo->prepare("
    SELECT id FROM room_schedule 
    WHERE room_id = ? AND date = ? 
    AND ((start_time <= ? AND end_time > ?) OR (start_time < ? AND end_time >= ?))
");
$stmt->execute([$room_id, $date, $start_time, $start_time, $end_time, $end_time]);

if ($stmt->fetch()) {
    echo json_encode(['success' => false, 'error' => 'Цей час вже зайнятий в даному кабінеті']);
    exit();
}

// Додаємо запис в розклад
$stmt = $pdo->prepare("
    INSERT INTO room_schedule (room_id, date, start_time, end_time, doctor_id, patient_id, status, appointment_id)
    VALUES (?, ?, ?, ?, ?, ?, 'scheduled', NULL)
");
$result = $stmt->execute([$room_id, $date, $start_time, $end_time, $doctor_id, $patient_id]);

if ($result) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'Помилка збереження']);
}
?>