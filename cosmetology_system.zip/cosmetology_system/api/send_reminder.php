<?php
session_start();
require_once '../includes/config.php';

header('Content-Type: application/json');

$appointment_id = $_GET['appointment_id'] ?? 0;

if (!$appointment_id) {
    echo json_encode(['success' => false, 'error' => 'Не вказано ID запису']);
    exit();
}

// Отримуємо інформацію про запис
$stmt = $pdo->prepare("
    SELECT a.*, u.phone, u.full_name as client_name, s.name as service_name, doc.full_name as doctor_name
    FROM appointments a
    JOIN users u ON a.client_id = u.id
    JOIN services s ON a.service_id = s.id
    JOIN cosmetologists c ON a.cosmetologist_id = c.id
    JOIN users doc ON c.user_id = doc.id
    WHERE a.id = ?
");
$stmt->execute([$appointment_id]);
$appointment = $stmt->fetch();

if (!$appointment) {
    echo json_encode(['success' => false, 'error' => 'Запис не знайдено']);
    exit();
}

// Формуємо SMS повідомлення
$datetime = date('d.m.Y H:i', strtotime($appointment['appointment_datetime']));
$message = "Шановний(а) {$appointment['client_name']}! Нагадуємо, що Ви записані на {$appointment['service_name']} до лікаря {$appointment['doctor_name']} на {$datetime}. Чекаємо на Вас! Cosmology Beauty.";

// Якщо потрібні аналізи
if ($appointment['requires_tests']) {
    $message .= " Для процедури необхідно здати аналізи заздалегідь. Деталі у адміністратора.";
}

// Тут можна додати реальну відправку SMS через API (Twilio, SMS-город та ін.)

// Симулюємо відправку
echo json_encode(['success' => true, 'message' => $message, 'phone' => $appointment['phone']]);
?>