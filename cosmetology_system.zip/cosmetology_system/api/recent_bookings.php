<?php
// api/recent_bookings.php
header('Content-Type: application/json');
require_once '../config.php';
require_once '../includes/db.php';

$limit = $_GET['limit'] ?? 10;
$period = $_GET['period'] ?? 'month';

switch ($period) {
    case 'week':
        $start = date('Y-m-d', strtotime('-7 days'));
        break;
    case 'year':
        $start = date('Y-01-01');
        break;
    default:
        $start = date('Y-m-01');
}

$query = "SELECT a.id, a.client_name, a.phone, a.appointment_datetime, a.status,
                 s.name as service_name, s.price
          FROM appointments a
          JOIN services s ON a.service_id = s.id
          WHERE a.appointment_datetime >= ?
          ORDER BY a.appointment_datetime DESC
          LIMIT ?";

$stmt = $conn->prepare($query);
$stmt->bind_param("si", $start, $limit);
$stmt->execute();
$result = $stmt->get_result();

$bookings = [];
while ($row = $result->fetch_assoc()) {
    $bookings[] = [
        'id' => $row['id'],
        'client_name' => $row['client_name'],
        'phone' => $row['phone'],
        'service_name' => $row['service_name'],
        'price' => $row['price'],
        'date' => date('d.m.Y', strtotime($row['appointment_datetime'])),
        'time' => date('H:i', strtotime($row['appointment_datetime'])),
        'status' => $row['status']
    ];
}

echo json_encode($bookings);
?>