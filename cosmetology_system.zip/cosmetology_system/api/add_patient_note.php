<?php
session_start();
require_once '../includes/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'cosmetologist') {
    echo json_encode(['success' => false, 'error' => 'Немає прав']);
    exit();
}

$patient_id = $_POST['patient_id'] ?? 0;
$appointment_id = $_POST['appointment_id'] ?? null;
$note = $_POST['note'] ?? '';
$doctor_id = $_SESSION['doctor_id'] ?? 0;

if (!$patient_id || empty($note)) {
    header("Location: ../doctor_cabinet.php?patient_id=" . $patient_id);
    exit();
}

$stmt = $pdo->prepare("
    INSERT INTO patient_notes (patient_id, doctor_id, appointment_id, note) 
    VALUES (?, ?, ?, ?)
");
$stmt->execute([$patient_id, $doctor_id, $appointment_id, $note]);

header("Location: ../doctor_cabinet.php?patient_id=" . $patient_id);
?>