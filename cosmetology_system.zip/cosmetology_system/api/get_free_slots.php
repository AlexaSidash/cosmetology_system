<?php
// api/get_free_slots.php
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../includes/config.php';

$cosmetologist_id = isset($_GET['cosmetologist_id']) ? (int)$_GET['cosmetologist_id'] : 0;
$date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
$service_id = isset($_GET['service_id']) ? (int)$_GET['service_id'] : 0;

if (!$cosmetologist_id) {
    echo json_encode(['error' => 'Мастера не обрано', 'free_slots' => []]);
    exit;
}

// Отримуємо тривалість послуги
$duration = 60;
if ($service_id) {
    $stmt = $pdo->prepare("SELECT duration_minutes FROM services WHERE id = ?");
    $stmt->execute([$service_id]);
    $service = $stmt->fetch();
    if ($service) {
        $duration = (int)$service['duration_minutes'];
    }
}

// Визначаємо день тижня
$dayOfWeek = date('N', strtotime($date));

// ГРАФІК РОБОТИ:
if ($dayOfWeek == 7) { // Неділя
    echo json_encode(['free_slots' => [], 'message' => 'У неділю клініка не працює']);
    exit;
} elseif ($dayOfWeek == 6) { // Субота
    $work_start = 10;
    $work_end = 15;
} else { // Понеділок - П'ятниця
    $work_start = 10;
    $work_end = 20;
}

// Отримуємо зайняті слоти
$stmt = $pdo->prepare("
    SELECT appointment_datetime 
    FROM appointments 
    WHERE cosmetologist_id = ? 
      AND DATE(appointment_datetime) = ?
      AND status NOT IN ('canceled', 'no_show')
");
$stmt->execute([$cosmetologist_id, $date]);
$booked = $stmt->fetchAll(PDO::FETCH_ASSOC);

$booked_times = [];
foreach ($booked as $book) {
    $booked_times[] = date('H:i', strtotime($book['appointment_datetime']));
}

// Генеруємо вільні слоти
$free_slots = [];
$current = strtotime("$date $work_start:00");
$end = strtotime("$date $work_end:00");

while ($current + $duration * 60 <= $end) {
    $slot_start = date('H:i', $current);
    
    if (!in_array($slot_start, $booked_times)) {
        $free_slots[] = $slot_start;
    }
    
    $current += $duration * 60;
}

echo json_encode(['free_slots' => $free_slots]);
?>