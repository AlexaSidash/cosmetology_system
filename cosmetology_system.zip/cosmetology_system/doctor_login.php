<?php
session_start();
require_once 'includes/config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    
    $stmt = $pdo->prepare("
        SELECT u.*, c.id as doctor_id 
        FROM users u 
        JOIN cosmetologists c ON u.id = c.user_id 
        WHERE u.role = 'cosmetologist' AND u.email = ?
    ");
    $stmt->execute([$email]);
    $doctor = $stmt->fetch();
    
    if ($doctor && password_verify($password, $doctor['password_hash'])) {
        $_SESSION['user_id'] = $doctor['id'];
        $_SESSION['user_name'] = $doctor['full_name'];
        $_SESSION['user_role'] = 'cosmetologist';
        $_SESSION['doctor_id'] = $doctor['doctor_id'];
        
        header("Location: doctor_cabinet.php");
        exit();
    } else {
        $error = "Невірний email або пароль";
    }
}
?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>Вхід для лікарів | Cosmology Beauty</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #1a5f7a, #0d3b4f);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .login-container {
            max-width: 400px;
            width: 90%;
            background: white;
            border-radius: 30px;
            padding: 40px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
        }
        h1 { text-align: center; color: #1a5f7a; margin-bottom: 10px; }
        .subtitle { text-align: center; color: #666; margin-bottom: 30px; }
        input {
            width: 100%;
            padding: 14px;
            margin: 10px 0;
            border: 2px solid #e0e0e0;
            border-radius: 15px;
            font-size: 15px;
        }
        button {
            width: 100%;
            background: #1a5f7a;
            color: white;
            padding: 14px;
            border: none;
            border-radius: 15px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
        }
        .error {
            background: #fee;
            color: #e74c3c;
            padding: 10px;
            border-radius: 10px;
            margin-bottom: 20px;
            text-align: center;
        }
        .test-data {
            background: #e8f4f8;
            padding: 15px;
            border-radius: 15px;
            margin-top: 20px;
            font-size: 13px;
        }
        .test-data strong { color: #1a5f7a; }
        a { color: #1a5f7a; text-decoration: none; }
        hr { margin: 15px 0; }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>👩‍⚕️ Вхід для лікарів</h1>
        <div class="subtitle">Cosmology Beauty Medical Center</div>
        
        <?php if($error): ?>
            <div class="error">❌ <?= $error ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Пароль" required>
            <button type="submit">Увійти в кабінет →</button>
        </form>
        
        <div class="test-data">
            <strong>📋 Тестові дані:</strong><br>
            👩‍⚕️ <strong>Анна Коваленко:</strong> anna@cosmology.com / 123456<br>
            📞 Телефон для входу: 0981112233<br>
            <hr>
            <a href="login.php">👤 Вхід для клієнтів →</a><br>
            <a href="index.php">🏠 На головну</a>
        </div>
    </div>
</body>
</html>