<?php
// create_admin.php
require_once 'includes/config.php';

$email = 'admin@cosmology.com';
$plain_password = 'admin123';
$hashed_password = password_hash($plain_password, PASSWORD_DEFAULT);

echo "<h2>🔧 Створення адміністратора</h2>";
echo "Email: " . $email . "<br>";
echo "Пароль (відкритий): " . $plain_password . "<br>";
echo "Хеш пароля: " . $hashed_password . "<br><br>";

try {
    // Перевіряємо чи існує адміністратор
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $existing = $stmt->fetch();
    
    if ($existing) {
        echo "⚠️ Адміністратор вже існує. Оновлюємо пароль...<br>";
        $update = $pdo->prepare("UPDATE users SET password_hash = ?, role = 'admin' WHERE email = ?");
        $update->execute([$hashed_password, $email]);
        echo "✅ Пароль оновлено!<br>";
    } else {
        echo "📝 Створюємо нового адміністратора...<br>";
        $insert = $pdo->prepare("INSERT INTO users (full_name, email, phone, password_hash, role) VALUES (?, ?, ?, ?, 'admin')");
        $insert->execute(['Головний Адміністратор', $email, '+380000000000', $hashed_password]);
        echo "✅ Адміністратора створено!<br>";
    }
    
    // Перевіряємо результат
    $stmt = $pdo->prepare("SELECT id, full_name, email, role FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    
    echo "<br><div style='background: #d4edda; padding: 15px; border-radius: 10px;'>";
    echo "<strong style='color: #155724;'>✅ ГОТОВО!</strong><br>";
    echo "📧 Email: <strong>" . $user['email'] . "</strong><br>";
    echo "👤 Ім'я: <strong>" . $user['full_name'] . "</strong><br>";
    echo "👑 Роль: <strong>" . $user['role'] . "</strong><br>";
    echo "🔑 Пароль: <strong>admin123</strong><br>";
    echo "</div>";
    
} catch (PDOException $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 10px;'>";
    echo "<strong style='color: #721c24;'>❌ ПОМИЛКА:</strong><br>";
    echo htmlspecialchars($e->getMessage());
    echo "</div>";
}

echo '<br><a href="admin_login.php" style="background: #c7a17a; color: white; padding: 10px 20px; text-decoration: none; border-radius: 10px;">→ Перейти до входу</a>';
?>