<?php
namespace App\Controllers;

use App\Services\LanguageService;

class LanguageController
{
    private $languageService;
    
    public function __construct()
    {
        $this->languageService = new LanguageService();
    }
    
    public function switch($lang)
    {
        $this->languageService->setLanguage($lang);
        
        // Повернення на попередню сторінку
        $referer = $_SERVER['HTTP_REFERER'] ?? '/';
        header("Location: $referer");
        exit;
    }
}