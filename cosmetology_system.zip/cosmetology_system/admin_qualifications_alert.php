<!-- В адмін-панелі для відображення попереджень -->
<?php
// Підключення до БД
require_once 'config.php';

// Отримуємо лікарів з простроченими кваліфікаціями
$expired_query = "SELECT u.full_name, dt.training_name, dt.valid_until, 
                         DATEDIFF(CURDATE(), dt.valid_until) as days_expired
                  FROM doctor_training dt
                  JOIN cosmetologists c ON dt.doctor_id = c.id
                  JOIN users u ON c.user_id = u.id
                  WHERE dt.is_mandatory = 1 AND dt.valid_until < CURDATE()";
$expired_result = mysqli_query($conn, $expired_query);
?>

<?php if(mysqli_num_rows($expired_result) > 0) { ?>
    <div class="alert alert-danger" style="background-color: #ffcccc; border: 2px solid red; border-radius: 10px; padding: 15px;">
        <h3 style="color: red; margin-top: 0;">❗ ТЕРМІНОВО! НЕОБХІДНО ПІДВИЩЕННЯ КВАЛІФІКАЦІЇ</h3>
        <p>Наступні лікарі мають прострочені обов'язкові кваліфікації:</p>
        <table style="width: 100%; border-collapse: collapse;">
            <thead style="background-color: #ff6666; color: white;">
                <tr><th>Лікар</th><th>Необхідна кваліфікація</th><th>Прострочено на</th></tr>
            </thead>
            <tbody>
            <?php while($row = mysqli_fetch_assoc($expired_result)) { ?>
                <tr style="background-color: #ff9999;">
                    <td style="padding: 8px;"><?php echo $row['full_name']; ?></td>
                    <td style="padding: 8px;"><?php echo $row['training_name']; ?></td>
                    <td style="padding: 8px; font-weight: bold;"><?php echo $row['days_expired']; ?> днів</td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    </div>
<?php } ?>