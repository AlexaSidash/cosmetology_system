<?php session_start(); ?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>Програма лояльності - Cosmology Beauty</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #fafafa; }
        
        .top-bar { background: #2c2c2c; color: white; padding: 8px 0; text-align: center; font-size: 14px; }
        .header { background: white; box-shadow: 0 2px 15px rgba(0,0,0,0.08); position: sticky; top: 0; z-index: 1000; }
        .nav-container { max-width: 1300px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; padding: 15px 20px; }
        .logo { font-size: 28px; font-weight: bold; color: #c7a17a; }
        .logo span { color: #2c2c2c; }
        .nav-menu { display: flex; list-style: none; gap: 25px; }
        .nav-menu a { text-decoration: none; color: #2c2c2c; font-weight: 500; }
        .nav-menu a:hover { color: #c7a17a; }
        .dropdown { position: relative; }
        .dropdown-content { display: none; position: absolute; background: white; min-width: 220px; box-shadow: 0 8px 16px rgba(0,0,0,0.1); border-radius: 8px; top: 100%; left: 0; z-index: 1; }
        .dropdown:hover .dropdown-content { display: block; }
        .dropdown-content a { display: block; padding: 12px 20px; color: #333; border-bottom: 1px solid #eee; }
        .btn-book { background: #c7a17a; color: white !important; padding: 10px 25px; border-radius: 30px; }
        .auth-buttons { display: flex; gap: 15px; }
        .auth-link { color: #2c2c2c; text-decoration: none; }
        
        .loyalty-hero {
            background: linear-gradient(135deg, #c7a17a20, #fff);
            padding: 60px 20px;
            text-align: center;
        }
        .loyalty-hero h1 { font-size: 48px; color: #2c2c2c; margin-bottom: 15px; }
        
        .loyalty-content {
            max-width: 1000px;
            margin: 50px auto;
            padding: 0 20px;
        }
        
        .bonus-card {
            background: linear-gradient(135deg, #c7a17a, #a67c52);
            color: white;
            border-radius: 20px;
            padding: 40px;
            text-align: center;
            margin-bottom: 40px;
        }
        
        .bonus-card h2 { font-size: 36px; margin-bottom: 10px; }
        .bonus-card .bonus-value { font-size: 48px; font-weight: bold; margin: 20px 0; }
        
        .rules {
            background: white;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        
        .rules h3 { color: #c7a17a; margin-bottom: 20px; font-size: 24px; }
        .rules ul { list-style: none; padding-left: 0; }
        .rules li { padding: 12px 0; border-bottom: 1px solid #eee; display: flex; align-items: center; gap: 15px; }
        .rules li:before { content: "✓"; color: #c7a17a; font-weight: bold; font-size: 20px; }
        
        .levels {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 25px;
            margin: 40px 0;
        }
        
        .level {
            background: white;
            border-radius: 15px;
            padding: 25px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            border-top: 4px solid #c7a17a;
        }
        
        .level h4 { font-size: 22px; color: #c7a17a; margin-bottom: 15px; }
        .level .discount { font-size: 32px; font-weight: bold; margin: 15px 0; }
        
        .footer {
            background: #1a1a1a;
            color: #999;
            padding: 50px 20px 30px;
            margin-top: 60px;
        }
        .footer-content {
            max-width: 1300px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
        }
        .footer-column h4 { color: white; margin-bottom: 20px; }
        .footer-column a { color: #999; text-decoration: none; display: block; margin-bottom: 10px; }
        .footer-column a:hover { color: #c7a17a; }
        .footer-bottom {
            text-align: center;
            padding-top: 30px;
            margin-top: 30px;
            border-top: 1px solid #333;
        }
        
        @media (max-width: 768px) {
            .nav-container { flex-direction: column; gap: 15px; }
            .nav-menu { flex-wrap: wrap; justify-content: center; gap: 15px; }
        }
    </style>
</head>
<body>
    <div class="top-bar">
        ✨ Нова клієнтка отримує знижку 20% на перший візит ✨
    </div>
    
    <div class="header">
        <div class="nav-container">
            <div class="logo">
                Cosmology <span>Beauty</span>
            </div>
            <ul class="nav-menu">
                <li><a href="index.php">Головна</a></li>
                <li><a href="about.php">Про нас</a></li>
                <li class="dropdown">
                    <a href="#">Прайс ▼</a>
                    <div class="dropdown-content">
                        <a href="category.php?cat=injection">Ін'єкційна косметологія</a>
                        <a href="category.php?cat=apparatus">Апаратна косметологія</a>
                        <a href="category.php?cat=laser">Лазерна косметологія</a>
                        <a href="category.php?cat=epilation">Лазерна епіляція</a>
                        <a href="category.php?cat=intimate">Інтимна косметологія</a>
                        <a href="category.php?cat=care">Доглядові процедури</a>
                        <a href="category.php?cat=dermatology">Дерматологія</a>
                    </div>
                </li>
                <li><a href="loyalty.php">Програма лояльності</a></li>
                <li><a href="doctors.php">Лікарі</a></li>
                <li><a href="booking.php" class="btn-book">Записатися</a></li>
            </ul>
            <div class="auth-buttons">
                <?php if(isset($_SESSION['user_id'])): ?>
                    <a href="admin/dashboard.php" class="auth-link">👤 <?= htmlspecialchars($_SESSION['user_name']) ?></a>
                    <a href="logout.php" class="auth-link">🚪 Вихід</a>
                <?php else: ?>
                    <a href="login.php" class="auth-link">Вхід</a>
                    <a href="register.php" class="auth-link">Реєстрація</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="loyalty-hero">
        <h1>Програма лояльності</h1>
        <p>Дбаємо про вас та ваші заощадження</p>
    </div>
    
    <div class="loyalty-content">
        <div class="bonus-card">
            <h2>✨ Ваша вигода ✨</h2>
            <div class="bonus-value">5% кешбеку</div>
            <p>нараховується на бонусний рахунок після кожної процедури</p>
            <p style="margin-top: 15px; opacity: 0.9;">1 бонус = 1 гривня</p>
        </div>
        
        <div class="rules">
            <h3>📋 Як це працює</h3>
            <ul>
                <li>Реєструйтеся в системі перед першим візитом</li>
                <li>Отримуйте 5% від вартості кожної процедури бонусами</li>
                <li>Використовуйте бонуси для оплати до 30% вартості наступних послуг</li>
                <li>Бонуси діють 12 місяців з моменту нарахування</li>
                <li>Активуйте подвійні бонуси в дні народження!</li>
            </ul>
        </div>
        
        <div class="levels">
            <div class="level">
                <h4>💎 Новачок</h4>
                <p>до 2000 грн</p>
                <div class="discount">5% бонусів</div>
            </div>
            <div class="level">
                <h4>🌟 Преміум</h4>
                <p>від 2000 до 5000 грн</p>
                <div class="discount">7% бонусів</div>
            </div>
            <div class="level">
                <h4>👑 VIP</h4>
                <p>понад 5000 грн</p>
                <div class="discount">10% бонусів</div>
            </div>
        </div>
        
        <div class="rules" style="background: #f9f5f0;">
            <h3>🎁 Додаткові переваги</h3>
            <ul>
                <li>Знижка 15% на всі послуги в місяць Вашого дня народження</li>
                <li>Безкоштовна консультація лікаря при першому візиті</li>
                <li>Ексклюзивні акції та спецпропозиції для учасників програми</li>
                <li>Подарункові сертифікати для рідних та друзів</li>
            </ul>
        </div>
    </div>
    
    <div class="footer">
        <div class="footer-content">
            <div class="footer-column">
                <h4>Cosmology Beauty</h4>
                <p>Ваша краса - наша турбота. Професійна косметологія з використанням сучасних методик та преміальних засобів.</p>
            </div>
            <div class="footer-column">
                <h4>Контакти</h4>
                <p>📍 м. Дніпро, вул. Хрещатик, 15</p>
                <p>📞 (098) 123-45-67</p>
                <p>📞 (099) 123-45-67</p>
                <p>✉️ info@cosmology-beauty.com</p>
            </div>
            <div class="footer-column">
                <h4>Години роботи</h4>
                <p>Пн-Пт: 9:00 - 20:00</p>
                <p>Сб: 10:00 - 18:00</p>
                <p>Нд: Вихідний</p>
            </div>
            <div class="footer-column">
                <h4>Соціальні мережі</h4>
                <a href="#">📷 Instagram</a>
                <a href="#">📘 Facebook</a>
                <a href="#">📱 Telegram</a>
                <a href="#">🎥 TikTok</a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>© 2026 Cosmetology Beauty. Всі права захищено.</p>
            <p>м. Дніпро, вул. Хрещатик, 15 | Тел: (098) 123-45-67</p>
        </div>
    </div>
</body>
</html>