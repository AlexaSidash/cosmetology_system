<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

$host = 'localhost';
$user = 'root';
$password = '';
$database = 'cosmetology_db';

$conn = mysqli_connect($host, $user, $password, $database);
mysqli_set_charset($conn, "utf8mb4");

// Перевірка авторизації
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Отримання параметрів фільтрації
$period = isset($_GET['period']) ? $_GET['period'] : 'month';
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : '';
$cosmetologist_id = isset($_GET['cosmetologist_id']) ? $_GET['cosmetologist_id'] : '';

// Встановлення дат
$start = date('Y-m-01');
$end = date('Y-m-t');

if ($period == 'day') {
    $start = date('Y-m-d');
    $end = date('Y-m-d');
} elseif ($period == 'week') {
    $start = date('Y-m-d', strtotime('monday this week'));
    $end = date('Y-m-d', strtotime('sunday this week'));
} elseif ($period == 'month') {
    $start = date('Y-m-01');
    $end = date('Y-m-t');
} elseif ($period == 'year') {
    $start = date('Y-01-01');
    $end = date('Y-12-31');
} elseif ($period == 'custom' && !empty($start_date) && !empty($end_date)) {
    $start = $start_date;
    $end = $end_date;
}

// Обробка премії
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['give_bonus'])) {
    $bonus_id = (int)$_POST['cosmetologist_id_bonus'];
    $bonus_amount = (float)$_POST['bonus_amount'];
    mysqli_query($conn, "UPDATE cosmetologists SET bonus = bonus + $bonus_amount WHERE id = $bonus_id");
    echo "<script>alert('Премію нараховано!'); window.location.href='admin_finance.php?period=$period&start_date=$start&end_date=$end&cosmetologist_id=$cosmetologist_id';</script>";
    exit;
}

// Отримання списку косметологів
$cosmetologists = mysqli_query($conn, "
    SELECT c.id, u.full_name as name, c.commission_percent, c.bonus 
    FROM cosmetologists c
    JOIN users u ON c.user_id = u.id
    ORDER BY u.full_name
");

$cos_list = [];
while ($row = mysqli_fetch_assoc($cosmetologists)) {
    $cos_list[] = $row;
}

// Фільтр
$where = "WHERE a.status = 'completed' AND DATE(a.appointment_datetime) BETWEEN '$start' AND '$end'";
if (!empty($cosmetologist_id)) {
    $where .= " AND a.cosmetologist_id = " . (int)$cosmetologist_id;
}

// ОСНОВНИЙ ЗАПИТ
$query = "
    SELECT 
        c.id,
        u.full_name as doctor_name,
        c.commission_percent,
        COALESCE(c.bonus, 0) as bonus,
        COUNT(DISTINCT a.id) as total_services,
        COALESCE(SUM(s.price), 0) as revenue,
        COALESCE(SUM(s.price) * c.commission_percent / 100, 0) as salary_base,
        COALESCE(SUM(s.price) * c.commission_percent / 100 + c.bonus, 0) as salary_total
    FROM appointments a
    JOIN cosmetologists c ON a.cosmetologist_id = c.id
    JOIN users u ON c.user_id = u.id
    JOIN services s ON a.service_id = s.id
    $where
    GROUP BY c.id, u.full_name, c.commission_percent, c.bonus
    ORDER BY salary_total DESC
";

$result = mysqli_query($conn, $query);

if (!$result) {
    die("Помилка SQL: " . mysqli_error($conn));
}

// Загальна статистика
$total_query = "
    SELECT 
        COALESCE(SUM(s.price), 0) as total_revenue,
        COALESCE(SUM(s.price * c.commission_percent / 100), 0) as total_salary
    FROM appointments a
    JOIN cosmetologists c ON a.cosmetologist_id = c.id
    JOIN services s ON a.service_id = s.id
    WHERE a.status = 'completed' AND DATE(a.appointment_datetime) BETWEEN '$start' AND '$end'
";

$total = mysqli_fetch_assoc(mysqli_query($conn, $total_query));

// ДІАГНОСТИКА - перевіряємо ціни в послугах
$debug_services = mysqli_query($conn, "SELECT id, name, price FROM services WHERE price > 0");
$has_prices = mysqli_num_rows($debug_services);
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>Фінанси | Cosmology</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f0eb; }
        
        .sidebar {
            width: 280px;
            background: #2c2c2c;
            color: white;
            position: fixed;
            height: 100%;
            padding: 25px 20px;
            overflow-y: auto;
        }
        .sidebar h3 { margin-bottom: 30px; color: #c7a17a; text-align: center; font-size: 24px; }
        .sidebar a {
            color: #ddd;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 15px;
            margin: 5px 0;
            border-radius: 12px;
            transition: all 0.3s;
        }
        .sidebar a:hover, .sidebar a.active { background: #c7a17a; color: white; }
        .sidebar a i { width: 24px; }
        
        .content {
            margin-left: 280px;
            padding: 30px;
        }
        
        h1 {
            color: #2c2c2c;
            margin-bottom: 25px;
            font-size: 28px;
        }
        
        .filter-card {
            background: white;
            border-radius: 20px;
            padding: 20px;
            margin-bottom: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 25px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: transform 0.2s;
        }
        .stat-card:hover { transform: translateY(-3px); }
        .stat-number {
            font-size: 32px;
            font-weight: bold;
            color: #c7a17a;
            margin-bottom: 5px;
        }
        .stat-label { color: #666; font-size: 14px; }
        
        .table-card {
            background: white;
            border-radius: 20px;
            padding: 20px;
            overflow-x: auto;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 10px;
        }
        .table-header h3 { color: #c7a17a; }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #f0e6dc;
        }
        th {
            background: #c7a17a20;
            color: #c7a17a;
            font-weight: 600;
        }
        
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: 500; }
        
        .form-control, .form-select {
            width: 100%;
            padding: 10px;
            border: 2px solid #f0e6dc;
            border-radius: 10px;
            font-size: 14px;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
        }
        .btn-primary { background: #c7a17a; color: white; }
        .btn-primary:hover { background: #a67c52; }
        .btn-success { background: #28a745; color: white; }
        .btn-success:hover { background: #218838; }
        
        .filter-row {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            align-items: flex-end;
        }
        .filter-row .form-group { margin-bottom: 0; }
        .filter-row select, .filter-row input { width: auto; min-width: 130px; }
        
        .modal {
            display: none;
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background: rgba(0,0,0,0.5);
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        .modal-content {
            background: white;
            border-radius: 20px;
            padding: 30px;
            width: 450px;
            max-width: 90%;
        }
        .modal-content h3 { margin-bottom: 20px; color: #c7a17a; }
        
        .text-right { text-align: right; }
        .text-success { color: #28a745; font-weight: bold; }
        .warning-box {
            background: #fff3cd;
            border: 1px solid #ffc107;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        
        @media (max-width: 768px) {
            .sidebar { width: 70px; padding: 20px 10px; }
            .sidebar span { display: none; }
            .content { margin-left: 70px; padding: 15px; }
            .stats-grid { grid-template-columns: repeat(3, 1fr); gap: 10px; }
            .stat-card { padding: 15px; }
            .stat-number { font-size: 20px; }
        }
    </style>
</head>
<body>

<div class="sidebar">
    <h3>✨ Cosmology</h3>
    <a href="admin_dashboard.php"><i class="bi bi-house-door-fill"></i><span>Головна</span></a>
    <a href="admin_clients.php"><i class="bi bi-people-fill"></i><span>Клієнти</span></a>
    <a href="admin_doctors.php"><i class="bi bi-person-badge-fill"></i><span>Лікарі</span></a>
    <a href="admin_services.php"><i class="bi bi-grid-3x3-gap-fill"></i><span>Послуги</span></a>
    <a href="admin_appointments.php"><i class="bi bi-calendar-check-fill"></i><span>Записи</span></a>
    <a href="admin_certificates.php"><i class="bi bi-patch-check-fill"></i><span>Сертифікати</span></a>
    <a href="admin_stock.php"><i class="bi bi-box-seam-fill"></i><span>Склад</span></a>
    <a href="admin_stock_orders.php"><i class="bi bi-cart-fill"></i><span>Замовлення</span></a>
    <a href="admin_reviews.php"><i class="bi bi-star-fill"></i><span>Відгуки</span></a>
    <a href="admin_finance.php" class="active" style="background: #c7a17a; color: white;"><i class="bi bi-graph-up"></i><span>Фінанси</span></a>
    <a href="logout.php"><i class="bi bi-box-arrow-right"></i><span>Вихід</span></a>
</div>

<div class="content">
    <h1><i class="bi bi-graph-up"></i> Фінансовий звіт</h1>
    
    <?php if(!$has_prices): ?>
    <div class="warning-box">
        ⚠️ <strong>Увага!</strong> У таблиці <strong>services</strong> немає цін або всі ціни = 0.<br>
        Будь ласка, додайте ціни для послуг в розділі <a href="admin_services.php">Послуги</a>.
    </div>
    <?php endif; ?>
    
    <div class="filter-card">
        <form method="GET" class="filter-row">
            <div class="form-group">
                <select name="period" class="form-select">
                    <option value="day" <?= $period == 'day' ? 'selected' : '' ?>>📅 День</option>
                    <option value="week" <?= $period == 'week' ? 'selected' : '' ?>>📆 Тиждень</option>
                    <option value="month" <?= $period == 'month' ? 'selected' : '' ?>>📆 Місяць</option>
                    <option value="year" <?= $period == 'year' ? 'selected' : '' ?>>📅 Рік</option>
                    <option value="custom" <?= $period == 'custom' ? 'selected' : '' ?>>⚙️ Свій період</option>
                </select>
            </div>
            <div class="form-group">
                <input type="date" name="start_date" class="form-control" value="<?= $start ?>">
            </div>
            <div class="form-group">
                <input type="date" name="end_date" class="form-control" value="<?= $end ?>">
            </div>
            <div class="form-group">
                <select name="cosmetologist_id" class="form-select">
                    <option value="">👨‍⚕️ Всі лікарі</option>
                    <?php foreach($cos_list as $c): ?>
                        <option value="<?= $c['id'] ?>" <?= $cosmetologist_id == $c['id'] ? 'selected' : '' ?>><?= htmlspecialchars($c['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary">🔍 Показати</button>
            </div>
        </form>
    </div>
    
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-number"><?= number_format($total['total_revenue'] ?? 0, 0) ?> ₴</div>
            <div class="stat-label">💰 Загальна виручка</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?= number_format($total['total_salary'] ?? 0, 0) ?> ₴</div>
            <div class="stat-label">💸 Витрати на ЗП</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?= number_format(($total['total_revenue'] ?? 0) - ($total['total_salary'] ?? 0), 0) ?> ₴</div>
            <div class="stat-label">📊 Прибуток закладу</div>
        </div>
    </div>
    
    <div class="table-card">
        <div class="table-header">
            <h3>💼 Розрахунок заробітної плати</h3>
            <button class="btn btn-success" onclick="document.getElementById('bonusModal').style.display='flex'">
                🎁 Нарахувати премію
            </button>
        </div>
        
        <?php if(isset($result) && mysqli_num_rows($result) > 0): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Лікар</th>
                    <th class="text-right">Послуг</th>
                    <th class="text-right">Виручка</th>
                    <th class="text-right">%</th>
                    <th class="text-right">Базова ЗП</th>
                    <th class="text-right">Премія</th>
                    <th class="text-right">До виплати</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><strong><?= htmlspecialchars($row['doctor_name']) ?></strong></td>
                    <td class="text-right"><?= $row['total_services'] ?></td>
                    <td class="text-right"><?= number_format($row['revenue'], 0) ?> ₴</span>
                    <td class="text-right"><?= $row['commission_percent'] ?>%</span>
                    <td class="text-right"><?= number_format($row['salary_base'], 0) ?> ₴</span>
                    <td class="text-right"><?= number_format($row['bonus'], 0) ?> ₴</span>
                    <td class="text-right text-success"><?= number_format($row['salary_total'], 0) ?> ₴</span>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <?php else: ?>
            <p style="text-align: center; color: #999; padding: 40px;">
                📭 Немає завершених записів за вибраний період
            </p>
        <?php endif; ?>
    </div>
</div>

<!-- Модальне вікно -->
<div id="bonusModal" class="modal">
    <div class="modal-content">
        <h3>🎁 Нарахувати премію</h3>
        <form method="POST">
            <div class="form-group">
                <label>👨‍⚕️ Лікар</label>
                <select name="cosmetologist_id_bonus" class="form-select" required>
                    <option value="">Виберіть лікаря</option>
                    <?php foreach($cos_list as $c): ?>
                        <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>💰 Сума премії (₴)</label>
                <input type="number" name="bonus_amount" step="0.01" class="form-control" required>
            </div>
            <div class="form-group">
                <label>📝 Причина</label>
                <textarea name="bonus_reason" class="form-control" rows="2" placeholder="За перевиконання плану, високу якість роботи..."></textarea>
            </div>
            <div style="display: flex; gap: 10px; margin-top: 20px;">
                <button type="submit" name="give_bonus" class="btn btn-success">✅ Нарахувати</button>
                <button type="button" class="btn btn-primary" onclick="document.getElementById('bonusModal').style.display='none'">❌ Скасувати</button>
            </div>
        </form>
    </div>
</div>

<script>
    window.onclick = function(event) {
        let modal = document.getElementById('bonusModal');
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    }
</script>

</body>
</html>