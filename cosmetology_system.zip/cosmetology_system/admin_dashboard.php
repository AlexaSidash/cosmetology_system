 <?php
// admin_dashboard.php
session_start();
session_start();
require_once 'includes/config.php';

// Перевірка підключення до БД
if (!isset($pdo) || !$pdo) {
    die('Помилка підключення до бази даних. Перевірте файл includes/config.php');
}

// Перевірка авторизації адміністратора
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin_login.php');
    exit;
}

// Функція для безпечного отримання даних
function __($key) {
    $translations = [
        'nav_home' => 'Головна',
        'about_us' => 'Про нас',
        'price_list' => 'Прайс',
        'loyalty_program' => 'Програма лояльності',
        'nav_doctors' => 'Лікарі',
        'btn_book' => 'Записатися',
        'nav_admin' => 'Адмін',
        'nav_logout' => 'Вихід',
        'nav_login' => 'Вхід',
        'register' => 'Реєстрація',
        'title_home' => 'Головна',
        'btn_book_online' => 'Записатися онлайн',
        'hero_text' => 'Професійна косметологія',
        'footer_copyright' => 'Всі права захищено',
    ];
    return $translations[$key] ?? $key;
}

$current_lang = 'uk';

// Отримуємо базову статистику для швидкого відображення
try {
    // Кількість клієнтів
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM users WHERE role = 'client'");
    $clients_count = $stmt->fetch()['count'] ?? 0;
} catch (PDOException $e) {
    $clients_count = 0;
}

try {
    // Кількість лікарів
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM users WHERE role = 'cosmetologist'");
    $doctors_count = $stmt->fetch()['count'] ?? 0;
} catch (PDOException $e) {
    $doctors_count = 0;
}

try {
    // Кількість послуг
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM services WHERE is_active = 1");
    $services_count = $stmt->fetch()['count'] ?? 0;
} catch (PDOException $e) {
    $services_count = 0;
}

try {
    // Записи, що очікують підтвердження
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM appointments WHERE status = 'pending'");
    $pending_count = $stmt->fetch()['count'] ?? 0;
} catch (PDOException $e) {
    $pending_count = 0;
}

try {
    // Записи на сьогодні
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM appointments WHERE DATE(appointment_datetime) = CURDATE()");
    $today_count = $stmt->fetch()['count'] ?? 0;
} catch (PDOException $e) {
    $today_count = 0;
}

try {
    // Виручка за місяць
    $stmt = $pdo->query("
        SELECT SUM(s.price) as total 
        FROM appointments a 
        JOIN services s ON a.service_id = s.id 
        WHERE MONTH(a.appointment_datetime) = MONTH(CURDATE()) 
        AND YEAR(a.appointment_datetime) = YEAR(CURDATE())
        AND a.status = 'completed'
    ");
    $monthly_revenue = $stmt->fetch()['total'] ?? 0;
} catch (PDOException $e) {
    $monthly_revenue = 0;
}

try {
    // Всього записів
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM appointments");
    $total_appointments = $stmt->fetch()['count'] ?? 0;
} catch (PDOException $e) {
    $total_appointments = 0;
}

try {
    // Товари на складі що закінчуються
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM stock_items WHERE quantity <= min_quantity");
    $low_stock_count = $stmt->fetch()['count'] ?? 0;
} catch (PDOException $e) {
    $low_stock_count = 0;
}

// Пошук клієнта
$search_result = null;
$search_error = '';

if (isset($_GET['search_client'])) {
    $search = trim($_GET['search'] ?? '');
    if (!empty($search)) {
        try {
            $stmt = $pdo->prepare("
                SELECT * FROM users 
                WHERE role = 'client' 
                AND (full_name LIKE ? OR email LIKE ? OR phone LIKE ?)
                LIMIT 5
            ");
            $stmt->execute(["%$search%", "%$search%", "%$search%"]);
            $search_result = $stmt->fetchAll();
            
            if (count($search_result) == 0) {
                $search_error = "Клієнта не знайдено. Бажаєте зареєструвати нового?";
            }
        } catch (PDOException $e) {
            $search_result = [];
        }
    }
}

// Сьогоднішні записи з деталями
$today_appointments = [];
try {
    $today_appointments = $pdo->query("
        SELECT a.*, u.full_name as client_name, u.phone as client_phone, 
               s.name as service_name, s.price, 
               COALESCE(doc.full_name, 'Не призначено') as doctor_name
        FROM appointments a
        JOIN users u ON a.client_id = u.id
        JOIN services s ON a.service_id = s.id
        LEFT JOIN cosmetologists c ON a.cosmetologist_id = c.id
        LEFT JOIN users doc ON c.user_id = doc.id
        WHERE DATE(a.appointment_datetime) = CURDATE()
        ORDER BY a.appointment_datetime ASC
    ")->fetchAll();
} catch (PDOException $e) {
    $today_appointments = [];
}

// Отримуємо всіх клієнтів для швидкого вибору
$clients = [];
try {
    $clients = $pdo->query("SELECT id, full_name, email, phone FROM users WHERE role = 'client' ORDER BY full_name")->fetchAll();
} catch (PDOException $e) {
    $clients = [];
}

// Отримуємо лікарів
$doctors = [];
try {
    $doctors = $pdo->query("
        SELECT c.id, u.full_name, COALESCE(c.rating, 0) as rating 
        FROM cosmetologists c 
        JOIN users u ON c.user_id = u.id
    ")->fetchAll();
} catch (PDOException $e) {
    $doctors = [];
}

// Отримуємо послуги
$services = [];
try {
    $services = $pdo->query("SELECT id, name, price, duration_minutes FROM services WHERE is_active = 1")->fetchAll();
} catch (PDOException $e) {
    $services = [];
}
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Адмін-панель | Cosmology Beauty</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f0eb; }
        
        .sidebar {
            width: 280px;
            background: #2c2c2c;
            color: white;
            position: fixed;
            height: 100%;
            padding: 25px 20px;
            overflow-y: auto;
            z-index: 100;
        }
        .sidebar h3 { margin-bottom: 30px; color: #c7a17a; text-align: center; font-size: 24px; }
        .sidebar a {
            color: #ddd;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 15px;
            margin: 5px 0;
            border-radius: 12px;
            transition: all 0.3s;
        }
        .sidebar a:hover, .sidebar a.active { background: #c7a17a; color: white; }
        .sidebar a i { width: 24px; }
        
        .content {
            margin-left: 280px;
            padding: 30px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 20px;
            transition: transform 0.3s, box-shadow 0.3s;
            cursor: pointer;
            border: 1px solid rgba(0,0,0,0.05);
        }
        .stat-card:hover { transform: translateY(-5px); box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
        .stat-number { font-size: 32px; font-weight: bold; color: #c7a17a; }
        .stat-label { font-size: 13px; color: #666; margin-top: 5px; }
        .stat-icon { font-size: 2rem; color: #c7a17a; opacity: 0.5; }
        
        .card {
            background: white;
            border-radius: 20px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .card h3 {
            color: #c7a17a;
            margin-bottom: 20px;
            border-bottom: 2px solid #f0e6dc;
            padding-bottom: 10px;
        }
        
        .form-control {
            width: 100%;
            padding: 10px;
            border: 2px solid #f0e6dc;
            border-radius: 10px;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
        }
        .btn-primary { background: #c7a17a; color: white; }
        .btn-primary:hover { background: #a67c52; }
        .btn-danger { background: #dc3545; color: white; }
        .btn-danger:hover { background: #c82333; }
        .btn-success { background: #28a745; color: white; }
        .btn-success:hover { background: #218838; }
        .btn-info { background: #17a2b8; color: white; }
        .btn-info:hover { background: #138496; }
        
        .status-pending { color: #ffc107; font-weight: bold; }
        .status-confirmed { color: #28a745; font-weight: bold; }
        .status-completed { color: #17a2b8; font-weight: bold; }
        .status-cancelled { color: #dc3545; font-weight: bold; }
        
        .table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #f0e6dc; }
        th { color: #c7a17a; border-bottom: 2px solid #c7a17a; }
        
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        .modal-content {
            background: white;
            border-radius: 20px;
            padding: 30px;
            max-width: 500px;
            width: 90%;
        }
        
        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1100;
            padding: 15px 20px;
            border-radius: 10px;
            animation: slideIn 0.3s ease;
        }
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        .notification.success { background: #d4edda; color: #155724; border-left: 4px solid #28a745; }
        .notification.error { background: #f8d7da; color: #721c24; border-left: 4px solid #dc3545; }
        
        @media (max-width: 768px) {
            .sidebar { width: 70px; padding: 20px 10px; }
            .sidebar a span:not(.icon) { display: none; }
            .content { margin-left: 70px; }
        }
    </style>
</head>
<body>
    
<div class="sidebar">
    <h3>✨ Cosmology</h3>
    <a href="admin_dashboard.php" class="active"><i class="bi bi-house-door-fill"></i><span>Головна</span></a>
    <a href="admin_clients.php"><i class="bi bi-people-fill"></i><span>Клієнти</span></a>
    <a href="admin_doctors.php"><i class="bi bi-person-badge-fill"></i><span>Лікарі</span></a>
    <a href="admin_services.php"><i class="bi bi-grid-3x3-gap-fill"></i><span>Послуги</span></a>
    <a href="admin_appointments.php"><i class="bi bi-calendar-check-fill"></i><span>Записи</span></a>
    <a href="admin_certificates.php"><i class="bi bi-patch-check-fill"></i><span>Сертифікати</span></a>
    <a href="admin_stock.php"><i class="bi bi-box-seam-fill"></i><span>Склад</span></a>
    <a href="admin_stock_orders.php"><i class="bi bi-cart-fill"></i><span>Замовлення</span></a>
    <a href="admin_reviews.php"><i class="bi bi-star-fill"></i><span>Відгуки</span></a>
    <a href="admin_finance.php"><i class="bi bi-graph-up"></i><span>Фінанси</span></a>
    <a href="logout.php"><i class="bi bi-box-arrow-right"></i><span>Вихід</span></a>
</div>
    
<div class="content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1><i class="bi bi-speedometer2"></i> Головна панель адміністратора</h1>
            <p class="text-muted">Вітаємо, <?= htmlspecialchars($_SESSION['admin_name'] ?? $_SESSION['user_name'] ?? 'Адміністратор') ?>!</p>
        </div>
    </div>
    
    <!-- Статистика -->
    <div class="stats-grid">
        <div class="stat-card" onclick="window.location.href='admin_clients.php'">
            <div class="d-flex justify-content-between">
                <div>
                    <div class="stat-number"><?= $clients_count ?></div>
                    <div class="stat-label">👥 Всього клієнтів</div>
                </div>
                <div class="stat-icon"><i class="bi bi-people"></i></div>
            </div>
        </div>
        <div class="stat-card" onclick="window.location.href='admin_doctors.php'">
            <div class="d-flex justify-content-between">
                <div>
                    <div class="stat-number"><?= $doctors_count ?></div>
                    <div class="stat-label">👩‍⚕️ Лікарів</div>
                </div>
                <div class="stat-icon"><i class="bi bi-person-badge"></i></div>
            </div>
        </div>
        <div class="stat-card" onclick="window.location.href='admin_services.php'">
            <div class="d-flex justify-content-between">
                <div>
                    <div class="stat-number"><?= $services_count ?></div>
                    <div class="stat-label">💆‍♀️ Послуг</div>
                </div>
                <div class="stat-icon"><i class="bi bi-grid-3x3-gap-fill"></i></div>
            </div>
        </div>
        <div class="stat-card" onclick="window.location.href='admin_appointments.php'">
            <div class="d-flex justify-content-between">
                <div>
                    <div class="stat-number"><?= $total_appointments ?></div>
                    <div class="stat-label">📋 Всього записів</div>
                </div>
                <div class="stat-icon"><i class="bi bi-calendar-check"></i></div>
            </div>
        </div>
        <div class="stat-card" onclick="window.location.href='admin_appointments.php?status=pending'">
            <div class="d-flex justify-content-between">
                <div>
                    <div class="stat-number"><?= $pending_count ?></div>
                    <div class="stat-label">⏳ Очікує підтвердження</div>
                </div>
                <div class="stat-icon"><i class="bi bi-hourglass-split"></i></div>
            </div>
        </div>
        <div class="stat-card" onclick="window.location.href='admin_appointments.php?date=today'">
            <div class="d-flex justify-content-between">
                <div>
                    <div class="stat-number"><?= $today_count ?></div>
                    <div class="stat-label">📅 Записів сьогодні</div>
                </div>
                <div class="stat-icon"><i class="bi bi-calendar-day"></i></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="d-flex justify-content-between">
                <div>
                    <div class="stat-number"><?= number_format($monthly_revenue, 0) ?> ₴</div>
                    <div class="stat-label">💰 Виручка за місяць</div>
                </div>
                <div class="stat-icon"><i class="bi bi-coin"></i></div>
            </div>
        </div>
        <div class="stat-card" onclick="window.location.href='admin_stock.php?filter=low'">
            <div class="d-flex justify-content-between">
                <div>
                    <div class="stat-number"><?= $low_stock_count ?></div>
                    <div class="stat-label">⚠️ Товарів мало</div>
                </div>
                <div class="stat-icon"><i class="bi bi-exclamation-triangle"></i></div>
            </div>
        </div>
    </div>
    
    <!-- Прості графи (без API) -->
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <h3><i class="bi bi-pie-chart"></i> Статуси записів</h3>
                <canvas id="statusChart" height="250"></canvas>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <h3><i class="bi bi-star-fill"></i> Інформація</h3>
                <div class="alert alert-info">
                    <strong>📊 Загальна статистика:</strong><br>
                    - Всього клієнтів: <?= $clients_count ?><br>
                    - Всього записів: <?= $total_appointments ?><br>
                    - Виручка за місяць: <?= number_format($monthly_revenue, 0) ?> ₴<br>
                    - Записів сьогодні: <?= $today_count ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Форма створення запису -->
    <div class="card">
        <h3><i class="bi bi-plus-circle"></i> Створити запис для клієнта</h3>
        <form method="GET" action="">
            <div class="row">
                <div class="col-md-10">
                    <input type="text" name="search" class="form-control" placeholder="🔍 Пошук клієнта (за іменем, email або телефоном)..." value="<?= htmlspecialchars($_GET['search'] ?? '') ?>">
                </div>
                <div class="col-md-2">
                    <button type="submit" name="search_client" class="btn btn-primary w-100">🔍 Знайти</button>
                </div>
            </div>
        </form>
        
        <?php if($search_result !== null): ?>
            <?php if(count($search_result) > 0): ?>
                <div class="mt-3" style="background: #f9f5f0; padding: 15px; border-radius: 10px;">
                    <strong>📋 Знайдені клієнти:</strong>
                    <?php foreach($search_result as $client): ?>
                        <div class="d-flex justify-content-between align-items-center p-3 border-bottom">
                            <div>
                                <strong><?= htmlspecialchars($client['full_name']) ?></strong><br>
                                <small class="text-muted">📧 <?= htmlspecialchars($client['email']) ?> | 📞 <?= htmlspecialchars($client['phone']) ?></small>
                            </div>
                            <button class="btn btn-primary btn-sm" onclick="alert('Функція створення запису в розробці. Використовуйте admin_appointments.php')">
                                📅 Записати
                            </button>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="alert alert-warning mt-3">
                    ❌ <?= $search_error ?>
                    <a href="register.php" class="btn btn-success btn-sm ms-3">➕ Зареєструвати нового клієнта</a>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    
    <!-- Сьогоднішні записи -->
    <div class="card">
        <h3><i class="bi bi-calendar-today"></i> Сьогоднішні записи (<?= date('d.m.Y') ?>)</h3>
        <?php if(count($today_appointments) > 0): ?>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr><th>Час</th><th>Клієнт</th><th>Телефон</th><th>Лікар</th><th>Послуга</th><th>Сума</th><th>Статус</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach($today_appointments as $a): ?>
                        <tr>
                            <td><strong><?= date('H:i', strtotime($a['appointment_datetime'])) ?></strong></td>
                            <td><?= htmlspecialchars($a['client_name']) ?></td>
                            <td><?= htmlspecialchars($a['client_phone']) ?></td>
                            <td><?= htmlspecialchars($a['doctor_name']) ?></td>
                            <td><?= htmlspecialchars($a['service_name']) ?></td>
                            <td><?= number_format($a['price'], 0) ?> ₴</td>
                            <td class="status-<?= $a['status'] ?>">
                                <?php
                                $statusLabels = [
                                    'pending' => '⏳ Очікує',
                                    'confirmed' => '✅ Підтверджено',
                                    'completed' => '✔️ Виконано',
                                    'cancelled' => '❌ Скасовано'
                                ];
                                echo $statusLabels[$a['status']] ?? $a['status'];
                                ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-muted">Сьогодні записів немає</p>
        <?php endif; ?>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
// Проста кругова діаграма статусів
const statusCtx = document.getElementById('statusChart').getContext('2d');
const statusChart = new Chart(statusCtx, {
    type: 'pie',
    data: {
        labels: ['Очікує', 'Підтверджено', 'Виконано', 'Скасовано'],
        datasets: [{
            data: [<?= $pending_count ?>, <?= $total_appointments - $pending_count - $today_count ?? 0 ?>, <?= $today_count ?>, 0],
            backgroundColor: ['#ffc107', '#28a745', '#17a2b8', '#dc3545'],
            borderWidth: 0
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: { position: 'bottom' }
        }
    }
});

function showNotification(message, type) {
    const notification = $('<div class="notification ' + type + '">' + message + '</div>');
    $('body').append(notification);
    setTimeout(() => notification.fadeOut(300, function() { $(this).remove(); }), 3000);
}
</script>

</body>
</html> 