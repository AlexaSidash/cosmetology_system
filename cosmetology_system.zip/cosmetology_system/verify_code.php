<?php
session_start();
require_once 'includes/config.php';

header('Content-Type: application/json');

$code = $_POST['code'] ?? '';

if (empty($code)) {
    echo json_encode(['success' => false, 'error' => 'Введіть код підтвердження']);
    exit;
}

if (!isset($_SESSION['temp_user'])) {
    echo json_encode(['success' => false, 'error' => 'Сесія не знайдена. Спробуйте зареєструватися знову']);
    exit;
}

$temp_user = $_SESSION['temp_user'];
$saved_code = $temp_user['verification_code'] ?? '';

if ($code != $saved_code) {
    echo json_encode(['success' => false, 'error' => 'Невірний код підтвердження']);
    exit;
}

// Перевіряємо, чи код ще дійсний
try {
    $stmt = $pdo->prepare("SELECT * FROM verification_codes WHERE email = ? AND code = ? AND is_used = FALSE AND expires_at > NOW()");
    $stmt->execute([$temp_user['email'], $code]);
    $valid_code = $stmt->fetch();
} catch (PDOException $e) {
    // Якщо таблиці немає, пропускаємо перевірку
    $valid_code = true;
}

if (!$valid_code && $valid_code !== true) {
    echo json_encode(['success' => false, 'error' => 'Код застарів. Надішліть новий код']);
    exit;
}

if ($valid_code !== true) {
    // Позначаємо код як використаний
    $stmt = $pdo->prepare("UPDATE verification_codes SET is_used = TRUE WHERE id = ?");
    $stmt->execute([$valid_code['id']]);
}

// Перевіряємо, чи email вже існує (ще раз перед реєстрацією)
$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
$stmt->execute([$temp_user['email']]);
if ($stmt->fetch()) {
    echo json_encode(['success' => false, 'error' => 'Такий email вже зареєстровано']);
    exit;
}

// Реєструємо користувача
$stmt = $pdo->prepare("INSERT INTO users (full_name, email, phone, password_hash, role, bonus_points, created_at) VALUES (?, ?, ?, ?, 'client', 100, NOW())");
$result = $stmt->execute([
    $temp_user['full_name'],
    $temp_user['email'],
    $temp_user['phone'],
    $temp_user['password']
]);

if (!$result) {
    echo json_encode(['success' => false, 'error' => 'Помилка реєстрації. Спробуйте пізніше.']);
    exit;
}

$user_id = $pdo->lastInsertId();

// Автоматичний вхід
$_SESSION['user_id'] = $user_id;
$_SESSION['user_name'] = $temp_user['full_name'];
$_SESSION['user_role'] = 'client';
$_SESSION['user_email'] = $temp_user['email'];

// Додаємо вітальне сповіщення
try {
    $stmt = $pdo->prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (?, 'Ласкаво просимо!', 'Дякуємо за реєстрацію в Cosmology Beauty! Ви отримали 100 бонусних балів на перший візит.', 'info')");
    $stmt->execute([$user_id]);
} catch (PDOException $e) {
    // Якщо таблиці notifications немає - ігноруємо
}

// Очищаємо тимчасові дані
unset($_SESSION['temp_user']);
unset($_SESSION['verification_method']);

echo json_encode(['success' => true]);
?>