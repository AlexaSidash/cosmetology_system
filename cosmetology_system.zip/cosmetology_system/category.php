<?php
session_start();
require_once 'includes/config.php';

$category = $_GET['cat'] ?? 'all';
$search = $_GET['search'] ?? '';
$sort = $_GET['sort'] ?? 'name_asc';
$min_price = $_GET['min_price'] ?? '';
$max_price = $_GET['max_price'] ?? '';

$category_names = [
    'all' => 'Всі послуги',
    'injection' => 'Ін\'єкційна косметологія',
    'apparatus' => 'Апаратна косметологія',
    'laser' => 'Лазерна косметологія',
    'epilation' => 'Лазерна епіляція',
    'intimate' => 'Інтимна косметологія',
    'care' => 'Доглядові процедури',
    'dermatology' => 'Дерматологія'
];

$current_category_name = $category_names[$category] ?? 'Всі послуги';

// Будуємо SQL запит з фільтрами
$sql = "SELECT * FROM services WHERE is_active = 1";
$params = [];

// Пошук за назвою
if (!empty($search)) {
    $sql .= " AND name LIKE ?";
    $params[] = "%$search%";
}

// Фільтр за ціною
if ($min_price !== '') {
    $sql .= " AND price >= ?";
    $params[] = (float)$min_price;
}
if ($max_price !== '') {
    $sql .= " AND price <= ?";
    $params[] = (float)$max_price;
}

// Сортування
switch ($sort) {
    case 'price_asc':
        $sql .= " ORDER BY price ASC";
        break;
    case 'price_desc':
        $sql .= " ORDER BY price DESC";
        break;
    case 'name_asc':
        $sql .= " ORDER BY name ASC";
        break;
    case 'name_desc':
        $sql .= " ORDER BY name DESC";
        break;
    case 'duration_asc':
        $sql .= " ORDER BY duration_minutes ASC";
        break;
    default:
        $sql .= " ORDER BY name ASC";
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$services = $stmt->fetchAll();

// Отримуємо мінімальну та максимальну ціну
$priceStats = $pdo->query("SELECT MIN(price) as min_price, MAX(price) as max_price FROM services WHERE is_active = 1")->fetch();
$minPriceAll = floor($priceStats['min_price'] ?? 0);
$maxPriceAll = ceil($priceStats['max_price'] ?? 10000);

// Фотографії для послуг (замість емодзі)
$servicePhotos = [
    1 => 'https://www.gravimed.com.ua/wp-content/uploads/2020/12/laser-1.jpg',
    2 => 'https://comfortclinic.com.ua/wp-content/uploads/2021/12/rfl_1.jpeg',
    3 => 'https://vidnova.ua/wp-content/uploads/2017/11/protsess-inektsii-ukola-krasoty.jpg',
    4 => 'https://slim.ua/images/lazernoe-udalenie-sosudov-v-kieve-2.jpg',
    5 => 'https://comfortclinic.com.ua/wp-content/uploads/2021/12/rfl_1.jpeg',
    6 => 'https://images.pexels.com/photos/3779706/pexels-photo-3779706.jpeg?w=300&h=200&fit=crop',
    7 => 'https://images.pexels.com/photos/4506103/pexels-photo-4506103.jpeg?w=300&h=200&fit=crop',
    8 => 'https://images.pexels.com/photos/4348405/pexels-photo-4348405.jpeg?w=300&h=200&fit=crop',
    9 => 'https://images.pexels.com/photos/3825540/pexels-photo-3825540.jpeg?w=300&h=200&fit=crop',
    10 => 'https://images.pexels.com/photos/6686186/pexels-photo-6686186.jpeg?w=300&h=200&fit=crop',
];
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $current_category_name ?> - Cosmology Beauty</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #fafafa; }
        
        .top-bar { background: #2c2c2c; color: white; padding: 8px 0; font-size: 14px; text-align: center; }
        .header { background: white; box-shadow: 0 2px 15px rgba(0,0,0,0.08); position: sticky; top: 0; z-index: 1000; }
        .nav-container { max-width: 1300px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; padding: 15px 20px; flex-wrap: wrap; gap: 15px; }
        .logo { font-size: 28px; font-weight: bold; color: #c7a17a; }
        .logo span { color: #2c2c2c; }
        .nav-menu { display: flex; list-style: none; gap: 25px; flex-wrap: wrap; }
        .nav-menu a { text-decoration: none; color: #2c2c2c; font-weight: 500; }
        .nav-menu a:hover { color: #c7a17a; }
        .dropdown { position: relative; }
        .dropdown-content { display: none; position: absolute; background: white; min-width: 220px; box-shadow: 0 8px 16px rgba(0,0,0,0.1); border-radius: 8px; top: 100%; left: 0; z-index: 1; }
        .dropdown:hover .dropdown-content { display: block; }
        .dropdown-content a { display: block; padding: 12px 20px; color: #333; }
        .btn-book { background: #c7a17a; color: white !important; padding: 10px 25px; border-radius: 30px; }
        .auth-buttons { display: flex; gap: 15px; align-items: center; }
        .auth-link { color: #2c2c2c; text-decoration: none; }
        
        .category-hero {
            background: linear-gradient(135deg, #c7a17a20, #fff);
            padding: 40px 20px;
            text-align: center;
        }
        .category-hero h1 { font-size: 48px; color: #2c2c2c; margin-bottom: 15px; }
        .category-hero p { color: #666; font-size: 18px; }
        
        .catalog-layout {
            max-width: 1300px;
            margin: 40px auto;
            padding: 0 20px;
            display: grid;
            grid-template-columns: 280px 1fr;
            gap: 30px;
        }
        
        @media (max-width: 768px) {
            .catalog-layout { grid-template-columns: 1fr; }
        }
        
        /* Фільтри */
        .filters-sidebar {
            background: white;
            border-radius: 20px;
            padding: 25px;
            height: fit-content;
            position: sticky;
            top: 100px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.05);
        }
        
        .filter-title {
            font-size: 18px;
            font-weight: 600;
            color: #2c2c2c;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #f0e6dc;
        }
        
        .search-box { margin-bottom: 25px; }
        .search-box input {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #f0e6dc;
            border-radius: 40px;
            font-size: 14px;
        }
        .search-box input:focus { outline: none; border-color: #c7a17a; }
        
        .price-filter { margin-bottom: 25px; }
        .price-inputs { display: flex; gap: 10px; margin-top: 10px; }
        .price-inputs input {
            width: 50%;
            padding: 10px;
            border: 2px solid #f0e6dc;
            border-radius: 12px;
        }
        
        .sort-select {
            width: 100%;
            padding: 12px;
            border: 2px solid #f0e6dc;
            border-radius: 12px;
            margin-bottom: 20px;
        }
        
        .btn-filter {
            background: #c7a17a;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 40px;
            width: 100%;
            font-weight: 600;
            margin-bottom: 10px;
        }
        .btn-reset {
            background: #f0e6dc;
            color: #2c2c2c;
            border: none;
            padding: 12px;
            border-radius: 40px;
            width: 100%;
            text-decoration: none;
            display: block;
            text-align: center;
        }
        
        .services-count {
            margin-bottom: 20px;
            color: #666;
        }
        .services-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 25px;
        }
        
        .service-card {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            transition: transform 0.3s;
        }
        .service-card:hover { transform: translateY(-5px); }
        
        .service-image {
            width: 100%;
            height: 200px;
            overflow: hidden;
        }
        .service-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s;
        }
        .service-card:hover .service-image img {
            transform: scale(1.05);
        }
        
        .service-content {
            padding: 20px;
            text-align: center;
        }
        .service-content h3 {
            font-size: 20px;
            color: #2c2c2c;
            margin-bottom: 10px;
        }
        .service-price {
            font-size: 28px;
            font-weight: bold;
            color: #c7a17a;
            margin: 10px 0;
        }
        .service-duration {
            color: #666;
            font-size: 14px;
            margin-bottom: 15px;
        }
        .btn-service {
            background: #c7a17a;
            color: white;
            padding: 10px 25px;
            border-radius: 30px;
            text-decoration: none;
            display: inline-block;
            transition: background 0.3s;
        }
        .btn-service:hover { background: #a67c52; color: white; }
        
        .no-results {
            text-align: center;
            padding: 50px;
            background: white;
            border-radius: 20px;
        }
        
        .footer {
            background: #1a1a1a;
            color: #999;
            padding: 50px 20px 30px;
            margin-top: 60px;
        }
        .footer-content {
            max-width: 1300px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
        }
        .footer-column h4 { color: white; margin-bottom: 20px; }
        .footer-column a { color: #999; text-decoration: none; display: block; margin-bottom: 10px; }
        .footer-column a:hover { color: #c7a17a; }
        .footer-bottom {
            text-align: center;
            padding-top: 30px;
            margin-top: 30px;
            border-top: 1px solid #333;
        }
    </style>
</head>
<body>
    <div class="top-bar">✨ Нова клієнтка отримує знижку 20% на перший візит ✨</div>
    
    <div class="header">
        <div class="nav-container">
            <div class="logo">Cosmology <span>Beauty</span></div>
            <ul class="nav-menu">
                <li><a href="index.php">Головна</a></li>
                <li><a href="about.php">Про нас</a></li>
                <li class="dropdown">
                    <a href="#">Прайс ▼</a>
                    <div class="dropdown-content">
                        <a href="category.php?cat=all">Всі послуги</a>
                        <a href="category.php?cat=injection">Ін'єкційна косметологія</a>
                        <a href="category.php?cat=apparatus">Апаратна косметологія</a>
                        <a href="category.php?cat=laser">Лазерна косметологія</a>
                        <a href="category.php?cat=epilation">Лазерна епіляція</a>
                        <a href="category.php?cat=intimate">Інтимна косметологія</a>
                        <a href="category.php?cat=care">Доглядові процедури</a>
                        <a href="category.php?cat=dermatology">Дерматологія</a>
                    </div>
                </li>
                <li><a href="loyalty.php">Програма лояльності</a></li>
                <li><a href="doctors.php">Лікарі</a></li>
                <li><a href="booking.php" class="btn-book">Записатися</a></li>
            </ul>
            <div class="auth-buttons">
                <?php if(isset($_SESSION['user_id'])): ?>
                    <a href="client_cabinet.php" class="auth-link">👤 <?= htmlspecialchars($_SESSION['user_name'] ?? 'Користувач') ?></a>
                    <a href="logout.php" class="auth-link">🚪 Вихід</a>
                <?php else: ?>
                    <a href="login.php" class="auth-link">🔑 Вхід</a>
                    <a href="register.php" class="auth-link">📝 Реєстрація</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="category-hero">
        <h1><?= $current_category_name ?></h1>
        <p>Професійні послуги від сертифікованих спеціалістів</p>
    </div>
    
    <div class="catalog-layout">
        <!-- Бокова панель фільтрів -->
        <div class="filters-sidebar">
            <form method="GET" action="">
                <input type="hidden" name="cat" value="<?= htmlspecialchars($category) ?>">
                
                <div class="filter-title">🔍 Пошук</div>
                <div class="search-box">
                    <input type="text" name="search" placeholder="Назва послуги..." value="<?= htmlspecialchars($search) ?>">
                </div>
                
                <div class="filter-title">💰 Фільтр за ціною</div>
                <div class="price-filter">
                    <div class="price-inputs">
                        <input type="number" name="min_price" placeholder="Від" value="<?= htmlspecialchars($min_price) ?>">
                        <input type="number" name="max_price" placeholder="До" value="<?= htmlspecialchars($max_price) ?>">
                    </div>
                </div>
                
                <div class="filter-title">📊 Сортування</div>
                <select name="sort" class="sort-select">
                    <option value="name_asc" <?= $sort == 'name_asc' ? 'selected' : '' ?>>За назвою (А-Я)</option>
                    <option value="name_desc" <?= $sort == 'name_desc' ? 'selected' : '' ?>>За назвою (Я-А)</option>
                    <option value="price_asc" <?= $sort == 'price_asc' ? 'selected' : '' ?>>За ціною (від низької до високої)</option>
                    <option value="price_desc" <?= $sort == 'price_desc' ? 'selected' : '' ?>>За ціною (від високої до низької)</option>
                    <option value="duration_asc" <?= $sort == 'duration_asc' ? 'selected' : '' ?>>За тривалістю (спочатку короткі)</option>
                </select>
                
                <button type="submit" class="btn-filter">🔍 Застосувати</button>
                <a href="category.php?cat=<?= $category ?>" class="btn-reset">🗑 Скинути всі фільтри</a>
            </form>
        </div>
        
        <!-- Список послуг -->
        <div>
            <div class="services-count">
                <i class="fas fa-list"></i> Знайдено послуг: <strong><?= count($services) ?></strong>
            </div>
            
            <?php if (count($services) > 0): ?>
                <div class="services-grid">
                    <?php foreach($services as $index => $service): 
                        $photoUrl = $servicePhotos[$service['id']] ?? $servicePhotos[($index % count($servicePhotos)) + 1];
                    ?>
                    <div class="service-card">
                        <div class="service-image">
                            <img src="<?= htmlspecialchars($photoUrl) ?>" alt="<?= htmlspecialchars($service['name']) ?>" loading="lazy">
                        </div>
                        <div class="service-content">
                            <h3><?= htmlspecialchars($service['name']) ?></h3>
                            <div class="service-price"><?= number_format($service['price'], 0) ?> грн</div>
                            <div class="service-duration">⏱ Тривалість: <?= $service['duration_minutes'] ?> хв</div>
                            <a href="booking.php" class="btn-service">Записатися →</a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="no-results">
                    <i class="fas fa-search" style="font-size: 48px; color: #ccc;"></i>
                    <h3 style="margin: 20px 0; color: #666;">Нічого не знайдено</h3>
                    <p>Спробуйте змінити параметри пошуку або фільтри</p>
                    <a href="category.php?cat=<?= $category ?>" class="btn-service" style="margin-top: 20px;">Показати всі послуги</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="footer">
        <div class="footer-content">
            <div class="footer-column">
                <h4>Cosmology Beauty</h4>
                <p>Ваша краса - наша турбота. Професійна косметологія з використанням сучасних методик та преміальних засобів.</p>
            </div>
            <div class="footer-column">
                <h4>Контакти</h4>
                <p>📍 м. Дніпро, вул. Хрещатик, 15</p>
                <p>📞 (098) 123-45-67</p>
                <p>📞 (099) 123-45-67</p>
                <p>✉️ info@cosmology-beauty.com</p>
            </div>
            <div class="footer-column">
                <h4>Години роботи</h4>
                <p>Пн-Пт: 9:00 - 20:00</p>
                <p>Сб: 10:00 - 18:00</p>
                <p>Нд: Вихідний</p>
            </div>
            <div class="footer-column">
                <h4>Соціальні мережі</h4>
                <a href="#">📷 Instagram</a>
                <a href="#">📘 Facebook</a>
                <a href="#">📱 Telegram</a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>© 2026 Cosmology Beauty. Всі права захищено.</p>
            <p>м. Дніпро, вул. Хрещатик, 15 | Тел: (098) 123-45-67</p>
        </div>
    </div>
</body>
</html>