<?php
session_start();
require_once 'includes/config.php';

// Перевірка адміна
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Обробка додавання обладнання
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_equipment'])) {
    $name = $_POST['name'];
    $model = $_POST['model'];
    $manufacturer = $_POST['manufacturer'];
    $purchase_date = $_POST['purchase_date'];
    $warranty_until = $_POST['warranty_until'];
    $room_location = $_POST['room_location'];
    
    $stmt = $pdo->prepare("INSERT INTO equipment (name, model, manufacturer, purchase_date, warranty_until, room_location, status) VALUES (?, ?, ?, ?, ?, ?, 'active')");
    $stmt->execute([$name, $model, $manufacturer, $purchase_date, $warranty_until, $room_location]);
    $success = "Обладнання додано успішно!";
}

// Обробка оновлення статусу (через POST для безпеки та підтвердження)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status'])) {
    $id = $_POST['id'];
    $status = $_POST['status'];
    $stmt = $pdo->prepare("UPDATE equipment SET status = ? WHERE id = ?");
    $stmt->execute([$status, $id]);
    $success = "Статус обладнання оновлено!";
}

// Обробка видалення обладнання
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_equipment'])) {
    $id = $_POST['id'];
    
    // Перевірка, чи є обладнання в активних записах (опціонально)
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM appointments WHERE equipment_id = ? AND status NOT IN ('completed', 'canceled')");
    $stmt->execute([$id]);
    $in_use = $stmt->fetchColumn();
    
    if ($in_use > 0) {
        $error = "Неможливо видалити обладнання, яке використовується в активних записах!";
    } else {
        $stmt = $pdo->prepare("DELETE FROM equipment WHERE id = ?");
        $stmt->execute([$id]);
        $success = "Обладнання видалено!";
    }
}

// Обробка оновлення дати ТО
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_maintenance'])) {
    $id = $_POST['id'];
    $last_maintenance = $_POST['last_maintenance'];
    $stmt = $pdo->prepare("UPDATE equipment SET last_maintenance = ? WHERE id = ?");
    $stmt->execute([$last_maintenance, $id]);
    $success = "Дату технічного обслуговування оновлено!";
}

// Отримуємо обладнання з JOIN на кількість використань (опціонально)
$equipment = $pdo->query("
    SELECT e.*, 
           (SELECT COUNT(*) FROM appointments WHERE equipment_id = e.id AND status NOT IN ('completed', 'canceled')) as in_use_count
    FROM equipment e 
    ORDER BY e.id DESC
")->fetchAll();

// Статистика обладнання
$stats = $pdo->query("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
        SUM(CASE WHEN status = 'maintenance' THEN 1 ELSE 0 END) as maintenance,
        SUM(CASE WHEN status = 'broken' THEN 1 ELSE 0 END) as broken,
        SUM(CASE WHEN warranty_until < CURDATE() THEN 1 ELSE 0 END) as expired_warranty,
        SUM(CASE WHEN last_maintenance IS NULL OR last_maintenance < DATE_SUB(CURDATE(), INTERVAL 6 MONTH) THEN 1 ELSE 0 END) as maintenance_overdue
    FROM equipment
")->fetch();
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>Управління обладнанням - Cosmology Beauty</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f0eb; }
        
        /* Modal styles для підтверджень */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.6);
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        .modal-content {
            background: white;
            padding: 30px;
            border-radius: 20px;
            width: 450px;
            max-width: 90%;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .modal-buttons {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 25px;
        }
        .modal-buttons button {
            padding: 10px 25px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 14px;
        }
        .confirm-yes { background: #dc3545; color: white; }
        .confirm-no { background: #6c757d; color: white; }
        
        .toast {
            position: fixed;
            bottom: 30px;
            right: 30px;
            background: #28a745;
            color: white;
            padding: 15px 25px;
            border-radius: 10px;
            display: none;
            z-index: 1100;
            animation: fadeInOut 3s ease;
        }
        .toast.error { background: #dc3545; }
        @keyframes fadeInOut {
            0% { opacity: 0; transform: translateY(20px); }
            15% { opacity: 1; transform: translateY(0); }
            85% { opacity: 1; transform: translateY(0); }
            100% { opacity: 0; transform: translateY(20px); }
        }
        
        .sidebar {
            width: 260px;
            background: #2c2c2c;
            color: white;
            position: fixed;
            height: 100%;
            padding: 20px;
        }
        .sidebar h3 { margin-bottom: 30px; color: #c7a17a; }
        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 12px;
            margin: 5px 0;
            border-radius: 10px;
            transition: background 0.3s;
        }
        .sidebar a:hover, .sidebar a.active { background: #c7a17a; }
        
        .content {
            margin-left: 260px;
            padding: 30px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: transform 0.2s;
        }
        .stat-card:hover { transform: translateY(-3px); }
        .stat-number { font-size: 32px; font-weight: bold; color: #c7a17a; }
        .stat-label { color: #666; margin-top: 5px; font-size: 13px; }
        
        .equipment-card {
            background: white;
            border-radius: 20px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .header-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 25px;
        }
        
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.2s;
        }
        .btn-sm { padding: 5px 12px; font-size: 12px; }
        .btn-success { background: #28a745; color: white; }
        .btn-warning { background: #ffc107; color: #2c2c2c; }
        .btn-danger { background: #dc3545; color: white; }
        .btn-primary { background: #c7a17a; color: white; }
        .btn-info { background: #17a2b8; color: white; }
        .btn-secondary { background: #6c757d; color: white; }
        
        .btn-success:hover { background: #218838; }
        .btn-danger:hover { background: #c82333; }
        .btn-primary:hover { background: #b88d62; }
        .btn-warning:hover { background: #e0a800; }
        
        .equipment-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 25px;
        }
        
        .equipment-item {
            background: #f9f5f0;
            border-radius: 15px;
            padding: 20px;
            border-left: 5px solid #c7a17a;
            transition: all 0.2s;
            position: relative;
        }
        .equipment-item:hover { box-shadow: 0 5px 20px rgba(0,0,0,0.1); }
        .equipment-item.warranty-expired { border-left-color: #dc3545; background: #fff5f5; }
        .equipment-item.maintenance-overdue { border-left-color: #ffc107; background: #fffbf0; }
        
        .status-badge {
            position: absolute;
            top: 15px;
            right: 15px;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: bold;
        }
        .status-active { background: #d4edda; color: #155724; }
        .status-maintenance { background: #fff3cd; color: #856404; }
        .status-broken { background: #f8d7da; color: #721c24; }
        
        .equipment-item h4 { margin-bottom: 12px; color: #2c2c2c; font-size: 18px; }
        .equipment-item p { margin: 8px 0; font-size: 13px; color: #555; }
        .equipment-item strong { color: #2c2c2c; }
        
        .btn-group {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #e0d6cc;
        }
        
        .form-group { margin-bottom: 15px; }
        .form-group input, .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
        }
        
        .filter-bar {
            background: white;
            padding: 15px 20px;
            border-radius: 15px;
            margin-bottom: 25px;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }
        .filter-bar input, .filter-bar select {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
        }
        
        .search-btn { background: #c7a17a; color: white; border: none; padding: 8px 20px; border-radius: 8px; cursor: pointer; }
        
        @media (max-width: 768px) {
            .sidebar { width: 70px; padding: 15px 10px; }
            .sidebar h3, .sidebar a span { display: none; }
            .sidebar a { text-align: center; font-size: 20px; padding: 10px; }
            .content { margin-left: 70px; }
        }
    </style>
</head>
<body>
  <div class="sidebar">
    <h3>✨ Cosmology</h3>
    
    <a href="admin_dashboard.php">
        <i class="bi bi-house-door"></i>
        <span>Головна</span>
    </a>
    
    <a href="admin_clients.php">
        <i class="bi bi-people"></i>
        <span>Клієнти</span>
    </a>
    
    <a href="admin_doctors.php">
        <i class="bi bi-person-badge"></i>
        <span>Лікарі</span>
    </a>
    
    <a href="admin_services.php">
        <i class="bi bi-grid-3x3-gap-fill"></i>
        <span>Послуги</span>
    </a>
    
    <a href="admin_appointments.php">
        <i class="bi bi-calendar-check"></i>
        <span>Записи</span>
        <span class="badge">17</span> <!-- цифра, як на одному зі скріншотів -->
    </a>
    
    <a href="admin_certificates.php">
        <i class="bi bi-patch-check"></i>
        <span>Сертифікати</span>
    </a>
    
    <a href="admin_stock.php">
        <i class="bi bi-box-seam"></i>
        <span>Склад</span>
    </a>
    
    <a href="admin_stock_orders.php">
        <i class="bi bi-cart"></i>
        <span>Замовлення</span>
    </a>
    
    <a href="logout.php">
        <i class="bi bi-box-arrow-right"></i>
        <span>Вихід</span>
    </a>
</div>
    
    
    <div class="content">
        <h1 style="margin-bottom: 10px;">🔧 Управління обладнанням</h1>
        <p style="color: #666; margin-bottom: 25px;">Керування медичним обладнанням, статусами та технічним обслуговуванням</p>
        
        <div class="stats-grid">
            <div class="stat-card"><div class="stat-number"><?= $stats['total'] ?? 0 ?></div><div class="stat-label">Всього одиниць</div></div>
            <div class="stat-card"><div class="stat-number" style="color:#28a745;"><?= $stats['active'] ?? 0 ?></div><div class="stat-label">Активне</div></div>
            <div class="stat-card"><div class="stat-number" style="color:#ffc107;"><?= $stats['maintenance'] ?? 0 ?></div><div class="stat-label">На ремонті</div></div>
            <div class="stat-card"><div class="stat-number" style="color:#dc3545;"><?= $stats['broken'] ?? 0 ?></div><div class="stat-label">Зламано</div></div>
            <div class="stat-card"><div class="stat-number" style="color:#dc3545;"><?= $stats['expired_warranty'] ?? 0 ?></div><div class="stat-label">Гарантія минула</div></div>
            <div class="stat-card"><div class="stat-number" style="color:#ffc107;"><?= $stats['maintenance_overdue'] ?? 0 ?></div><div class="stat-label">ТО прострочено</div></div>
        </div>
        
        <div class="filter-bar">
            <input type="text" id="searchEquipment" placeholder="🔍 Пошук за назвою, моделлю..." onkeyup="filterEquipment()">
            <select id="statusFilter" onchange="filterEquipment()">
                <option value="all">Всі статуси</option>
                <option value="active">Активне</option>
                <option value="maintenance">На ремонті</option>
                <option value="broken">Зламано</option>
            </select>
            <select id="warrantyFilter" onchange="filterEquipment()">
                <option value="all">Вся гарантія</option>
                <option value="expired">Гарантія закінчилась</option>
                <option value="active_warranty">Гарантія активна</option>
            </select>
            <button class="btn btn-primary" onclick="openAddModal()">➕ Додати обладнання</button>
        </div>
        
        <div class="equipment-card">
            <div class="equipment-grid" id="equipmentGrid">
                <?php foreach($equipment as $e): ?>
                <?php 
                    $isWarrantyExpired = strtotime($e['warranty_until']) < time();
                    $isMaintenanceOverdue = !$e['last_maintenance'] || strtotime($e['last_maintenance']) < strtotime('-6 months');
                    $extraClass = '';
                    if ($isWarrantyExpired) $extraClass = 'warranty-expired';
                    if ($isMaintenanceOverdue && !$isWarrantyExpired) $extraClass = 'maintenance-overdue';
                ?>
                <div class="equipment-item <?= $extraClass ?>" data-name="<?= htmlspecialchars(strtolower($e['name'])) ?> <?= htmlspecialchars(strtolower($e['model'] ?? '')) ?>" data-status="<?= $e['status'] ?>" data-warranty="<?= $isWarrantyExpired ? 'expired' : 'active' ?>">
                    <span class="status-badge status-<?= $e['status'] ?>">
                        <?= $e['status'] == 'active' ? '✅ Активне' : ($e['status'] == 'maintenance' ? '🔧 Обслуговування' : '⚠️ Зламано') ?>
                    </span>
                    <h4><?= htmlspecialchars($e['name']) ?></h4>
                    <p><strong>Модель:</strong> <?= htmlspecialchars($e['model'] ?? '-') ?></p>
                    <p><strong>Виробник:</strong> <?= htmlspecialchars($e['manufacturer'] ?? '-') ?></p>
                    <p><strong>📅 Дата придбання:</strong> <?= date('d.m.Y', strtotime($e['purchase_date'])) ?></p>
                    <p><strong>📄 Гарантія до:</strong> <?= date('d.m.Y', strtotime($e['warranty_until'])) ?>
                        <?php if($isWarrantyExpired): ?>
                            <span style="color:#dc3545;"> (Закінчилась!)</span>
                        <?php endif; ?>
                    </p>
                    <p><strong>📍 Розташування:</strong> <?= htmlspecialchars($e['room_location'] ?? '-') ?></p>
                    <p><strong>🔧 Останнє ТО:</strong> <?= $e['last_maintenance'] ? date('d.m.Y', strtotime($e['last_maintenance'])) : 'Не проведено' ?>
                        <?php if($isMaintenanceOverdue && $e['last_maintenance']): ?>
                            <span style="color:#ffc107;"> (Прострочено!)</span>
                        <?php endif; ?>
                    </p>
                    <?php if(($e['in_use_count'] ?? 0) > 0): ?>
                        <p><strong>📋 В активних записах:</strong> <?= $e['in_use_count'] ?></p>
                    <?php endif; ?>
                    
                    <div class="btn-group">
                        <!-- Кнопки з підтвердженням зміни статусу -->
                        <button class="btn btn-success btn-sm" onclick="confirmStatusChange(<?= $e['id'] ?>, 'active', 'Активне')">✅ Активне</button>
                        <button class="btn btn-warning btn-sm" onclick="confirmStatusChange(<?= $e['id'] ?>, 'maintenance', 'Обслуговування')">🔧 На ремонт</button>
                        <button class="btn btn-danger btn-sm" onclick="confirmStatusChange(<?= $e['id'] ?>, 'broken', 'Зламано')">⚠️ Зламано</button>
                        <button class="btn btn-info btn-sm" onclick="openMaintenanceModal(<?= $e['id'] ?>, '<?= $e['last_maintenance'] ?>')">📅 Оновити ТО</button>
                        <button class="btn btn-secondary btn-sm" onclick="confirmDelete(<?= $e['id'] ?>, '<?= htmlspecialchars($e['name']) ?>')">🗑️ Видалити</button>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php if(empty($equipment)): ?>
                <p style="text-align: center; padding: 40px; color: #999;">Немає доданого обладнання. Натисніть "Додати обладнання"</p>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Modal для підтвердження зміни статусу -->
    <div id="statusModal" class="modal">
        <div class="modal-content">
            <h3>⚠️ Підтвердження дії</h3>
            <p id="statusConfirmText">Ви впевнені, що хочете змінити статус обладнання?</p>
            <form id="statusForm" method="POST">
                <input type="hidden" name="id" id="statusId">
                <input type="hidden" name="status" id="statusValue">
                <div class="modal-buttons">
                    <button type="button" class="confirm-no" onclick="closeModals()">Скасувати</button>
                    <button type="submit" name="update_status" class="confirm-yes">Підтвердити</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Modal для підтвердження видалення -->
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <h3>⚠️ Видалення обладнання</h3>
            <p id="deleteConfirmText">Ви впевнені, що хочете видалити це обладнання? Дія незворотна!</p>
            <form id="deleteForm" method="POST">
                <input type="hidden" name="id" id="deleteId">
                <div class="modal-buttons">
                    <button type="button" class="confirm-no" onclick="closeModals()">Скасувати</button>
                    <button type="submit" name="delete_equipment" class="confirm-yes">Так, видалити</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Modal для оновлення ТО -->
    <div id="maintenanceModal" class="modal">
        <div class="modal-content">
            <h3>📅 Оновлення технічного обслуговування</h3>
            <form id="maintenanceForm" method="POST">
                <input type="hidden" name="id" id="maintenanceId">
                <div class="form-group">
                    <label>Дата останнього ТО:</label>
                    <input type="date" name="last_maintenance" id="maintenanceDate" required>
                </div>
                <div class="modal-buttons">
                    <button type="button" class="confirm-no" onclick="closeModals()">Скасувати</button>
                    <button type="submit" name="update_maintenance" class="btn btn-primary">Зберегти</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Modal для додавання обладнання -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <h3 style="margin-bottom: 20px;">➕ Додати обладнання</h3>
            <form method="POST">
                <div class="form-group">
                    <input type="text" name="name" placeholder="Назва обладнання *" required>
                </div>
                <div class="form-group">
                    <input type="text" name="model" placeholder="Модель">
                </div>
                <div class="form-group">
                    <input type="text" name="manufacturer" placeholder="Виробник">
                </div>
                <div class="form-group">
                    <label>Дата придбання</label>
                    <input type="date" name="purchase_date">
                </div>
                <div class="form-group">
                    <label>Гарантія до</label>
                    <input type="date" name="warranty_until">
                </div>
                <div class="form-group">
                    <input type="text" name="room_location" placeholder="Розташування (кабінет)">
                </div>
                <div class="modal-buttons">
                    <button type="button" class="confirm-no" onclick="closeModals()">Скасувати</button>
                    <button type="submit" name="add_equipment" class="btn btn-primary">➕ Додати</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Toast повідомлення -->
    <div id="toast" class="toast"></div>
    
    <script>
        // Функції для модальних вікон з підтвердженням
        function confirmStatusChange(id, status, statusName) {
            document.getElementById('statusId').value = id;
            document.getElementById('statusValue').value = status;
            document.getElementById('statusConfirmText').innerHTML = `Ви впевнені, що хочете змінити статус обладнання на <strong>${statusName}</strong>?`;
            document.getElementById('statusModal').style.display = 'flex';
        }
        
        function confirmDelete(id, name) {
            document.getElementById('deleteId').value = id;
            document.getElementById('deleteConfirmText').innerHTML = `Ви впевнені, що хочете видалити обладнання <strong>${name}</strong>? Дія незворотна!`;
            document.getElementById('deleteModal').style.display = 'flex';
        }
        
        function openMaintenanceModal(id, currentDate) {
            document.getElementById('maintenanceId').value = id;
            if (currentDate && currentDate !== '') {
                document.getElementById('maintenanceDate').value = currentDate;
            } else {
                document.getElementById('maintenanceDate').value = new Date().toISOString().split('T')[0];
            }
            document.getElementById('maintenanceModal').style.display = 'flex';
        }
        
        function openAddModal() {
            document.getElementById('addModal').style.display = 'flex';
        }
        
        function closeModals() {
            document.querySelectorAll('.modal').forEach(modal => {
                modal.style.display = 'none';
            });
        }
        
        // Закриття модального вікна при кліку поза ним
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }
        
        // Фільтрація обладнання
        function filterEquipment() {
            const searchTerm = document.getElementById('searchEquipment').value.toLowerCase();
            const statusFilter = document.getElementById('statusFilter').value;
            const warrantyFilter = document.getElementById('warrantyFilter').value;
            
            const items = document.querySelectorAll('.equipment-item');
            
            items.forEach(item => {
                const name = item.getAttribute('data-name') || '';
                const status = item.getAttribute('data-status');
                const warranty = item.getAttribute('data-warranty');
                
                let matchesSearch = name.includes(searchTerm);
                let matchesStatus = statusFilter === 'all' || status === statusFilter;
                let matchesWarranty = warrantyFilter === 'all' || warranty === warrantyFilter;
                
                if (matchesSearch && matchesStatus && matchesWarranty) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        }
        
        // Показати повідомлення (якщо є success/error з PHP)
        <?php if(isset($success) && $success): ?>
        showToast('<?= addslashes($success) ?>', 'success');
        <?php elseif(isset($error) && $error): ?>
        showToast('<?= addslashes($error) ?>', 'error');
        <?php endif; ?>
        
        function showToast(message, type = 'success') {
            const toast = document.getElementById('toast');
            toast.textContent = message;
            toast.className = 'toast ' + (type === 'error' ? 'error' : '');
            toast.style.display = 'block';
            setTimeout(() => {
                toast.style.display = 'none';
            }, 3000);
        }
    </script>
</body>
</html>