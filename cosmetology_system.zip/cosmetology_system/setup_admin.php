<?php
// setup_admin.php
require_once 'includes/config.php';

$email = 'admin@cosmology.com';
$password = password_hash('admin123', PASSWORD_DEFAULT);
$full_name = 'Головний Адміністратор';

// Перевіряємо чи існує таблиця users
try {
    // Спроба додати в таблицю users
    $stmt = $pdo->prepare("INSERT INTO users (email, password, full_name, role) VALUES (?, ?, ?, 'admin')");
    $stmt->execute([$email, $password, $full_name]);
    echo "✅ Адміністратора успішно додано в таблицю users!<br>";
    echo "📧 Email: admin@cosmology.com<br>";
    echo "🔑 Пароль: admin123<br>";
} catch (PDOException $e) {
    // Якщо таблиці users немає або запис вже існує
    if (strpos($e->getMessage(), 'Duplicate') !== false) {
        echo "⚠️ Адміністратор вже існує!<br>";
    } else {
        echo "❌ Помилка: " . $e->getMessage() . "<br>";
        echo "Спробуйте створити таблицю admins...<br>";
        
        // Створюємо таблицю admins
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS admins (
                id INT AUTO_INCREMENT PRIMARY KEY,
                email VARCHAR(100) NOT NULL UNIQUE,
                password VARCHAR(255) NOT NULL,
                full_name VARCHAR(100) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ");
        
        // Додаємо адміністратора
        $stmt = $pdo->prepare("INSERT INTO admins (email, password, full_name) VALUES (?, ?, ?)");
        $stmt->execute([$email, $password, $full_name]);
        echo "✅ Таблицю admins створено та адміністратора додано!<br>";
        echo "📧 Email: admin@cosmology.com<br>";
        echo "🔑 Пароль: admin123<br>";
    }
}

echo '<br><a href="admin_login.php">→ Перейти до сторінки входу</a>';