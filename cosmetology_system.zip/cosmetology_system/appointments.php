<?php
session_start();
// Простий перевірка ролі (для демо)
if (true) { // тут має бути перевірка $_SESSION['role'] == 'admin'
    require_once '../config.php';
    
    $stmt = $pdo->query("
        SELECT a.id, u.full_name as client, s.name as service, a.appointment_datetime, a.status
        FROM appointments a
        JOIN users u ON a.client_id = u.id
        JOIN services s ON a.service_id = s.id
        ORDER BY a.appointment_datetime DESC
    ");
    $appointments = $stmt->fetchAll();
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Записи - Адмін</title>
        <style>
            table { border-collapse: collapse; width: 100%; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background: #4CAF50; color: white; }
            .confirmed { background: #c8e6c9; }
            .pending { background: #fff9c4; }
            .canceled { background: #ffcdd2; }
        </style>
    </head>
    <body>
        <h2>Управління записами</h2>
         <?php if (count($appointments) > 0): ?>
            <table>
                <tr><th>ID</th><th>Клієнт</th><th>Послуга</th><th>Дата/час</th><th>Статус</th><th>Дія</th></tr>
                <?php foreach ($appointments as $a): ?>
                <tr class="<?= $a['status'] ?>">
                    <td><?= $a['id'] ?></td>
                    <td><?= htmlspecialchars($a['client']) ?></td>
                    <td><?= htmlspecialchars($a['service']) ?></td>
                    <td><?= $a['appointment_datetime'] ?></td>
                    <td><?= $a['status'] ?></td>
                    <td>
                        <a href="update_status.php?id=<?= $a['id'] ?>&status=confirmed">✅ Підтвердити</a> |
                        <a href="update_status.php?id=<?= $a['id'] ?>&status=canceled">❌ Скасувати</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        <?php else: ?>
            <p>Немає записів</p>
        <?php endif; ?>
    </body>
    </html>
    <?php
} else {
    echo "Доступ заборонено";
}
?>