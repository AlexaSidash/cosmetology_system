<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/language.php';
?>

<!DOCTYPE html>
<html lang="<?php echo $current_lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo __('title_home'); ?> - Cosmology Beauty</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #fff; color: #333; }
        .top-bar { background: #121212; color: white; padding: 8px 0; font-size: 14px; text-align: center; }
        .header { background: white; box-shadow: 0 2px 15px rgba(0,0,0,0.08); position: sticky; top: 0; z-index: 1000; }
        .nav-container { max-width: 1300px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; padding: 15px 20px; flex-wrap: wrap; gap: 15px; }
        .logo { font-size: 28px; font-weight: bold; color: #c7a17a; }
        .logo span { color: #121212; }
        .nav-menu { display: flex; list-style: none; gap: 25px; flex-wrap: wrap; margin: 0; padding: 0; }
        .nav-menu li { position: relative; }
        .nav-menu a { text-decoration: none; color: #121212; font-weight: 500; transition: color 0.3s; font-size: 16px; }
        .nav-menu a:hover { color: #c7a17a; }
        .dropdown { position: relative; }
        .dropdown-content { display: none; position: absolute; background: white; min-width: 220px; box-shadow: 0 8px 16px rgba(0,0,0,0.1); border-radius: 8px; top: 100%; left: 0; z-index: 1; }
        .dropdown:hover .dropdown-content { display: block; }
        .dropdown-content a { display: block; padding: 12px 20px; color: #333; border-bottom: 1px solid #eee; }
        .dropdown-content a:hover { background: #f9f5f0; color: #c7a17a; }
        .btn-book { background: #c7a17a; color: white !important; padding: 10px 25px; border-radius: 30px; }
        .btn-book:hover { background: #a67c52; }
        .right-controls { display: flex; align-items: center; gap: 15px; }
        .language-switcher { display: flex; gap: 5px; }
        .lang-link { text-decoration: none; padding: 5px 10px; border-radius: 5px; color: #2c2c2c; font-size: 14px; }
        .lang-link.active { background-color: #c7a17a; color: white; }
        .theme-btn { background: none; border: 1px solid #c7a17a; border-radius: 20px; padding: 5px 12px; cursor: pointer; font-size: 14px; }
        .theme-btn:hover { background: #c7a17a; color: white; }
        .hero { background: linear-gradient(135deg, #f9f5f0 0%, #fff 100%); padding: 80px 20px; text-align: center; }
        .hero h1 { font-size: 56px; color: #121212; margin-bottom: 20px; font-weight: 300; }
        .hero h1 span { color: #c7a17a; font-weight: 600; }
        .hero p { font-size: 18px; color: #666; margin-bottom: 35px; max-width: 600px; margin: 0 auto 35px; }
        .btn-primary { background: #c7a17a; color: white; padding: 14px 40px; border-radius: 40px; text-decoration: none; font-weight: 600; display: inline-block; transition: all 0.3s; }
        .btn-primary:hover { background: #a67c52; transform: translateY(-2px); }
        .categories { max-width: 1300px; margin: 60px auto; padding: 0 20px; }
        .section-title { text-align: center; font-size: 36px; margin-bottom: 40px; color: #2c2c2c; font-weight: 300; }
        .section-title span { color: #c7a17a; font-weight: 600; }
        .categories-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px; }
        .category-card { background: white; border-radius: 15px; overflow: hidden; box-shadow: 0 5px 20px rgba(0,0,0,0.05); transition: all 0.3s; text-decoration: none; color: #333; display: block; border: 1px solid #f0e6dc; }
        .category-card:hover { transform: translateY(-8px); box-shadow: 0 15px 35px rgba(0,0,0,0.1); }
        .category-image { height: 240px; background-size: cover; background-position: center; }
        .category-info { padding: 20px; text-align: center; }
        .category-info h3 { font-size: 20px; margin-bottom: 10px; color: #c7a17a; }
        .category-info p { color: #666; font-size: 14px; }
        .footer { background: #1a1a1a; color: #999; padding: 50px 20px 30px; margin-top: 60px; }
        .footer-content { max-width: 1300px; margin: 0 auto; display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 40px; }
        .footer-column h4 { color: white; margin-bottom: 20px; font-size: 18px; }
        .footer-column p { line-height: 1.8; }
        .footer-column a { color: #999; text-decoration: none; display: block; margin-bottom: 10px; transition: color 0.3s; }
        .footer-column a:hover { color: #c7a17a; }
        .footer-bottom { text-align: center; padding-top: 30px; margin-top: 30px; border-top: 1px solid #333; font-size: 14px; }
        body.dark-mode { background: #121212; color: #e9ecef; }
        body.dark-mode .header { background: #1a1a1a; }
        body.dark-mode .nav-menu a { color: #e9ecef; }
        body.dark-mode .logo span { color: #e9ecef; }
        body.dark-mode .category-card { background: #1e1e1e; border-color: #343a40; }
        body.dark-mode .category-card h3 { color: #c7a17a; }
        body.dark-mode .category-card p { color: #adb5bd; }
        body.dark-mode .lang-link { color: #e9ecef; }
        @media (max-width: 768px) { .nav-container { flex-direction: column; } .hero h1 { font-size: 36px; } }
    </style>
</head>
<body>
    <div class="top-bar">✨ <?php echo __('new_client_discount'); ?> ✨</div>
    
    <div class="header">
        <div class="nav-container">
            <div class="logo">Cosmology <span>Beauty</span></div>
            <ul class="nav-menu">
                <li><a href="index.php"><?php echo __('nav_home'); ?></a></li>
                <li><a href="about.php"><?php echo __('about_us'); ?></a></li>
                <li class="dropdown">
                    <a href="#"><?php echo __('price_list'); ?> ▼</a>
                    <div class="dropdown-content">
                        <a href="category.php?cat=injection"><?php echo __('injection_cosmetology'); ?></a>
                        <a href="category.php?cat=apparatus"><?php echo __('apparatus_cosmetology'); ?></a>
                        <a href="category.php?cat=laser"><?php echo __('laser_cosmetology'); ?></a>
                        <a href="category.php?cat=epilation"><?php echo __('laser_epilation'); ?></a>
                        <a href="category.php?cat=intimate"><?php echo __('intimate_cosmetology'); ?></a>
                        <a href="category.php?cat=care"><?php echo __('care_procedures'); ?></a>
                        <a href="category.php?cat=dermatology"><?php echo __('dermatology'); ?></a>
                    </div>
                </li>
                <li><a href="loyalty.php"><?php echo __('loyalty_program'); ?></a></li>
                <li><a href="doctors.php"><?php echo __('nav_doctors'); ?></a></li>
                <li><a href="booking.php" class="btn-book"><?php echo __('btn_book'); ?></a></li>
            </ul>
            
            <div class="right-controls">
                <div class="language-switcher">
                    <a href="switch_language.php?lang=uk" class="lang-link <?php echo $current_lang == 'uk' ? 'active' : ''; ?>">🇺🇦 УКР</a>
                    <a href="switch_language.php?lang=en" class="lang-link <?php echo $current_lang == 'en' ? 'active' : ''; ?>">🇬🇧 ENG</a>
                </div>
                <button onclick="toggleTheme()" class="theme-btn">🌓 Тема</button>
            </div>
        </div>
    </div>
    
    <div class="hero">
        <h1><?php echo __('hero_title'); ?> <span><?php echo __('hero_title_span'); ?></span></h1>
        <p><?php echo __('hero_text'); ?></p>
        <a href="booking.php" class="btn-primary"><?php echo __('btn_book_online'); ?> →</a>
    </div>
    
    <div class="categories">
        <h2 class="section-title"><?php echo __('our_services'); ?> <span><?php echo __('services_highlight'); ?></span></h2>
        <div class="categories-grid">
            <?php
           $categories = [
    [
        'name' => __('injection_cosmetology'),
        'desc' => __('injection_desc'),
        'cat' => 'injection',
        'image' => 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?w=600&h=400&fit=crop'
    ],
    [
        'name' => __('apparatus_cosmetology'),
        'desc' => __('apparatus_desc'),
        'cat' => 'apparatus',
        'image' => 'https://images.unsplash.com/photo-1515377905703-c4788e51af15?w=600&h=400&fit=crop'
    ],
    [
        'name' => __('laser_cosmetology'),
        'desc' => __('laser_desc'),
        'cat' => 'laser',
        'image' => 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?w=600&h=400&fit=crop'
    ],
    [
        'name' => __('laser_epilation'),
        'desc' => __('epilation_desc'),
        'cat' => 'epilation',
        'image' => 'https://images.unsplash.com/photo-1526947425960-945c6e72858f?w=600&h=400&fit=crop'
    ],
    [
        'name' => __('intimate_cosmetology'),
        'desc' => __('intimate_desc'),
        'cat' => 'intimate',
        'image' => 'https://images.unsplash.com/photo-1519823551278-64ac92734fb1?w=600&h=400&fit=crop'
    ],
    [
        'name' => __('care_procedures'),
        'desc' => __('care_desc'),
        'cat' => 'care',
        'image' => 'https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?w=600&h=400&fit=crop'
    ],
    [
      
    'name' => __('dermatology'),
    'desc' => __('dermatology_desc'),
    'cat' => 'dermatology',
    'image' => 'https://images.pexels.com/photos/4041395/pexels-photo-4041395.jpeg?w=600&h=400&fit=crop'
],
];
            foreach($categories as $cat): ?>
            <a href="category.php?cat=<?= $cat['cat'] ?>" class="category-card">
                <div class="category-image" style="background-image: url('<?= $cat['image'] ?>');"></div>
                <div class="category-info">
                    <h3><?= $cat['name'] ?></h3>
                    <p><?= $cat['desc'] ?></p>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    
    <div class="footer">
        <div class="footer-content">
            <div class="footer-column">
                <h4>Cosmology Beauty</h4>
                <p><?php echo __('footer_text'); ?></p>
            </div>
            <div class="footer-column">
                <h4><?php echo __('contacts'); ?></h4>
                <p>📍 <?php echo __('address'); ?></p>
                <p>📞 (098) 123-45-67</p>
                <p>✉️ info@cosmology-beauty.com</p>
            </div>
            <div class="footer-column">
                <h4><?php echo __('working_hours'); ?></h4>
                <p><?php echo __('mon_fri'); ?>: 9:00 - 20:00</p>
                <p><?php echo __('saturday'); ?>: 10:00 - 18:00</p>
                <p><?php echo __('sunday'); ?>: <?php echo __('day_off'); ?></p>
            </div>
            <div class="footer-column">
                <h4><?php echo __('social_media'); ?></h4>
                <a href="#">📷 Instagram</a>
                <a href="#">📘 Facebook</a>
              <div class="admin-links">
    <h4 style="color:#c7a17a; font-size:14px; margin-top:15px;">🔐 <?php echo __('system_access'); ?></h4>
    <a href="login.php">👤 <?php echo __('client_login'); ?></a>
    <a href="doctor_login.php">👩‍⚕️ <?php echo __('doctor_login'); ?></a>
    <a href="admin_login.php">⚙️ <?php echo __('admin_login'); ?></a>
    <a href="register.php">📝 <?php echo __('register'); ?></a>
</div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>© 2026 Cosmology Beauty. <?php echo __('footer_copyright'); ?></p>
        </div>
    </div>
    
    <script>
    function toggleTheme() {
        document.body.classList.toggle('dark-mode');
        localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
    }
    if (localStorage.getItem('theme') === 'dark') {
        document.body.classList.add('dark-mode');
    }
    </script>
</body>
</html>