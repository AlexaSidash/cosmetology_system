<?php
session_start();
require_once 'includes/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$client_id = $_GET['client_id'] ?? 0;
if (!$client_id) {
    header("Location: admin_dashboard.php");
    exit();
}

// Отримуємо дані клієнта
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND role = 'client'");
$stmt->execute([$client_id]);
$client = $stmt->fetch();

if (!$client) {
    header("Location: admin_dashboard.php");
    exit();
}

// Отримуємо лікарів
$doctors = $pdo->query("
    SELECT c.id, u.full_name, c.rating 
    FROM cosmetologists c 
    JOIN users u ON c.user_id = u.id
")->fetchAll();

// Отримуємо послуги
$services = $pdo->query("SELECT id, name, price, duration_minutes FROM services WHERE is_active = 1")->fetchAll();

// Створення запису
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $doctor_id = $_POST['doctor_id'];
    $service_id = $_POST['service_id'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $datetime = $date . ' ' . $time . ':00';
    
    $stmt = $pdo->prepare("
        INSERT INTO appointments (client_id, cosmetologist_id, service_id, appointment_datetime, status, created_at) 
        VALUES (?, ?, ?, ?, 'confirmed', NOW())
    ");
    $stmt->execute([$client_id, $doctor_id, $service_id, $datetime]);
    
    header("Location: admin_dashboard.php?msg=created");
    exit();
}
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>Створення запису | Cosmology Beauty</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f0eb; padding: 40px; }
        .container { max-width: 600px; margin: 0 auto; background: white; border-radius: 20px; padding: 30px; }
        h1 { color: #c7a17a; margin-bottom: 20px; }
        .form-group { margin-bottom: 20px; }
        label { display: block; font-weight: 500; margin-bottom: 5px; }
        select, input {
            width: 100%;
            padding: 10px;
            border: 2px solid #f0e6dc;
            border-radius: 10px;
        }
        .btn {
            background: #c7a17a;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            width: 100%;
        }
        .info { background: #f9f5f0; padding: 15px; border-radius: 10px; margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>📅 Створення запису</h1>
        <div class="info">
            <strong>👤 Клієнт:</strong> <?= htmlspecialchars($client['full_name']) ?><br>
            <strong>📧 Email:</strong> <?= htmlspecialchars($client['email']) ?><br>
            <strong>📞 Телефон:</strong> <?= htmlspecialchars($client['phone']) ?>
        </div>
        
        <form method="POST">
            <div class="form-group">
                <label>👩‍⚕️ Лікар</label>
                <select name="doctor_id" required>
                    <option value="">-- Оберіть --</option>
                    <?php foreach($doctors as $d): ?>
                        <option value="<?= $d['id'] ?>"><?= htmlspecialchars($d['full_name']) ?> ⭐ <?= $d['rating'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>💆‍♀️ Послуга</label>
                <select name="service_id" required>
                    <option value="">-- Оберіть --</option>
                    <?php foreach($services as $s): ?>
                        <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['name']) ?> (<?= $s['price'] ?> грн)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>📅 Дата</label>
                <input type="date" name="date" required min="<?= date('Y-m-d') ?>">
            </div>
            
            <div class="form-group">
                <label>⏰ Час</label>
                <input type="time" name="time" required>
            </div>
            
            <button type="submit" class="btn">✅ Створити запис</button>
        </form>
    </div>
</body>
</html>