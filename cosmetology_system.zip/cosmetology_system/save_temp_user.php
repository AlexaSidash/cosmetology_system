<?php
session_start();
require_once 'includes/config.php';

header('Content-Type: application/json');

$full_name = $_POST['full_name'] ?? '';
$email = $_POST['email'] ?? '';
$phone = $_POST['phone'] ?? '';
$password = $_POST['password'] ?? '';

// Перевірка на пусті поля
if (empty($full_name) || empty($email) || empty($phone) || empty($password)) {
    echo json_encode(['success' => false, 'error' => 'Всі поля обов\'язкові']);
    exit;
}

// Перевірка, чи email вже існує в БД
try {
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'error' => 'Такий email вже зареєстровано']);
        exit;
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Помилка бази даних: ' . $e->getMessage()]);
    exit;
}

// Зберігаємо дані в сесію
$_SESSION['temp_user'] = [
    'full_name' => $full_name,
    'email' => $email,
    'phone' => $phone,
    'password' => password_hash($password, PASSWORD_DEFAULT)
];

echo json_encode(['success' => true]);
?>