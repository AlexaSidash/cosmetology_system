<?php
// reset_admin_password.php
require_once 'includes/config.php';

$email = 'admin@cosmology.com';
$new_password = 'admin123';

// Створюємо новий хеш пароля
$new_hash = password_hash($new_password, PASSWORD_DEFAULT);

echo "<h2>🔧 Скидання пароля адміністратора</h2>";
echo "Email: " . $email . "<br>";
echo "Новий пароль: " . $new_password . "<br>";
echo "Новий хеш: " . $new_hash . "<br><br>";

try {
    // Оновлюємо пароль
    $stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE email = ?");
    $stmt->execute([$new_hash, $email]);
    
    if ($stmt->rowCount() > 0) {
        echo "<div style='background: #d4edda; padding: 15px; border-radius: 10px;'>";
        echo "✅ <strong>Пароль успішно оновлено!</strong><br>";
        echo "📧 Email: <strong>admin@cosmology.com</strong><br>";
        echo "🔑 Новий пароль: <strong>admin123</strong><br>";
        echo "</div>";
        
        // Перевіряємо, що пароль працює
        $verify_stmt = $pdo->prepare("SELECT password_hash FROM users WHERE email = ?");
        $verify_stmt->execute([$email]);
        $user = $verify_stmt->fetch();
        
        if (password_verify($new_password, $user['password_hash'])) {
            echo "<div style='background: #d4edda; padding: 10px; border-radius: 10px; margin-top: 10px;'>";
            echo "✅ <strong>Перевірка пройдена!</strong> Пароль працює коректно.<br>";
            echo "</div>";
        } else {
            echo "<div style='background: #f8d7da; padding: 10px; border-radius: 10px; margin-top: 10px;'>";
            echo "❌ <strong>ПОМИЛКА!</strong> Пароль не працює після оновлення.<br>";
            echo "</div>";
        }
        
    } else {
        echo "<div style='background: #fff3cd; padding: 15px; border-radius: 10px;'>";
        echo "⚠️ <strong>Адміністратора з email $email не знайдено!</strong><br>";
        echo "Створюємо нового...<br>";
        
        // Створюємо нового адміністратора
        $insert = $pdo->prepare("INSERT INTO users (full_name, email, phone, password_hash, role) VALUES (?, ?, ?, ?, 'admin')");
        $insert->execute(['Головний Адміністратор', $email, '+380000000000', $new_hash]);
        echo "✅ Адміністратора створено!<br>";
        echo "</div>";
    }
    
} catch (PDOException $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 10px;'>";
    echo "❌ <strong>Помилка:</strong><br>";
    echo htmlspecialchars($e->getMessage());
    echo "</div>";
}

echo '<br><a href="admin_login.php" style="background: #c7a17a; color: white; padding: 10px 20px; text-decoration: none; border-radius: 10px;">→ Перейти до входу</a>';
?>