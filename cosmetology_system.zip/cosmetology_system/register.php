<?php
session_start();
require_once 'includes/config.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    if (empty($full_name) || empty($email) || empty($phone) || empty($password)) {
        $error = 'Будь ласка, заповніть всі поля';
    } elseif ($password !== $confirm_password) {
        $error = 'Паролі не співпадають';
    } elseif (strlen($password) < 4) {
        $error = 'Пароль має містити щонайменше 4 символи';
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        try {
            // Перевірка чи email існує
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $error = 'Такий email вже зареєстровано';
            } else {
                // Додаємо користувача
                $stmt = $pdo->prepare("INSERT INTO users (full_name, email, phone, password_hash, role, bonus_points, created_at) VALUES (?, ?, ?, ?, 'client', 100, NOW())");
                $stmt->execute([$full_name, $email, $phone, $hashed_password]);
                
                $user_id = $pdo->lastInsertId();
                
                // Автоматичний вхід
                $_SESSION['user_id'] = $user_id;
                $_SESSION['user_name'] = $full_name;
                $_SESSION['user_role'] = 'client';
                $_SESSION['user_email'] = $email;
                
                // Перенаправлення на сторінку запису
                header("Location: booking.php");
                exit();
            }
        } catch(PDOException $e) {
            $error = 'Помилка бази даних: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Реєстрація | Cosmology Beauty</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f9f5f0 0%, #e8ddd0 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 40px 20px;
        }
        
        .register-container {
            max-width: 500px;
            width: 100%;
            background: white;
            border-radius: 30px;
            box-shadow: 0 25px 50px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .register-decoration {
            height: 6px;
            background: linear-gradient(90deg, #c7a17a, #d4b896, #c7a17a);
        }
        
        .register-header {
            background: white;
            padding: 35px 35px 20px;
            text-align: center;
        }
        
        .register-header .logo-icon {
            font-size: 55px;
            margin-bottom: 10px;
        }
        
        .register-header h1 {
            font-size: 28px;
            color: #2c2c2c;
            font-weight: 300;
        }
        
        .register-header h1 span {
            color: #c7a17a;
            font-weight: 600;
        }
        
        .register-header p {
            color: #999;
            font-size: 13px;
            margin-top: 8px;
        }
        
        .register-body {
            padding: 0 35px 40px;
        }
        
        .form-group {
            margin-bottom: 18px;
        }
        
        .form-group label {
            display: block;
            font-weight: 500;
            color: #555;
            margin-bottom: 6px;
            font-size: 12px;
            text-transform: uppercase;
        }
        
        .input-group {
            position: relative;
        }
        
        .input-group .input-icon {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 16px;
            color: #c7a17a;
        }
        
        .input-group input {
            width: 100%;
            padding: 13px 16px 13px 46px;
            border: 1.5px solid #f0e6dc;
            border-radius: 50px;
            font-size: 14px;
            transition: all 0.3s;
            background: #fefefe;
        }
        
        .input-group input:focus {
            outline: none;
            border-color: #c7a17a;
        }
        
        .btn-register {
            width: 100%;
            background: #c7a17a;
            color: white;
            border: none;
            padding: 14px;
            font-size: 16px;
            font-weight: 600;
            border-radius: 50px;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 15px;
        }
        
        .btn-register:hover {
            background: #a67c52;
            transform: translateY(-2px);
        }
        
        .error-message {
            background: #fef3e8;
            border-left: 4px solid #e74c3c;
            padding: 12px 15px;
            border-radius: 12px;
            margin-bottom: 20px;
            color: #e74c3c;
            font-size: 13px;
        }
        
        .success-message {
            background: #e8f5e9;
            border-left: 4px solid #28a745;
            padding: 12px 15px;
            border-radius: 12px;
            margin-bottom: 20px;
            color: #155724;
        }
        
        .login-link {
            text-align: center;
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid #f0e6dc;
        }
        
        .login-link p {
            color: #888;
            font-size: 13px;
            margin-bottom: 5px;
        }
        
        .login-link a {
            color: #c7a17a;
            text-decoration: none;
            font-weight: 600;
        }
        
        .login-link a:hover {
            text-decoration: underline;
        }
        
        .back-home {
            text-align: center;
            margin-top: 15px;
        }
        
        .back-home a {
            color: #bbb;
            text-decoration: none;
            font-size: 12px;
        }
        
        .back-home a:hover {
            color: #c7a17a;
        }
    </style>
</head>
<body>
    <div class="register-container">
        <div class="register-decoration"></div>
        
        <div class="register-header">
            <div class="logo-icon">✨</div>
            <h1>Приєднуйтесь до <span>Cosmology</span></h1>
            <p>Створіть акаунт за 30 секунд</p>
        </div>
        
        <div class="register-body">
            <?php if($error): ?>
                <div class="error-message">⚠️ <?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            
            <?php if($success): ?>
                <div class="success-message">✅ <?= htmlspecialchars($success) ?></div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label>ПІБ</label>
                    <div class="input-group">
                        <span class="input-icon">👤</span>
                        <input type="text" name="full_name" placeholder="Іван Петренко" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Email</label>
                    <div class="input-group">
                        <span class="input-icon">📧</span>
                        <input type="email" name="email" placeholder="your@email.com" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Телефон</label>
                    <div class="input-group">
                        <span class="input-icon">📞</span>
                        <input type="tel" name="phone" placeholder="099 123 45 67" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Пароль</label>
                    <div class="input-group">
                        <span class="input-icon">🔒</span>
                        <input type="password" name="password" placeholder="Мінімум 4 символи" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Підтвердіть пароль</label>
                    <div class="input-group">
                        <span class="input-icon">✓</span>
                        <input type="password" name="confirm_password" placeholder="Введіть пароль ще раз" required>
                    </div>
                </div>
                
                <button type="submit" class="btn-register">
                    Зареєструватися →
                </button>
            </form>
            
            <div class="login-link">
                <p>Вже маєте акаунт?</p>
                <a href="login.php">Увійти →</a>
            </div>
            
            <div class="back-home">
                <a href="index.php">← На головну</a>
            </div>
        </div>
    </div>
</body>
</html>