<?php
session_start();
require_once 'includes/config.php';

header('Content-Type: application/json');

$method = $_POST['method'] ?? $_SESSION['verification_method'] ?? 'email';
$resend = isset($_POST['resend']);

// Перевірка, чи є дані в сесії
if (!isset($_SESSION['temp_user'])) {
    echo json_encode(['success' => false, 'error' => 'Дані не знайдено. Почніть реєстрацію заново.']);
    exit;
}

$temp_user = $_SESSION['temp_user'];
$email = $temp_user['email'];
$phone = $temp_user['phone'];
$full_name = $temp_user['full_name'];

// Зберігаємо метод в сесію
$_SESSION['verification_method'] = $method;

// Генеруємо 6-значний код
$code = sprintf("%06d", mt_rand(1, 999999));

// Видаляємо старі коди для цього email
try {
    $stmt = $pdo->prepare("DELETE FROM verification_codes WHERE email = ?");
    $stmt->execute([$email]);
} catch (PDOException $e) {
    // Таблиці може не бути - створимо її
    $pdo->exec("CREATE TABLE IF NOT EXISTS verification_codes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(100) NOT NULL,
        code VARCHAR(6) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        expires_at TIMESTAMP DEFAULT (CURRENT_TIMESTAMP + INTERVAL 10 MINUTE),
        is_used BOOLEAN DEFAULT FALSE,
        INDEX idx_email (email)
    )");
    $stmt = $pdo->prepare("DELETE FROM verification_codes WHERE email = ?");
    $stmt->execute([$email]);
}

// Зберігаємо новий код в БД
$stmt = $pdo->prepare("INSERT INTO verification_codes (email, code) VALUES (?, ?)");
$stmt->execute([$email, $code]);

// Зберігаємо код в сесію
$_SESSION['temp_user']['verification_code'] = $code;

// Визначаємо куди надсилати
$destination = ($method == 'email') ? $email : $phone;

// ТЕСТОВА ВЕРСІЯ - просто повертаємо код
echo json_encode([
    'success' => true, 
    'code' => $code,
    'destination' => $destination,
    'method' => $method
]);
?>