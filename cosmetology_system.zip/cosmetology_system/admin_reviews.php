<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// ЗМІНІТЬ ШЛЯХ ЯКЩО ПОТРІБНО
require_once 'includes/config.php';
// require_once '../includes/config.php';  // Якщо файл в папці admin

// Перевірка авторизації адміністратора
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    header("Location: admin_login.php");
    exit();
}

// Перевіряємо чи існує колонка is_approved
$hasApprovedColumn = false;
try {
    $checkColumn = $pdo->query("SHOW COLUMNS FROM reviews LIKE 'is_approved'");
    $hasApprovedColumn = ($checkColumn->rowCount() > 0);
} catch (PDOException $e) {
    $hasApprovedColumn = false;
}

// Отримуємо відгуки
$reviews = [];
try {
    $stmt = $pdo->query("SELECT * FROM reviews ORDER BY created_at DESC");
    $reviews = $stmt->fetchAll();
} catch (PDOException $e) {
    echo "Помилка: " . $e->getMessage();
    exit();
}

// Підрахунок статистики
$total = count($reviews);
$approved = 0;
$pending = 0;
$sum = 0;

foreach ($reviews as $r) {
    $sum += $r['rating'];
    if ($hasApprovedColumn) {
        if ($r['is_approved'] == 1) {
            $approved++;
        } else {
            $pending++;
        }
    } else {
        $approved = $total;
        $pending = 0;
    }
}
$avg_rating = ($total > 0) ? $sum / $total : 0;
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Модерація відгуків - Адмін панель</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f5f5; }
        .sidebar {
            width: 260px;
            background: #2c2c2c;
            color: white;
            position: fixed;
            left: 0;
            top: 0;
            height: 100%;
            padding: 20px;
            overflow-y: auto;
        }
        .sidebar h3 { color: #c7a17a; margin-bottom: 30px; text-align: center; font-size: 24px; }
        .sidebar a {
            display: flex;
            align-items: center;
            gap: 12px;
            color: #ddd;
            text-decoration: none;
            padding: 12px 15px;
            margin: 5px 0;
            border-radius: 8px;
            transition: 0.3s;
        }
        .sidebar a:hover, .sidebar a.active { background: #c7a17a; color: white; }
        .sidebar a i { width: 24px; font-size: 18px; }
        .main-content { margin-left: 260px; padding: 30px; }
        .header { background: white; padding: 20px; border-radius: 15px; margin-bottom: 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: white; padding: 20px; border-radius: 15px; text-align: center; box-shadow: 0 2px 10px rgba(0,0,0,0.1); cursor: pointer; transition: 0.3s; }
        .stat-card:hover { transform: translateY(-3px); background: #fef9f5; }
        .stat-card .number { font-size: 36px; font-weight: bold; color: #c7a17a; }
        .stat-card .label { color: #666; margin-top: 10px; }
        .reviews-container { background: white; border-radius: 15px; padding: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .filter-buttons { margin-bottom: 20px; display: flex; gap: 10px; flex-wrap: wrap; border-bottom: 1px solid #eee; padding-bottom: 15px; }
        .filter-btn { padding: 8px 20px; border: 2px solid #c7a17a; background: white; color: #c7a17a; border-radius: 25px; cursor: pointer; transition: 0.3s; font-weight: 500; }
        .filter-btn.active, .filter-btn:hover { background: #c7a17a; color: white; }
        .review-item { border-bottom: 1px solid #eee; padding: 20px; transition: 0.3s; }
        .review-item:hover { background: #f9f9f9; }
        .review-header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; margin-bottom: 15px; }
        .review-rating { color: #ffc107; font-size: 18px; }
        .review-comment { background: #f8f8f8; padding: 15px; border-radius: 10px; margin: 10px 0; line-height: 1.5; }
        .review-meta { display: flex; gap: 15px; flex-wrap: wrap; margin: 10px 0; font-size: 12px; color: #888; }
        .review-status { padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: bold; display: inline-block; }
        .status-approved { background: #d4edda; color: #155724; }
        .status-pending { background: #fff3cd; color: #856404; }
        .btn { padding: 8px 16px; border: none; border-radius: 8px; cursor: pointer; margin: 5px; font-size: 13px; font-weight: 500; transition: 0.3s; }
        .btn-approve { background: #28a745; color: white; }
        .btn-approve:hover { background: #218838; }
        .btn-delete { background: #dc3545; color: white; }
        .btn-delete:hover { background: #c82333; }
        .btn-response { background: #c7a17a; color: white; }
        .btn-response:hover { background: #a67c52; }
        .empty-state { text-align: center; padding: 50px; color: #999; }
        .empty-state i { font-size: 48px; margin-bottom: 15px; display: block; }
        textarea { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 8px; font-family: inherit; resize: vertical; }
        @media (max-width: 768px) { .sidebar { width: 70px; padding: 20px 10px; } .sidebar a span { display: none; } .main-content { margin-left: 70px; } }
    </style>
</head>
<body>
<div class="sidebar">
    <h3>✨ Cosmology</h3>
    <a href="admin_dashboard.php"><i class="bi bi-house-door-fill"></i><span>Головна</span></a>
    <a href="admin_clients.php"><i class="bi bi-people-fill"></i><span>Клієнти</span></a>
    <a href="admin_doctors.php"><i class="bi bi-person-badge-fill"></i><span>Лікарі</span></a>
    <a href="admin_services.php"><i class="bi bi-grid-3x3-gap-fill"></i><span>Послуги</span></a>
    <a href="admin_appointments.php"><i class="bi bi-calendar-check-fill"></i><span>Записи</span></a>
    <a href="admin_certificates.php"><i class="bi bi-patch-check-fill"></i><span>Сертифікати</span></a>
    <a href="admin_stock.php"><i class="bi bi-box-seam-fill"></i><span>Склад</span></a>
    <a href="admin_stock_orders.php"><i class="bi bi-cart-fill"></i><span>Замовлення</span></a>
    <a href="admin_reviews.php" class="active"><i class="bi bi-star-fill"></i><span>Відгуки</span></a>
    <a href="admin_finance.php"><i class="bi bi-graph-up"></i><span>Фінанси</span></a>
    <a href="logout.php"><i class="bi bi-box-arrow-right"></i><span>Вихід</span></a>
</div>
    
<div class="main-content">
    <div class="header">
        <h1><i class="bi bi-star-fill"></i> Модерація відгуків</h1>
        <p>Управління відгуками клієнтів</p>
    </div>
    
    <div class="stats-grid">
        <div class="stat-card" onclick="filterReviews('all')"><div class="number"><?php echo $total; ?></div><div class="label">📝 Всього відгуків</div></div>
        <div class="stat-card" onclick="filterReviews('pending')"><div class="number"><?php echo $pending; ?></div><div class="label">⏳ Очікують модерації</div></div>
        <div class="stat-card" onclick="filterReviews('approved')"><div class="number"><?php echo $approved; ?></div><div class="label">✅ Опубліковано</div></div>
        <div class="stat-card"><div class="number"><?php echo number_format($avg_rating, 1); ?></div><div class="label">⭐ Середній рейтинг</div></div>
    </div>
    
    <div class="reviews-container">
        <div class="filter-buttons">
            <button class="filter-btn active" data-filter="all" onclick="filterReviews('all')">📋 Всі</button>
            <button class="filter-btn" data-filter="pending" onclick="filterReviews('pending')">⏳ На модерації</button>
            <button class="filter-btn" data-filter="approved" onclick="filterReviews('approved')">✅ Опубліковані</button>
        </div>
        
        <?php if(count($reviews) > 0): ?>
            <?php foreach($reviews as $review): ?>
            <?php 
            if ($hasApprovedColumn) { $isApproved = ($review['is_approved'] == 1); } 
            else { $isApproved = true; }
            $statusClass = $isApproved ? 'approved' : 'pending';
            $statusText = $isApproved ? '✅ Опубліковано' : '⏳ Очікує перевірки';
            ?>
            <div class="review-item" data-status="<?php echo $statusClass; ?>">
                <div class="review-header">
                    <div>
                        <strong><i class="bi bi-chat-dots"></i> Відгук #<?php echo $review['id']; ?></strong><br>
                        <small><i class="bi bi-calendar"></i> <?php echo date('d.m.Y H:i', strtotime($review['created_at'])); ?></small>
                    </div>
                    <div class="review-rating">
                        <?php for($i = 1; $i <= 5; $i++): ?>
                            <?php echo $i <= $review['rating'] ? '★' : '☆'; ?>
                        <?php endfor; ?>
                    </div>
                    <div><span class="review-status status-<?php echo $statusClass; ?>"><?php echo $statusText; ?></span></div>
                </div>
                <div class="review-comment"><?php echo nl2br(htmlspecialchars($review['comment'])); ?></div>
                <div class="review-meta">
                    <span><i class="bi bi-person"></i> Клієнт ID: <?php echo $review['client_id']; ?></span>
                    <?php if($review['doctor_id']): ?>
                        <span><i class="bi bi-person-badge"></i> Лікар ID: <?php echo $review['doctor_id']; ?></span>
                    <?php endif; ?>
                </div>
                <div style="margin-top: 15px;">
                    <button class="btn btn-response" onclick="showResponseForm(<?php echo $review['id']; ?>)"><i class="bi bi-reply"></i> Відповісти</button>
                    <button class="btn btn-delete" onclick="deleteReview(<?php echo $review['id']; ?>)"><i class="bi bi-trash"></i> Видалити</button>
                </div>
                <div id="responseForm_<?php echo $review['id']; ?>" style="display: none; margin-top: 15px;">
                    <textarea id="responseText_<?php echo $review['id']; ?>" rows="3" placeholder="Введіть відповідь на відгук..."></textarea>
                    <button class="btn btn-response" onclick="saveResponse(<?php echo $review['id']; ?>)">📤 Надіслати відповідь</button>
                    <button class="btn" onclick="hideResponseForm(<?php echo $review['id']; ?>)" style="background:#6c757d; color:white;">Скасувати</button>
                </div>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="empty-state"><i class="bi bi-chat-dots"></i><p>Немає відгуків для відображення</p></div>
        <?php endif; ?>
    </div>
</div>

<script>
function filterReviews(status) {
    var items = document.querySelectorAll('.review-item');
    items.forEach(function(item) {
        item.style.display = (status === 'all' || item.dataset.status === status) ? 'block' : 'none';
    });
    var btns = document.querySelectorAll('.filter-btn');
    btns.forEach(function(btn) {
        btn.classList.remove('active');
        if (btn.getAttribute('data-filter') === status) btn.classList.add('active');
    });
}
function deleteReview(id) {
    if (confirm('Видалити цей відгук?')) {
        fetch('api/moderate_review.php', { method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: 'id=' + id + '&action=delete' })
        .then(r => r.json()).then(d => { if(d.success) { alert('Відгук видалено!'); location.reload(); } else { alert('Помилка: ' + d.message); } });
    }
}
function showResponseForm(id) { var f = document.getElementById('responseForm_' + id); f.style.display = f.style.display === 'none' ? 'block' : 'none'; }
function hideResponseForm(id) { document.getElementById('responseForm_' + id).style.display = 'none'; }
function saveResponse(id) {
    var response = document.getElementById('responseText_' + id).value;
    if (!response.trim()) { alert('Введіть текст відповіді'); return; }
    fetch('api/moderate_review.php', { method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: 'id=' + id + '&action=respond&response=' + encodeURIComponent(response) })
    .then(r => r.json()).then(d => { if(d.success) { alert('Відповідь збережено!'); location.reload(); } else { alert('Помилка: ' + d.message); } });
}
</script>
</body>
</html>