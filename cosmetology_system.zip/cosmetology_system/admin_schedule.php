<?php
session_start();
require_once 'includes/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Отримуємо дату (за замовчуванням - сьогодні)
$selected_date = $_GET['date'] ?? date('Y-m-d');
$selected_room = $_GET['room'] ?? 'all';

// Отримуємо всі кабінети
$rooms = $pdo->query("SELECT * FROM rooms ORDER BY room_number")->fetchAll();

// Отримуємо розклад для вибраної дати
$schedule_sql = "
    SELECT rs.*, 
           r.room_number, r.name as room_name,
           u.full_name as doctor_name,
           p.full_name as patient_name,
           s.name as service_name
    FROM room_schedule rs
    JOIN rooms r ON rs.room_id = r.id
    LEFT JOIN cosmetologists c ON rs.doctor_id = c.id
    LEFT JOIN users u ON c.user_id = u.id
    LEFT JOIN users p ON rs.patient_id = p.id
    LEFT JOIN appointments a ON rs.appointment_id = a.id
    LEFT JOIN services s ON a.service_id = s.id
    WHERE rs.date = ?
";

if ($selected_room != 'all') {
    $schedule_sql .= " AND rs.room_id = ?";
}

$schedule_sql .= " ORDER BY rs.start_time ASC";

$stmt = $pdo->prepare($schedule_sql);
if ($selected_room != 'all') {
    $stmt->execute([$selected_date, $selected_room]);
} else {
    $stmt->execute([$selected_date]);
}
$schedule_items = $stmt->fetchAll();

// Групуємо по кабінетах
$schedule_by_room = [];
foreach ($schedule_items as $item) {
    $schedule_by_room[$item['room_id']][] = $item;
}

// Отримуємо статистику на день
$stats = $pdo->prepare("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
        SUM(CASE WHEN status = 'scheduled' THEN 1 ELSE 0 END) as scheduled
    FROM room_schedule WHERE date = ?
");
$stats->execute([$selected_date]);
$day_stats = $stats->fetch();
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>Розклад по кабінетах | Cosmology Beauty</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f0eb; }
        
        .sidebar {
            width: 260px;
            background: #2c2c2c;
            color: white;
            position: fixed;
            height: 100%;
            padding: 20px;
        }
        .sidebar h3 { margin-bottom: 30px; color: #c7a17a; text-align: center; }
        .sidebar a {
            color: #ddd;
            text-decoration: none;
            display: block;
            padding: 12px;
            margin: 5px 0;
            border-radius: 10px;
        }
        .sidebar a:hover, .sidebar a.active { background: #c7a17a; color: white; }
        
        .content {
            margin-left: 260px;
            padding: 30px;
        }
        
        .header-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .date-nav {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        .date-nav button {
            background: #c7a17a;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 8px;
            cursor: pointer;
        }
        .date-nav input {
            padding: 8px;
            border: 2px solid #f0e6dc;
            border-radius: 8px;
        }
        
        .stats-bar {
            display: flex;
            gap: 20px;
            background: white;
            padding: 15px 20px;
            border-radius: 15px;
            margin-bottom: 20px;
        }
        .stat-item { text-align: center; }
        .stat-number { font-size: 24px; font-weight: bold; color: #c7a17a; }
        
        .room-filter {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }
        .room-filter a {
            background: white;
            padding: 8px 20px;
            border-radius: 20px;
            text-decoration: none;
            color: #2c2c2c;
        }
        .room-filter a.active {
            background: #c7a17a;
            color: white;
        }
        
        /* Календар кабінетів */
        .rooms-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 20px;
        }
        
        .room-card {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .room-header {
            background: linear-gradient(135deg, #c7a17a, #a67c52);
            color: white;
            padding: 15px 20px;
        }
        .room-header h3 { font-size: 20px; }
        .room-header p { font-size: 12px; opacity: 0.9; }
        
        .schedule-list {
            padding: 15px;
        }
        
        .schedule-item {
            display: flex;
            align-items: center;
            padding: 12px;
            margin-bottom: 10px;
            background: #f9f5f0;
            border-radius: 12px;
            transition: all 0.3s;
        }
        .schedule-item:hover { transform: translateX(5px); }
        
        .schedule-time {
            min-width: 100px;
            font-weight: bold;
            color: #c7a17a;
        }
        
        .schedule-info {
            flex: 1;
        }
        .schedule-patient {
            font-weight: bold;
            color: #2c2c2c;
        }
        .schedule-service {
            font-size: 12px;
            color: #666;
        }
        
        .schedule-status {
            width: 30px;
            text-align: center;
        }
        .status-scheduled { color: #ffc107; }
        .status-in_progress { color: #17a2b8; }
        .status-completed { color: #28a745; }
        .status-cancelled { color: #dc3545; }
        
        .empty-schedule {
            text-align: center;
            padding: 30px;
            color: #999;
        }
        
        .btn-add {
            background: #28a745;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 12px;
        }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        .modal-content {
            background: white;
            padding: 30px;
            border-radius: 20px;
            width: 500px;
            max-width: 90%;
        }
        .modal-content input, .modal-content select {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 8px;
        }
        
        @media (max-width: 900px) {
            .sidebar { width: 80px; }
            .sidebar a span:not(.icon) { display: none; }
            .content { margin-left: 80px; }
            .rooms-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    
 <div class="sidebar">
    <h3>✨ Cosmology</h3>
    
    <a href="admin_dashboard.php">
        <i class="bi bi-house-door"></i>
        <span>Головна</span>
    </a>
    
    <a href="admin_clients.php">
        <i class="bi bi-people"></i>
        <span>Клієнти</span>
    </a>
    
    <a href="admin_doctors.php">
        <i class="bi bi-person-badge"></i>
        <span>Лікарі</span>
    </a>
    
    <a href="admin_services.php">
        <i class="bi bi-grid-3x3-gap-fill"></i>
        <span>Послуги</span>
    </a>
    
    <a href="admin_appointments.php">
        <i class="bi bi-calendar-check"></i>
        <span>Записи</span>
        <span class="badge">17</span> <!-- цифра, як на одному зі скріншотів -->
    </a>
    
    <a href="admin_certificates.php">
        <i class="bi bi-patch-check"></i>
        <span>Сертифікати</span>
    </a>
    
    <a href="admin_stock.php">
        <i class="bi bi-box-seam"></i>
        <span>Склад</span>
    </a>
    
    <a href="admin_stock_orders.php">
        <i class="bi bi-cart"></i>
        <span>Замовлення</span>
    </a>
    
    <a href="logout.php">
        <i class="bi bi-box-arrow-right"></i>
        <span>Вихід</span>
    </a>
</div>
  
    
    <div class="content">
        <div class="header-bar">
            <h1>📆 Розклад по кабінетах</h1>
            <div class="date-nav">
                <button onclick="changeDate(-1)">◀ Попередній</button>
                <input type="date" id="datePicker" value="<?= $selected_date ?>">
                <button onclick="changeDate(1)">Наступний ▶</button>
            </div>
        </div>
        
        <div class="stats-bar">
            <div class="stat-item">
                <div class="stat-number"><?= date('d.m.Y', strtotime($selected_date)) ?></div>
                <div>📅 Дата</div>
            </div>
            <div class="stat-item">
                <div class="stat-number"><?= ucfirst(date('l', strtotime($selected_date))) ?></div>
                <div>📆 День тижня</div>
            </div>
            <div class="stat-item">
                <div class="stat-number"><?= $day_stats['total'] ?? 0 ?></div>
                <div>📋 Всього прийомів</div>
            </div>
            <div class="stat-item">
                <div class="stat-number"><?= $day_stats['completed'] ?? 0 ?></div>
                <div>✅ Завершено</div>
            </div>
        </div>
        
        <div class="room-filter">
            <a href="?date=<?= $selected_date ?>&room=all" class="<?= $selected_room == 'all' ? 'active' : '' ?>">📌 Всі кабінети</a>
            <?php foreach($rooms as $room): ?>
                <a href="?date=<?= $selected_date ?>&room=<?= $room['id'] ?>" class="<?= $selected_room == $room['id'] ? 'active' : '' ?>">
                    🚪 Каб. <?= htmlspecialchars($room['room_number']) ?> (<?= htmlspecialchars($room['name']) ?>)
                </a>
            <?php endforeach; ?>
        </div>
        
        <div class="rooms-grid">
            <?php foreach($rooms as $room): ?>
                <?php if ($selected_room != 'all' && $selected_room != $room['id']) continue; ?>
                <div class="room-card">
                    <div class="room-header">
                        <h3>🚪 Кабінет <?= htmlspecialchars($room['room_number']) ?></h3>
                        <p><?= htmlspecialchars($room['name']) ?> | Поверх <?= $room['floor'] ?></p>
                    </div>
                    <div class="schedule-list">
                        <?php if(isset($schedule_by_room[$room['id']]) && count($schedule_by_room[$room['id']]) > 0): ?>
                            <?php foreach($schedule_by_room[$room['id']] as $item): ?>
                                <div class="schedule-item">
                                    <div class="schedule-time">
                                        <?= date('H:i', strtotime($item['start_time'])) ?> - <?= date('H:i', strtotime($item['end_time'])) ?>
                                    </div>
                                    <div class="schedule-info">
                                        <div class="schedule-patient">👤 <?= htmlspecialchars($item['patient_name'] ?? '-') ?></div>
                                        <div class="schedule-service">💆 <?= htmlspecialchars($item['service_name'] ?? '-') ?></div>
                                        <div class="schedule-doctor">👩‍⚕️ Лікар: <?= htmlspecialchars($item['doctor_name'] ?? '-') ?></div>
                                    </div>
                                    <div class="schedule-status">
                                        <?php if($item['status'] == 'scheduled'): ?>
                                            <span class="status-scheduled" title="Заплановано">⏳</span>
                                        <?php elseif($item['status'] == 'in_progress'): ?>
                                            <span class="status-in_progress" title="В процесі">🔄</span>
                                        <?php elseif($item['status'] == 'completed'): ?>
                                            <span class="status-completed" title="Завершено">✅</span>
                                        <?php else: ?>
                                            <span class="status-cancelled" title="Скасовано">❌</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="empty-schedule">
                                📭 Немає записів у цьому кабінеті на <?= date('d.m.Y', strtotime($selected_date)) ?>
                                <button class="btn-add" onclick="addToSchedule(<?= $room['id'] ?>)">+ Додати запис</button>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <!-- Модальне вікно для додавання запису -->
    <div id="scheduleModal" class="modal">
        <div class="modal-content">
            <h3>➕ Додати запис у розклад</h3>
            <form id="scheduleForm">
                <input type="hidden" name="room_id" id="schedule_room_id">
                <input type="hidden" name="date" value="<?= $selected_date ?>">
                
                <label>👤 Пацієнт:</label>
                <select name="patient_id" id="patient_id" required>
                    <option value="">-- Оберіть пацієнта --</option>
                    <?php
                    $patients = $pdo->query("SELECT id, full_name, phone FROM users WHERE role = 'client' ORDER BY full_name")->fetchAll();
                    foreach($patients as $p):
                    ?>
                        <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['full_name']) ?> (<?= $p['phone'] ?>)</option>
                    <?php endforeach; ?>
                </select>
                
                <label>👩‍⚕️ Лікар:</label>
                <select name="doctor_id" id="doctor_id" required>
                    <option value="">-- Оберіть лікаря --</option>
                    <?php
                    $doctors = $pdo->query("
                        SELECT c.id, u.full_name 
                        FROM cosmetologists c 
                        JOIN users u ON c.user_id = u.id
                    ")->fetchAll();
                    foreach($doctors as $d):
                    ?>
                        <option value="<?= $d['id'] ?>"><?= htmlspecialchars($d['full_name']) ?></option>
                    <?php endforeach; ?>
                </select>
                
                <label>💆 Послуга:</label>
                <select name="service_id" id="service_id" required>
                    <option value="">-- Оберіть послугу --</option>
                    <?php
                    $services = $pdo->query("SELECT id, name, price, duration_minutes FROM services WHERE is_active = 1")->fetchAll();
                    foreach($services as $s):
                    ?>
                        <option value="<?= $s['id'] ?>" data-duration="<?= $s['duration_minutes'] ?>"><?= htmlspecialchars($s['name']) ?> (<?= $s['price'] ?> грн, <?= $s['duration_minutes'] ?> хв)</option>
                    <?php endforeach; ?>
                </select>
                
                <label>⏰ Час початку:</label>
                <input type="time" name="start_time" id="start_time" required>
                
                <label>⏰ Час закінчення:</label>
                <input type="time" name="end_time" id="end_time" readonly style="background:#f0e6dc;">
                
                <div style="display: flex; gap: 10px; margin-top: 20px;">
                    <button type="submit" class="btn-add" style="background:#28a745; padding:10px;">✅ Зберегти</button>
                    <button type="button" onclick="closeModal()" style="background:#dc3545; color:white; padding:10px; border:none; border-radius:8px;">❌ Скасувати</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function confirmLogout() {
        if (confirm('Ви дійсно хочете вийти з акаунту адміністратора?')) {
            window.location.href = 'logout.php';
        }
    }
    
    function changeDate(delta) {
        let currentDate = new Date(document.getElementById('datePicker').value);
        currentDate.setDate(currentDate.getDate() + delta);
        let newDate = currentDate.toISOString().split('T')[0];
        window.location.href = `?date=${newDate}&room=<?= $selected_room ?>`;
    }
    
    document.getElementById('datePicker').addEventListener('change', function() {
        window.location.href = `?date=${this.value}&room=<?= $selected_room ?>`;
    });
    
    function addToSchedule(roomId) {
        document.getElementById('schedule_room_id').value = roomId;
        document.getElementById('scheduleModal').style.display = 'flex';
    }
    
    function closeModal() {
        document.getElementById('scheduleModal').style.display = 'none';
    }
    
    // Автоматичний розрахунок часу закінчення
    document.getElementById('service_id').addEventListener('change', function() {
        let duration = this.options[this.selectedIndex]?.dataset.duration || 60;
        let startTime = document.getElementById('start_time').value;
        if (startTime) {
            let [hours, minutes] = startTime.split(':');
            let endDate = new Date();
            endDate.setHours(parseInt(hours));
            endDate.setMinutes(parseInt(minutes) + parseInt(duration));
            let endHours = String(endDate.getHours()).padStart(2, '0');
            let endMinutes = String(endDate.getMinutes()).padStart(2, '0');
            document.getElementById('end_time').value = `${endHours}:${endMinutes}`;
        }
    });
    
    document.getElementById('start_time').addEventListener('change', function() {
        let duration = document.getElementById('service_id').options[document.getElementById('service_id').selectedIndex]?.dataset.duration || 60;
        let [hours, minutes] = this.value.split(':');
        let endDate = new Date();
        endDate.setHours(parseInt(hours));
        endDate.setMinutes(parseInt(minutes) + parseInt(duration));
        let endHours = String(endDate.getHours()).padStart(2, '0');
        let endMinutes = String(endDate.getMinutes()).padStart(2, '0');
        document.getElementById('end_time').value = `${endHours}:${endMinutes}`;
    });
    
    document.getElementById('scheduleForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        fetch('api/add_schedule_item.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams(new FormData(this))
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Помилка: ' + data.error);
            }
        });
    });
    </script>
</body>
</html>