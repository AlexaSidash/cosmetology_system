<?php
// includes/language.php
session_start();

// Українські переклади за замовчуванням (вбудовані, без окремих файлів)
$translations = [
    'nav_home' => 'Головна',
    'about_us' => 'Про нас',
    'price_list' => 'Прайс',
    'loyalty_program' => 'Програма лояльності',
    'nav_doctors' => 'Лікарі',
    'btn_book' => 'Записатися',
    'nav_admin' => 'Адмін',
    'nav_logout' => 'Вихід',
    'nav_login' => 'Вхід',
    'nav_cabinet' => 'Кабінет',
    'register' => 'Реєстрація',
    'title_home' => 'Головна',
    'hero_title' => 'Ваша краса —',
    'hero_title_span' => 'наша турбота',
    'hero_text' => 'Професійна косметологія з використанням сучасних методик та преміальних засобів',
    'btn_book_online' => 'Записатися онлайн',
    'our_services' => 'Наші',
    'services_highlight' => 'послуги',
    'new_client_discount' => 'Нова клієнтка отримує знижку 20% на перший візит',
    'injection_cosmetology' => 'Ін\'єкційна косметологія',
    'apparatus_cosmetology' => 'Апаратна косметологія',
    'laser_cosmetology' => 'Лазерна косметологія',
    'laser_epilation' => 'Лазерна епіляція',
    'intimate_cosmetology' => 'Інтимна косметологія',
    'care_procedures' => 'Доглядові процедури',
    'dermatology' => 'Дерматологія',
    'injection_desc' => 'Ботокс, філери, мезотерапія',
    'apparatus_desc' => 'RF-ліфтинг, ультразвук',
    'laser_desc' => 'Фраксель, лазерне шліфування',
    'epilation_desc' => 'Безболісне видалення волосся',
    'intimate_desc' => 'Інтимне омолодження',
    'care_desc' => 'Чистки, пілінги, маски',
    'dermatology_desc' => 'Лікування шкіри, акне, дерматологічні захворювання',
    'footer_text' => 'Ваша краса - наша турбота. Професійна косметологія з використанням сучасних методик та преміальних засобів.',
    'contacts' => 'Контакти',
    'address' => 'м. Дніпро, вул. Косметологічна, 15',
    'working_hours' => 'Години роботи',
    'mon_fri' => 'Пн-Пт',
    'saturday' => 'Сб',
    'sunday' => 'Нд',
    'day_off' => 'Вихідний',
    'social_media' => 'Соціальні мережі',
    'system_access' => 'Доступ до системи',
    'client_login' => 'Вхід для клієнтів',
    'doctor_login' => 'Вхід для лікарів',
    'admin_login' => 'Вхід для адміністратора',
    'footer_copyright' => 'Всі права захищено',
    'phone' => 'Тел',
    'theme_toggle' => 'Змінити тему',
    'doctor_cabinet' => 'Кабінет лікаря',
    'logout_confirm' => 'Ви дійсно хочете вийти?',
];

// Англійські переклади
$translations_en = [
    'nav_home' => 'Home',
    'about_us' => 'About Us',
    'price_list' => 'Price List',
    'loyalty_program' => 'Loyalty Program',
    'nav_doctors' => 'Doctors',
    'btn_book' => 'Book Now',
    'nav_admin' => 'Admin',
    'nav_logout' => 'Logout',
    'nav_login' => 'Login',
    'nav_cabinet' => 'Cabinet',
    'register' => 'Register',
    'title_home' => 'Home',
    'hero_title' => 'Your beauty —',
    'hero_title_span' => 'our care',
    'hero_text' => 'Professional cosmetology using modern methods and premium products',
    'btn_book_online' => 'Book Online',
    'our_services' => 'Our',
    'services_highlight' => 'Services',
    'new_client_discount' => 'New client gets 20% discount on first visit',
    'injection_cosmetology' => 'Injection Cosmetology',
    'apparatus_cosmetology' => 'Apparatus Cosmetology',
    'laser_cosmetology' => 'Laser Cosmetology',
    'laser_epilation' => 'Laser Epilation',
    'intimate_cosmetology' => 'Intimate Cosmetology',
    'care_procedures' => 'Care Procedures',
    'dermatology' => 'Dermatology',
    'injection_desc' => 'Botox, fillers, mesotherapy',
    'apparatus_desc' => 'RF-lifting, ultrasound',
    'laser_desc' => 'Fraxel, laser resurfacing',
    'epilation_desc' => 'Painless hair removal',
    'intimate_desc' => 'Intimate rejuvenation',
    'care_desc' => 'Cleanings, peels, masks',
    'dermatology_desc' => 'Skin treatment, acne, dermatological diseases',
    'footer_text' => 'Your beauty is our care. Professional cosmetology using modern methods.',
    'contacts' => 'Contacts',
    'address' => 'Dnipro, Cosmetology St., 15',
    'working_hours' => 'Working Hours',
    'mon_fri' => 'Mon-Fri',
    'saturday' => 'Sat',
    'sunday' => 'Sun',
    'day_off' => 'Day off',
    'social_media' => 'Social Media',
    'system_access' => 'System Access',
    'client_login' => 'Client Login',
    'doctor_login' => 'Doctor Login',
    'admin_login' => 'Admin Login',
    'footer_copyright' => 'All rights reserved',
    'phone' => 'Tel',
    'theme_toggle' => 'Change theme',
    'doctor_cabinet' => 'Doctor Cabinet',
    'logout_confirm' => 'Are you sure you want to logout?',
];

// Визначаємо поточну мову
$current_lang = $_COOKIE['lang'] ?? 'uk';
if (!in_array($current_lang, ['uk', 'en'])) {
    $current_lang = 'uk';
}

// Вибираємо потрібний масив перекладів
$trans = ($current_lang == 'en') ? $translations_en : $translations;

// Функція перекладу
function __($key) {
    global $trans;
    return $trans[$key] ?? $key;
}
?>