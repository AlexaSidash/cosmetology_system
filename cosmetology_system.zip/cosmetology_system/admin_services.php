<?php
session_start();
require_once 'includes/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Додавання послуги
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_service'])) {
    $stmt = $pdo->prepare("INSERT INTO services (name, duration_minutes, price, is_active) VALUES (?, ?, ?, 1)");
    $stmt->execute([$_POST['name'], $_POST['duration_minutes'], $_POST['price']]);
}

// Видалення
if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM services WHERE id = ?");
    $stmt->execute([$_GET['delete']]);
    header("Location: admin_services.php");
    exit();
}

$services = $pdo->query("SELECT * FROM services ORDER BY id DESC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>Послуги | Cosmology Beauty</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f0eb; }
        .sidebar {
            width: 260px;
            background: #2c2c2c;
            color: white;
            position: fixed;
            height: 100%;
            padding: 20px;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 12px;
            margin: 5px 0;
            border-radius: 10px;
        }
        .sidebar a:hover { background: #c7a17a; }
        .content {
            margin-left: 260px;
            padding: 30px;
        }
        .add-form {
            background: white;
            padding: 20px;
            border-radius: 15px;
            margin-bottom: 20px;
        }
        .add-form input {
            padding: 10px;
            margin: 5px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        table {
            width: 100%;
            background: white;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        th { background: #c7a17a; color: white; }
        .btn-delete { color: #dc3545; text-decoration: none; }
    </style>
</head>
<body>
 

  <div class="sidebar">
    <h3>✨ Cosmology</h3>
    <a href="admin_dashboard.php"><i class="bi bi-house-door-fill"></i><span>Головна</span></a>
    <a href="admin_clients.php"><i class="bi bi-people-fill"></i><span>Клієнти</span></a>
    <a href="admin_doctors.php"><i class="bi bi-person-badge-fill"></i><span>Лікарі</span></a>
    <a href="admin_services.php" class="active" style="background: #c7a17a; color: white;"><i class="bi bi-grid-3x3-gap-fill"></i><span>Послуги</span></a>
    <a href="admin_appointments.php"><i class="bi bi-calendar-check-fill"></i><span>Записи</span></a>
    <a href="admin_certificates.php"><i class="bi bi-patch-check-fill"></i><span>Сертифікати</span></a>
    <a href="admin_stock.php"><i class="bi bi-box-seam-fill"></i><span>Склад</span></a>
    <a href="admin_stock_orders.php"><i class="bi bi-cart-fill"></i><span>Замовлення</span></a>
    <a href="admin_reviews.php"><i class="bi bi-star-fill"></i><span>Відгуки</span></a>
    <a href="admin_finance.php"><i class="bi bi-graph-up"></i><span>Фінанси</span></a>
    <a href="logout.php"><i class="bi bi-box-arrow-right"></i><span>Вихід</span></a>
</div>

    <div class="content">
        <h1>💆‍♀️ Управління послугами</h1>
        
        <div class="add-form">
            <form method="POST">
                <input type="text" name="name" placeholder="Назва послуги" required>
                <input type="number" name="duration_minutes" placeholder="Тривалість (хв)" required>
                <input type="number" name="price" placeholder="Ціна (грн)" required>
                <button type="submit" name="add_service">➕ Додати</button>
            </form>
        </div>
        
        <table>
            <thead><tr><th>ID</th><th>Назва</th><th>Тривалість</th><th>Ціна</th><th>Дії</th></tr></thead>
            <tbody>
                <?php foreach($services as $s): ?>
                <tr>
                    <td><?= $s['id'] ?></td>
                    <td><?= htmlspecialchars($s['name']) ?></td>
                    <td><?= $s['duration_minutes'] ?> хв</td>
                    <td><?= number_format($s['price'], 0) ?> грн</td>
                    <td><a href="?delete=<?= $s['id'] ?>" class="btn-delete" onclick="return confirm('Видалити?')">🗑️</a></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>