<?php
namespace App\Middleware;

use App\Services\LanguageService;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
use Slim\Views\Twig;

class LanguageMiddleware
{
    private $twig;
    private $languageService;
    
    public function __construct(Twig $twig)
    {
        $this->twig = $twig;
        $this->languageService = new LanguageService();
    }
    
    public function __invoke(Request $request, RequestHandler $handler)
    {
        // Додаємо функцію trans() у Twig
        $this->twig->getEnvironment()->addFunction(new \Twig\TwigFunction('trans', function ($key) {
            return $this->languageService->trans($key);
        }));
        
        // Додаємо змінну поточної мови
        $this->twig->getEnvironment()->addGlobal('current_lang', $this->languageService->getCurrentLanguage());
        $this->twig->getEnvironment()->addGlobal('available_langs', $this->languageService->getAvailableLanguages());
        
        return $handler->handle($request);
    }
}