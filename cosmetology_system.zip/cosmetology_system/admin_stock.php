<?php
session_start();
require_once 'includes/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Отримуємо статистику складу
$stats = $pdo->query("
    SELECT 
        (SELECT COUNT(*) FROM stock_items) as total_items,
        (SELECT SUM(quantity) FROM stock_items) as total_quantity,
        (SELECT COUNT(*) FROM stock_items WHERE quantity <= min_quantity) as low_stock,
        (SELECT COUNT(*) FROM stock_items WHERE quantity = 0) as out_of_stock,
        (SELECT COUNT(*) FROM stock_requests WHERE status = 'pending') as pending_requests,
        (SELECT COUNT(*) FROM stock_orders WHERE status = 'new') as new_orders
")->fetch();

// Товари з низьким запасом (червоні)
$low_stock_items = $pdo->query("
    SELECT * FROM stock_items 
    WHERE quantity <= min_quantity 
    ORDER BY quantity ASC
    LIMIT 20
")->fetchAll();

// Товари з нульовим запасом
$out_of_stock_items = $pdo->query("
    SELECT * FROM stock_items 
    WHERE quantity = 0 
    ORDER BY name ASC
")->fetchAll();

// Заявки очікують
$pending_requests = $pdo->query("
    SELECT sr.*, si.name as item_name, u.full_name as requester_name
    FROM stock_requests sr
    JOIN stock_items si ON sr.item_id = si.id
    JOIN users u ON sr.requested_by = u.id
    WHERE sr.status = 'pending'
    ORDER BY sr.request_date DESC
")->fetchAll();

// Останні витрати
$recent_consumption = $pdo->query("
    SELECT sc.*, si.name as item_name, r.room_number
    FROM stock_consumption sc
    JOIN stock_items si ON sc.item_id = si.id
    LEFT JOIN rooms r ON sc.room_id = r.id
    ORDER BY sc.consumption_date DESC
    LIMIT 10
")->fetchAll();

// Отримуємо категорії та кабінети для форми
$categories = $pdo->query("SELECT * FROM stock_categories")->fetchAll();
$rooms = $pdo->query("SELECT * FROM rooms")->fetchAll();
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>Склад | Cosmology Beauty</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f0eb; }
        
        .sidebar {
            width: 260px;
            background: #2c2c2c;
            color: white;
            position: fixed;
            height: 100%;
            padding: 25px 20px;
        }
        .sidebar h3 { margin-bottom: 30px; color: #c7a17a; text-align: center; font-size: 24px; }
        .sidebar a {
            color: #ddd;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 15px;
            margin: 5px 0;
            border-radius: 12px;
        }
        .sidebar a:hover, .sidebar a.active { background: #c7a17a; color: white; }
        
        .content {
            margin-left: 260px;
            padding: 30px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 20px;
            text-align: center;
            transition: transform 0.3s;
        }
        .stat-card:hover { transform: translateY(-3px); }
        .stat-number { font-size: 32px; font-weight: bold; }
        .stat-label { font-size: 13px; color: #666; margin-top: 5px; }
        .stat-warning .stat-number { color: #ffc107; }
        .stat-danger .stat-number { color: #dc3545; }
        .stat-success .stat-number { color: #28a745; }
        .stat-info .stat-number { color: #17a2b8; }
        
        .items-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 15px;
        }
        .stock-item {
            background: white;
            border-radius: 15px;
            padding: 15px;
            border-left: 5px solid;
            transition: transform 0.3s;
        }
        .stock-item:hover { transform: translateX(5px); }
        .stock-item.normal { border-left-color: #28a745; }
        .stock-item.low { border-left-color: #ffc107; background: #fffef3; }
        .stock-item.out { border-left-color: #dc3545; background: #fff5f5; }
        
        .item-name { font-weight: bold; font-size: 16px; margin-bottom: 5px; }
        .item-code { font-size: 11px; color: #999; }
        .item-quantity { font-size: 24px; font-weight: bold; margin: 10px 0; }
        .item-quantity.low { color: #ffc107; }
        .item-quantity.out { color: #dc3545; }
        .item-min { font-size: 12px; color: #666; }
        
        .badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: bold;
        }
        .badge-warning { background: #ffc107; color: #333; }
        .badge-danger { background: #dc3545; color: white; }
        .badge-success { background: #28a745; color: white; }
        
        .alert-banner {
            background: #dc3545;
            color: white;
            padding: 12px 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .tabs {
            display: flex;
            gap: 10px;
            margin: 20px 0;
            flex-wrap: wrap;
        }
        .tab-btn {
            background: white;
            border: none;
            padding: 10px 20px;
            border-radius: 30px;
            cursor: pointer;
            transition: all 0.3s;
        }
        .tab-btn.active { background: #c7a17a; color: white; }
        
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        
        table {
            width: 100%;
            background: white;
            border-radius: 15px;
            border-collapse: collapse;
            overflow-x: auto;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #f0e6dc;
        }
        th { background: #c7a17a; color: white; }
        
        .btn {
            padding: 5px 12px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 12px;
            border: none;
            cursor: pointer;
        }
        .btn-primary { background: #c7a17a; color: white; }
        .btn-success { background: #28a745; color: white; }
        .btn-danger { background: #dc3545; color: white; }
        
        .form-group { margin-bottom: 15px; }
        .form-control {
            width: 100%;
            padding: 10px;
            border: 2px solid #f0e6dc;
            border-radius: 10px;
        }
        
        @media (max-width: 900px) {
            .sidebar { width: 80px; }
            .sidebar a span:not(.icon) { display: none; }
            .content { margin-left: 80px; }
        }
    </style>
</head>
<body>
  

    
   
    
    
   <div class="sidebar">
    <h3>✨ Cosmology</h3>
    <a href="admin_dashboard.php"><i class="bi bi-house-door-fill"></i><span>Головна</span></a>
    <a href="admin_clients.php"><i class="bi bi-people-fill"></i><span>Клієнти</span></a>
    <a href="admin_doctors.php"><i class="bi bi-person-badge-fill"></i><span>Лікарі</span></a>
    <a href="admin_services.php"><i class="bi bi-grid-3x3-gap-fill"></i><span>Послуги</span></a>
    <a href="admin_appointments.php"><i class="bi bi-calendar-check-fill"></i><span>Записи</span></a>
    <a href="admin_certificates.php"><i class="bi bi-patch-check-fill"></i><span>Сертифікати</span></a>
    <a href="admin_stock.php" class="active" style="background: #c7a17a; color: white;"><i class="bi bi-box-seam-fill"></i><span>Склад</span></a>
    <a href="admin_stock_orders.php"><i class="bi bi-cart-fill"></i><span>Замовлення</span></a>
    <a href="admin_reviews.php"><i class="bi bi-star-fill"></i><span>Відгуки</span></a>
    <a href="admin_finance.php"><i class="bi bi-graph-up"></i><span>Фінанси</span></a>
    <a href="logout.php"><i class="bi bi-box-arrow-right"></i><span>Вихід</span></a>
</div>
</div>
    
    <div class="content">
        <h1>📦 Склад та матеріали</h1>
        
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?= $stats['total_items'] ?? 0 ?></div>
                <div class="stat-label">📋 Всього позицій</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= $stats['total_quantity'] ?? 0 ?></div>
                <div class="stat-label">🔢 Одиниць на складі</div>
            </div>
            <div class="stat-card stat-warning">
                <div class="stat-number"><?= $stats['low_stock'] ?? 0 ?></div>
                <div class="stat-label">⚠️ Закінчується</div>
            </div>
            <div class="stat-card stat-danger">
                <div class="stat-number"><?= $stats['out_of_stock'] ?? 0 ?></div>
                <div class="stat-label">❌ Закінчилось</div>
            </div>
            <div class="stat-card stat-info">
                <div class="stat-number"><?= $stats['pending_requests'] ?? 0 ?></div>
                <div class="stat-label">📝 Заявок очікує</div>
            </div>
            <div class="stat-card stat-success">
                <div class="stat-number"><?= $stats['new_orders'] ?? 0 ?></div>
                <div class="stat-label">🛒 Замовлень нових</div>
            </div>
        </div>
        
        <?php if(count($out_of_stock_items) > 0): ?>
        <div class="alert-banner">
            <div>
                🚨 <strong>Увага!</strong> Наступні товари закінчились:
                <?php 
                $names = array_column($out_of_stock_items, 'name');
                echo implode(', ', array_slice($names, 0, 5));
                if(count($names) > 5) echo ' та інші...';
                ?>
            </div>
            <a href="#out_of_stock" style="color:white; text-decoration:underline;">Переглянути →</a>
        </div>
        <?php endif; ?>
        
        <div class="tabs">
            <button class="tab-btn active" onclick="showTab('overview')">📊 Огляд</button>
            <button class="tab-btn" onclick="showTab('items')">📦 Товари</button>
            <button class="tab-btn" onclick="showTab('requests')">📝 Заявки</button>
            <button class="tab-btn" onclick="showTab('consumption')">📉 Витрати</button>
            <button class="tab-btn" onclick="showTab('add')">➕ Додати товар</button>
        </div>
        
        <div id="overviewTab" class="tab-content active">
            <h3>⚠️ Товари, що закінчуються (нижче мінімуму)</h3>
            <div class="items-grid">
                <?php if(count($low_stock_items) > 0): ?>
                    <?php foreach($low_stock_items as $item): ?>
                        <?php $is_out = $item['quantity'] == 0; ?>
                        <div class="stock-item <?= $is_out ? 'out' : 'low' ?>">
                            <div class="item-name"><?= htmlspecialchars($item['name']) ?></div>
                            <div class="item-code">Код: <?= htmlspecialchars($item['code']) ?></div>
                            <div class="item-quantity <?= $is_out ? 'out' : 'low' ?>">
                                <?= $item['quantity'] ?> шт
                            </div>
                            <div class="item-min">Мінімум: <?= $item['min_quantity'] ?> шт</div>
                            <div style="margin-top: 10px;">
                                <?php if($is_out): ?>
                                    <span class="badge badge-danger">❌ ЗАКІНЧИЛОСЬ</span>
                                <?php else: ?>
                                    <span class="badge badge-warning">⚠️ МАЛО</span>
                                <?php endif; ?>
                                <button class="btn btn-primary" style="float:right;" onclick="openOrderModal(<?= $item['id'] ?>, '<?= htmlspecialchars($item['name']) ?>')">📦 Замовити</button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>Всі товари в нормі ✅</p>
                <?php endif; ?>
            </div>
        </div>
        
        <div id="itemsTab" class="tab-content">
            <div style="overflow-x: auto;">
                <table>
                    <thead>
                        <tr><th>Код</th><th>Назва</th><th>Категорія</th><th>Кабінет</th><th>Кількість</th><th>Мінімум</th><th>Статус</th><th>Дії</th></tr>
                    </thead>
                    <tbody>
                        <?php
                        $all_items = $pdo->query("
                            SELECT si.*, sc.name as category_name, r.room_number 
                            FROM stock_items si
                            LEFT JOIN stock_categories sc ON si.category_id = sc.id
                            LEFT JOIN rooms r ON si.room_id = r.id
                            ORDER BY si.name
                        ")->fetchAll();
                        ?>
                        <?php foreach($all_items as $item): ?>
                        <tr>
                            <td><?= htmlspecialchars($item['code']) ?></td>
                            <td><?= htmlspecialchars($item['name']) ?></td>
                            <td><?= htmlspecialchars($item['category_name']) ?></td>
                            <td><?= $item['room_number'] ? 'Каб. '.$item['room_number'] : 'Загальний' ?></td>
                            <td>
                                <span style="color: <?= $item['quantity'] == 0 ? '#dc3545' : ($item['quantity'] <= $item['min_quantity'] ? '#ffc107' : '#28a745') ?>; font-weight:bold;">
                                    <?= $item['quantity'] ?> шт
                                </span>
                            </td>
                            <td><?= $item['min_quantity'] ?> шт</span>
                            <td>
                                <?php if($item['quantity'] == 0): ?>
                                    <span class="badge badge-danger">❌ Немає</span>
                                <?php elseif($item['quantity'] <= $item['min_quantity']): ?>
                                    <span class="badge badge-warning">⚠️ Мало</span>
                                <?php else: ?>
                                    <span class="badge badge-success">✅ В наявності</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button class="btn btn-primary" onclick="openConsumeModal(<?= $item['id'] ?>, '<?= htmlspecialchars($item['name']) ?>')">Списати</button>
                                <button class="btn btn-success" onclick="openOrderModal(<?= $item['id'] ?>, '<?= htmlspecialchars($item['name']) ?>')">Замовити</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div id="requestsTab" class="tab-content">
            <div style="overflow-x: auto;">
                <table>
                    <thead>
                        <tr><th>Дата</th><th>Товар</th><th>Кількість</th><th>Подав</th><th>Статус</th><th>Дії</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach($pending_requests as $req): ?>
                        <tr>
                            <td><?= date('d.m.Y', strtotime($req['request_date'])) ?></td>
                            <td><?= htmlspecialchars($req['item_name']) ?></td>
                            <td><?= $req['requested_quantity'] ?> шт</span>
                            <td><?= htmlspecialchars($req['requester_name']) ?></td>
                            <td><span class="badge badge-warning">⏳ Очікує</span></td>
                            <td>
                                <a href="?approve_request=<?= $req['id'] ?>" class="btn btn-success">✅ Підтвердити</a>
                                <a href="?reject_request=<?= $req['id'] ?>" class="btn btn-danger">❌ Відхилити</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div id="consumptionTab" class="tab-content">
            <div style="overflow-x: auto;">
                <table>
                    <thead>
                        <tr><th>Дата</th><th>Товар</th><th>Кількість</th><th>Кабінет</th><th>Причина</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach($recent_consumption as $cons): ?>
                        <tr>
                            <td><?= date('d.m.Y H:i', strtotime($cons['consumption_date'])) ?></td>
                            <td><?= htmlspecialchars($cons['item_name']) ?></td>
                            <td><?= $cons['quantity'] ?> шт</span>
                            <td><?= $cons['room_number'] ? 'Каб. '.$cons['room_number'] : '-' ?> </td>
                            <td><?= htmlspecialchars($cons['reason']) ?> </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div id="addTab" class="tab-content">
            <div style="background:white; border-radius:20px; padding:25px; max-width:600px;">
                <h3>➕ Додати новий товар</h3>
                <form method="POST" action="api/add_stock_item.php">
                    <div class="form-group">
                        <input type="text" name="name" placeholder="Назва товару" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <input type="text" name="code" placeholder="Код товару" class="form-control">
                    </div>
                    <div class="form-group">
                        <select name="category_id" class="form-control">
                            <option value="">-- Виберіть категорію --</option>
                            <?php foreach($categories as $cat): ?>
                                <option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <input type="number" name="quantity" placeholder="Кількість" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <input type="number" name="min_quantity" placeholder="Мінімальний залишок" class="form-control" value="5">
                    </div>
                    <div class="form-group">
                        <input type="number" step="0.01" name="price_purchase" placeholder="Закупівельна ціна" class="form-control">
                    </div>
                    <div class="form-group">
                        <select name="room_id" class="form-control">
                            <option value="">-- Кабінет --</option>
                            <?php foreach($rooms as $room): ?>
                                <option value="<?= $room['id'] ?>">Кабінет <?= htmlspecialchars($room['room_number']) ?> (<?= htmlspecialchars($room['name']) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-success" style="width:100%; padding:12px;">➕ Додати товар</button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Модальне вікно списання -->
    <div id="consumeModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); justify-content:center; align-items:center; z-index:1000;">
        <div style="background:white; padding:30px; border-radius:20px; width:400px; max-width:90%;">
            <h3>📉 Списання товару</h3>
            <form id="consumeForm">
                <input type="hidden" name="item_id" id="consume_item_id">
                <p>Товар: <strong id="consume_item_name"></strong></p>
                <div class="form-group">
                    <label>Кількість для списання:</label>
                    <input type="number" name="quantity" id="consume_quantity" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Причина списання:</label>
                    <select name="reason" class="form-control">
                        <option value="Використано на процедурі">Використано на процедурі</option>
                        <option value="Прострочено">Прострочено</option>
                        <option value="Зіпсовано">Зіпсовано</option>
                        <option value="Інвентаризація">Інвентаризація</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Кабінет:</label>
                    <select name="room_id" class="form-control">
                        <option value="">-- Оберіть кабінет --</option>
                        <?php foreach($rooms as $room): ?>
                            <option value="<?= $room['id'] ?>">Кабінет <?= $room['room_number'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div style="display:flex; gap:10px; margin-top:20px;">
                    <button type="submit" class="btn btn-danger">✅ Списання</button>
                    <button type="button" class="btn btn-primary" onclick="closeModal('consumeModal')">Скасувати</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function confirmLogout() {
        if (confirm('Ви дійсно хочете вийти?')) {
            window.location.href = 'logout.php';
        }
    }
    
    function showTab(tab) {
        document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
        document.getElementById(tab + 'Tab').classList.add('active');
        document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
        event.target.classList.add('active');
    }
    
    function openConsumeModal(id, name) {
        document.getElementById('consume_item_id').value = id;
        document.getElementById('consume_item_name').innerText = name;
        document.getElementById('consumeModal').style.display = 'flex';
    }
    
    function closeModal(modalId) {
        document.getElementById(modalId).style.display = 'none';
    }
    
    document.getElementById('consumeForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        fetch('api/consume_stock.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams(new FormData(this))
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('✅ Товар списано успішно!');
                location.reload();
            } else {
                alert('❌ Помилка: ' + data.error);
            }
        });
    });
    
    function openOrderModal(id, name) {
        let quantity = prompt(`Скільки замовити товару "${name}"?`, "10");
        if (quantity && quantity > 0) {
            fetch('api/create_order_request.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'item_id=' + id + '&quantity=' + quantity
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('✅ Заявку на замовлення створено!');
                    location.reload();
                } else {
                    alert('❌ Помилка: ' + data.error);
                }
            });
        }
    }
    </script>
</body>
</html>