<?php
session_start();
require_once 'includes/config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Створення замовлення
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create_order'])) {
    $supplier_id = $_POST['supplier_id'];
    $order_number = 'ORD-' . date('Ymd') . '-' . rand(100, 999);
    
    $stmt = $pdo->prepare("
        INSERT INTO stock_orders (order_number, supplier_id, order_date, status, created_by) 
        VALUES (?, ?, CURDATE(), 'new', ?)
    ");
    $stmt->execute([$order_number, $supplier_id, $_SESSION['user_id']]);
    $order_id = $pdo->lastInsertId();
    
    // Додаємо товари до замовлення
    $items = $_POST['items'] ?? [];
    $total_amount = 0;
    foreach ($items as $item_id => $quantity) {
        if ($quantity > 0) {
            // Отримуємо ціну товару
            $stmt = $pdo->prepare("SELECT price_purchase FROM stock_items WHERE id = ?");
            $stmt->execute([$item_id]);
            $price = $stmt->fetch()['price_purchase'] ?? 0;
            $total = $price * $quantity;
            $total_amount += $total;
            
            $stmt = $pdo->prepare("
                INSERT INTO stock_order_items (order_id, item_id, quantity, price, total) 
                VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->execute([$order_id, $item_id, $quantity, $price, $total]);
        }
    }
    
    // Оновлюємо загальну суму замовлення
    $stmt = $pdo->prepare("UPDATE stock_orders SET total_amount = ? WHERE id = ?");
    $stmt->execute([$total_amount, $order_id]);
    
    header("Location: admin_stock_orders.php?msg=created");
    exit();
}

// Підтвердження отримання замовлення
if (isset($_GET['receive'])) {
    $order_id = (int)$_GET['receive'];
    
    // Отримуємо товари в замовленні
    $stmt = $pdo->prepare("
        SELECT oi.item_id, oi.quantity 
        FROM stock_order_items oi 
        WHERE oi.order_id = ?
    ");
    $stmt->execute([$order_id]);
    $items = $stmt->fetchAll();
    
    // Додаємо товари на склад
    foreach ($items as $item) {
        $stmt = $pdo->prepare("UPDATE stock_items SET quantity = quantity + ? WHERE id = ?");
        $stmt->execute([$item['quantity'], $item['item_id']]);
    }
    
    // Оновлюємо статус замовлення
    $stmt = $pdo->prepare("UPDATE stock_orders SET status = 'received' WHERE id = ?");
    $stmt->execute([$order_id]);
    
    header("Location: admin_stock_orders.php?msg=received");
    exit();
}

// Скасування замовлення
if (isset($_GET['cancel'])) {
    $order_id = (int)$_GET['cancel'];
    $stmt = $pdo->prepare("UPDATE stock_orders SET status = 'cancelled' WHERE id = ?");
    $stmt->execute([$order_id]);
    header("Location: admin_stock_orders.php?msg=cancelled");
    exit();
}

// Отримуємо замовлення
$orders = $pdo->query("
    SELECT so.*, s.name as supplier_name 
    FROM stock_orders so
    JOIN stock_suppliers s ON so.supplier_id = s.id
    ORDER BY so.order_date DESC
")->fetchAll();

// Отримуємо товари з низьким запасом для замовлення
$low_stock_items = $pdo->query("
    SELECT si.*, sc.name as category_name 
    FROM stock_items si
    LEFT JOIN stock_categories sc ON si.category_id = sc.id
    WHERE si.quantity <= si.min_quantity
    ORDER BY si.quantity ASC
")->fetchAll();

// Отримуємо всі товари для замовлення
$all_items = $pdo->query("
    SELECT si.*, sc.name as category_name 
    FROM stock_items si
    LEFT JOIN stock_categories sc ON si.category_id = sc.id
    WHERE si.quantity > 0
    ORDER BY si.name ASC
")->fetchAll();

// Постачальники
$suppliers = $pdo->query("SELECT * FROM stock_suppliers")->fetchAll();

$message = '';
if (isset($_GET['msg'])) {
    if ($_GET['msg'] == 'created') $message = '✅ Замовлення створено успішно!';
    if ($_GET['msg'] == 'received') $message = '✅ Замовлення отримано, товари додано на склад!';
    if ($_GET['msg'] == 'cancelled') $message = '❌ Замовлення скасовано!';
}
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>Замовлення | Cosmology Beauty</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f0eb; }
        
        .sidebar {
            width: 260px;
            background: #2c2c2c;
            color: white;
            position: fixed;
            height: 100%;
            padding: 25px 20px;
        }
        .sidebar h3 { margin-bottom: 30px; color: #c7a17a; text-align: center; font-size: 24px; }
        .sidebar a {
            color: #ddd;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 15px;
            margin: 5px 0;
            border-radius: 12px;
            transition: all 0.3s;
        }
        .sidebar a:hover, .sidebar a.active { background: #c7a17a; color: white; }
        
        .content {
            margin-left: 260px;
            padding: 30px;
        }
        
        .message {
            background: #d4edda;
            color: #155724;
            padding: 12px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        
        .card {
            background: white;
            border-radius: 20px;
            padding: 25px;
            margin-bottom: 30px;
        }
        .card h3 {
            color: #c7a17a;
            margin-bottom: 20px;
            border-bottom: 2px solid #f0e6dc;
            padding-bottom: 10px;
        }
        
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; font-weight: 500; margin-bottom: 5px; }
        .form-group select, .form-group input {
            width: 100%;
            padding: 10px;
            border: 2px solid #f0e6dc;
            border-radius: 10px;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        .btn-primary { background: #c7a17a; color: white; }
        .btn-success { background: #28a745; color: white; }
        .btn-danger { background: #dc3545; color: white; }
        .btn-warning { background: #ffc107; color: #333; }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #f0e6dc;
        }
        th { background: #c7a17a; color: white; }
        
        .order-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            border-bottom: 1px solid #f0e6dc;
        }
        .order-item input { width: 80px; padding: 5px; }
        
        @media (max-width: 900px) {
            .sidebar { width: 80px; }
            .sidebar a span:not(.icon) { display: none; }
            .content { margin-left: 80px; }
        }
    </style>
</head>
<body>

    
    
    
    
    <div class="sidebar">
    <h3>✨ Cosmology</h3>
    <a href="admin_dashboard.php"><i class="bi bi-house-door-fill"></i><span>Головна</span></a>
    <a href="admin_clients.php"><i class="bi bi-people-fill"></i><span>Клієнти</span></a>
    <a href="admin_doctors.php"><i class="bi bi-person-badge-fill"></i><span>Лікарі</span></a>
    <a href="admin_services.php"><i class="bi bi-grid-3x3-gap-fill"></i><span>Послуги</span></a>
    <a href="admin_appointments.php"><i class="bi bi-calendar-check-fill"></i><span>Записи</span></a>
    <a href="admin_certificates.php"><i class="bi bi-patch-check-fill"></i><span>Сертифікати</span></a>
    <a href="admin_stock.php"><i class="bi bi-box-seam-fill"></i><span>Склад</span></a>
    <a href="admin_stock_orders.php" class="active" style="background: #c7a17a; color: white;"><i class="bi bi-cart-fill"></i><span>Замовлення</span></a>
    <a href="admin_reviews.php"><i class="bi bi-star-fill"></i><span>Відгуки</span></a>
    <a href="admin_finance.php"><i class="bi bi-graph-up"></i><span>Фінанси</span></a>
    <a href="logout.php"><i class="bi bi-box-arrow-right"></i><span>Вихід</span></a>
</div>
  
    
    <div class="content">
        <h1>🛒 Замовлення постачальникам</h1>
        
        <?php if($message): ?>
            <div class="message"><?= $message ?></div>
        <?php endif; ?>
        
        <!-- Форма створення замовлення -->
        <div class="card">
            <h3>➕ Створити нове замовлення</h3>
            <form method="POST">
                <div class="form-group">
                    <label>📦 Постачальник:</label>
                    <select name="supplier_id" required>
                        <option value="">-- Оберіть постачальника --</option>
                        <?php foreach($suppliers as $s): ?>
                            <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['name']) ?> (<?= htmlspecialchars($s['contact_person'] ?? '') ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <h4>📋 Товари для замовлення:</h4>
                <div style="max-height: 300px; overflow-y: auto; border: 1px solid #f0e6dc; border-radius: 10px; padding: 10px;">
                    <?php foreach($all_items as $item): ?>
                        <div class="order-item">
                            <div>
                                <strong><?= htmlspecialchars($item['name']) ?></strong><br>
                                <small>Код: <?= htmlspecialchars($item['code']) ?> | В наявності: <?= $item['quantity'] ?> шт | Мінімум: <?= $item['min_quantity'] ?> шт</small>
                            </div>
                            <div>
                                <input type="number" name="items[<?= $item['id'] ?>]" value="0" min="0" step="1" style="width:80px;">
                                <span>шт</span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <button type="submit" name="create_order" class="btn btn-primary" style="margin-top:15px;">✅ Створити замовлення</button>
            </form>
        </div>
        
        <!-- Список замовлень -->
        <div class="card">
            <h3>📋 Історія замовлень</h3>
            <?php if(count($orders) > 0): ?>
                <table>
                    <thead>
                        <tr><th>№ замовлення</th><th>Постачальник</th><th>Дата</th><th>Сума</th><th>Статус</th><th>Дії</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach($orders as $o): ?>
                        <tr>
                            <td><?= $o['order_number'] ?></td>
                            <td><?= htmlspecialchars($o['supplier_name']) ?></td>
                            <td><?= date('d.m.Y', strtotime($o['order_date'])) ?></td>
                            <td><?= number_format($o['total_amount'], 0) ?> грн</span>
                            <td>
                                <?php if($o['status'] == 'new'): ?>
                                    <span style="color:#ffc107;">🆕 Нове</span>
                                <?php elseif($o['status'] == 'sent'): ?>
                                    <span style="color:#17a2b8;">📤 Надіслано</span>
                                <?php elseif($o['status'] == 'received'): ?>
                                    <span style="color:#28a745;">✅ Отримано</span>
                                <?php else: ?>
                                    <span style="color:#dc3545;">❌ Скасовано</span>
                                <?php endif; ?>
                             </span>
                            <td>
                                <?php if($o['status'] == 'new'): ?>
                                    <a href="?receive=<?= $o['id'] ?>" class="btn btn-success" onclick="return confirm('Підтвердити отримання замовлення?')">✅ Отримано</a>
                                    <a href="?cancel=<?= $o['id'] ?>" class="btn btn-danger" onclick="return confirm('Скасувати замовлення?')">❌ Скасувати</a>
                                <?php elseif($o['status'] == 'received'): ?>
                                    <span>✅ Завершено</span>
                                <?php else: ?>
                                    <span>❌ Скасовано</span>
                                <?php endif; ?>
                             </span>
                        </table>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>📭 Ще немає жодного замовлення</p>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
    function confirmLogout() {
        if (confirm('Ви дійсно хочете вийти?')) {
            window.location.href = 'logout.php';
        }
    }
    </script>
</body>
</html>