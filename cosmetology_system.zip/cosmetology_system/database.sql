CREATE DATABASE IF NOT EXISTS cosmetology_db;
USE cosmetology_db;

-- Користувачі
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('client', 'cosmetologist', 'admin') DEFAULT 'client',
    birth_date DATE,
    bonus_points INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Майстри (додаткові дані)
CREATE TABLE cosmetologists (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNIQUE,
    experience_years INT,
    rating DECIMAL(2,1) DEFAULT 0,
    photo_url VARCHAR(255),
    description TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Послуги
CREATE TABLE services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    duration_minutes INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    cost_price DECIMAL(10,2),
    is_active BOOLEAN DEFAULT TRUE
);

-- Зв'язок послуг з майстрами
CREATE TABLE service_cosmetologist (
    service_id INT,
    cosmetologist_id INT,
    price_override DECIMAL(10,2),
    PRIMARY KEY (service_id, cosmetologist_id),
    FOREIGN KEY (service_id) REFERENCES services(id),
    FOREIGN KEY (cosmetologist_id) REFERENCES cosmetologists(id)
);

-- Записи клієнтів
CREATE TABLE appointments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    client_id INT NOT NULL,
    cosmetologist_id INT NOT NULL,
    service_id INT NOT NULL,
    appointment_datetime DATETIME NOT NULL,
    status ENUM('pending', 'confirmed', 'completed', 'canceled', 'no_show') DEFAULT 'pending',
    prepayment_amount DECIMAL(10,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES users(id),
    FOREIGN KEY (cosmetologist_id) REFERENCES cosmetologists(id),
    FOREIGN KEY (service_id) REFERENCES services(id)
);

-- Вільні слоти (генеруються на тиждень вперед)
CREATE TABLE time_slots (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cosmetologist_id INT NOT NULL,
    start_datetime DATETIME NOT NULL,
    end_datetime DATETIME NOT NULL,
    is_booked BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (cosmetologist_id) REFERENCES cosmetologists(id)
);

-- Відгуки
CREATE TABLE reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    client_id INT,
    appointment_id INT UNIQUE,
    rating INT CHECK (rating BETWEEN 1 AND 5),
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES users(id),
    FOREIGN KEY (appointment_id) REFERENCES appointments(id)
);