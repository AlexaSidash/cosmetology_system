<?php
// fix_admin.php
require_once 'includes/config.php';

// Новий пароль
$plain_password = 'admin123';

// Створюємо хеш
$new_hash = password_hash($plain_password, PASSWORD_DEFAULT);

echo "<h2>🔧 Виправлення пароля адміністратора</h2>";
echo "Email: admin@cosmology.com<br>";
echo "Новий пароль: <strong>admin123</strong><br>";
echo "Новий хеш: <code>" . $new_hash . "</code><br><br>";

try {
    // Оновлюємо пароль
    $stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE email = ?");
    $stmt->execute([$new_hash, 'admin@cosmology.com']);
    
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 10px;'>";
    echo "✅ Базу даних оновлено!<br>";
    echo "Кількість оновлених рядків: " . $stmt->rowCount() . "<br>";
    echo "</div>";
    
    // Перевіряємо, чи правильно оновилося
    $check = $pdo->prepare("SELECT password_hash FROM users WHERE email = ?");
    $check->execute(['admin@cosmology.com']);
    $user = $check->fetch();
    
    echo "<br>🔍 Перевірка:<br>";
    echo "Хеш в БД після оновлення: <code>" . $user['password_hash'] . "</code><br>";
    
    if (password_verify($plain_password, $user['password_hash'])) {
        echo "<div style='background: #d4edda; padding: 10px; border-radius: 10px; margin-top: 10px;'>";
        echo "✅ <strong>ВІДМІННО!</strong> Пароль 'admin123' тепер працює!<br>";
        echo "</div>";
    } else {
        echo "<div style='background: #f8d7da; padding: 10px; border-radius: 10px; margin-top: 10px;'>";
        echo "❌ <strong>ПОМИЛКА!</strong> Пароль не працює. Спробуйте ще раз.<br>";
        echo "</div>";
    }
    
} catch (PDOException $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 10px;'>";
    echo "❌ Помилка: " . $e->getMessage();
    echo "</div>";
}

echo '<br><a href="admin_login.php" class="btn btn-primary">→ Перейти до входу</a>';
?>