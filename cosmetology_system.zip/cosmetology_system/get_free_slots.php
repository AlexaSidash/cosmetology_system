<?php
// api/get_free_slots.php - РОБОЧА ВЕРСІЯ
header('Content-Type: application/json');

// Отримуємо параметри
$cosmetologist_id = isset($_GET['cosmetologist_id']) ? $_GET['cosmetologist_id'] : 0;
$date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
$service_id = isset($_GET['service_id']) ? $_GET['service_id'] : 0;

// ============================================
// ТЕСТОВІ СЛОТИ - завжди показуємо для будь-якої дати
// ============================================

// Базові слоти на кожен день
$all_slots = [
    "09:00", "10:00", "11:00", "12:00", 
    "13:00", "14:00", "15:00", "16:00", 
    "17:00", "18:00", "19:00"
];

// Перевіряємо день тижня
$dayOfWeek = date('N', strtotime($date));

if ($dayOfWeek == 6) { // Субота
    $free_slots = ["10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00"];
} elseif ($dayOfWeek == 7) { // Неділя
    $free_slots = []; // Неділя - вихідний
} else {
    $free_slots = $all_slots; // Будні - всі слоти
}

// Відповідь
echo json_encode([
    'free_slots' => $free_slots,
    'date' => $date,
    'day_of_week' => $dayOfWeek,
    'message' => count($free_slots) > 0 ? 'OK' : 'Немає слотів на цей день'
]);
?>