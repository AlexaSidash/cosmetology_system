<?php session_start(); ?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>Про нас - Cosmology Beauty</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        
        /* Стилі навігації (такі ж як в index.php) */
        .top-bar { background: #2c2c2c; color: white; padding: 8px 0; text-align: center; font-size: 14px; }
        .header { background: white; box-shadow: 0 2px 15px rgba(0,0,0,0.08); position: sticky; top: 0; z-index: 1000; }
        .nav-container { max-width: 1300px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; padding: 15px 20px; }
        .logo { font-size: 28px; font-weight: bold; color: #c7a17a; }
        .logo span { color: #2c2c2c; }
        .nav-menu { display: flex; list-style: none; gap: 25px; }
        .nav-menu a { text-decoration: none; color: #2c2c2c; font-weight: 500; }
        .nav-menu a:hover { color: #c7a17a; }
        .dropdown { position: relative; }
        .dropdown-content { display: none; position: absolute; background: white; min-width: 220px; box-shadow: 0 8px 16px rgba(0,0,0,0.1); border-radius: 8px; top: 100%; left: 0; }
        .dropdown:hover .dropdown-content { display: block; }
        .dropdown-content a { display: block; padding: 12px 20px; color: #333; }
        .btn-book { background: #c7a17a; color: white !important; padding: 10px 25px; border-radius: 30px; }
        .auth-buttons { display: flex; gap: 15px; }
        .auth-link { color: #2c2c2c; text-decoration: none; }
        
        .about-hero {
            background: linear-gradient(135deg, #f9f5f0, #fff);
            padding: 80px 20px;
            text-align: center;
        }
        .about-hero h1 { font-size: 48px; color: #2c2c2c; margin-bottom: 20px; }
        .about-content { max-width: 1000px; margin: 50px auto; padding: 0 20px; line-height: 1.8; color: #444; }
        .about-content h2 { color: #c7a17a; margin: 30px 0 15px; }
        .features { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 30px; margin: 50px 0; }
        .feature { text-align: center; padding: 30px; background: white; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .feature .icon { font-size: 48px; margin-bottom: 15px; }
        
        .footer { background: #1a1a1a; color: #999; padding: 50px 20px 30px; margin-top: 60px; }
        .footer-content { max-width: 1300px; margin: 0 auto; display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 40px; }
        .footer-column h4 { color: white; margin-bottom: 20px; }
        .footer-bottom { text-align: center; padding-top: 30px; margin-top: 30px; border-top: 1px solid #333; }
    </style>
</head>
<body>
    <div class="top-bar">✨ Нова клієнтка отримує знижку 20% на перший візит ✨</div>
    
    <div class="header">
        <div class="nav-container">
            <div class="logo">Cosmology <span>Beauty</span></div>
            <ul class="nav-menu">
                <li><a href="index.php">Головна</a></li>
                <li><a href="about.php">Про нас</a></li>
                <li class="dropdown">
                    <a href="#">Прайс ▼</a>
                    <div class="dropdown-content">
                        <a href="category.php?cat=injection">Ін'єкційна косметологія</a>
                        <a href="category.php?cat=apparatus">Апаратна косметологія</a>
                        <a href="category.php?cat=laser">Лазерна косметологія</a>
                        <a href="category.php?cat=epilation">Лазерна епіляція</a>
                        <a href="category.php?cat=intimate">Інтимна косметологія</a>
                        <a href="category.php?cat=care">Доглядові процедури</a>
                        <a href="category.php?cat=dermatology">Дерматологія</a>
                    </div>
                </li>
                <li><a href="loyalty.php">Програма лояльності</a></li>
                <li><a href="doctors.php">Лікарі</a></li>
                <li><a href="booking.php" class="btn-book">Записатися</a></li>
            </ul>
            <div class="auth-buttons">
                <?php if(isset($_SESSION['user_id'])): ?>
                    <a href="admin/dashboard.php" class="auth-link">👤 <?= $_SESSION['user_name'] ?></a>
                    <a href="logout.php" class="auth-link">🚪 Вихід</a>
                <?php else: ?>
                    <a href="login.php" class="auth-link">Вхід</a>
                    <a href="register.php" class="auth-link">Реєстрація</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="about-hero">
        <h1>Про наш центр</h1>
        <p>Ваша краса — наша турбота з 2026 року</p>
    </div>
    
    <div class="about-content">
        <h2>Хто ми</h2>
        <p>Cosmology Beauty — це сучасний косметологічний центр у Дніпрі, де поєднуються європейські стандарти, інноваційні методики та індивідуальний підхід до кожної клієнтки. Наша місія — допомогти вам підкреслити природну красу та відчути себе впевнено.</p>
        
        <h2>Чому обирають нас</h2>
        <div class="features">
            <div class="feature"><div class="icon">👩‍⚕️</div><h3>Досвідчені лікарі</h3><p>Сертифіковані фахівці з багаторічним досвідом</p></div>
            <div class="feature"><div class="icon">🏆</div><h3>Преміальні засоби</h3><p>Тільки оригінальна продукція та препарати</p></div>
            <div class="feature"><div class="icon">🔬</div><h3>Сучасне обладнання</h3><p>Лазери, апарати останнього покоління</p></div>
            <div class="feature"><div class="icon">🤝</div><h3>Індивідуальний підхід</h3><p>Програма догляду саме для вашої шкіри</p></div>
        </div>
        
        <h2>Наші принципи</h2>
        <p>✔ Безпека та стерильність — понад усе<br>
        <p> ✔ Прозорі ціни без прихованих доплат<br>
         <p>✔ Конфіденційність та повага до кожного клієнта<br>
 <p>✔ Постійне підвищення кваліфікації персоналу</p>

        <h2>Ліцензії та сертифікати</h2>
        <p>Наш центр має всі необхідні ліцензії на провадження медичної практики. Ми регулярно проходимо перевірки та підтверджуємо високий рівень надання послуг. Всі косметологи мають сертифікати міжнародного зразка.</p>
        
        <h2>Наша історія</h2>
        <p>Cosmology Beauty відкрив свої двері у 2026 році. За цей час ми виросли з невеликого кабінету до сучасного центру площею 200 м², де щодня понад 30 клієнток довіряють нам свою красу. Ми постійно вдосконалюємося, слідкуємо за світовими трендами та впроваджуємо найновіші методики.</p>
    </div>
    
    <div class="footer">
        <div class="footer-content">
            <div class="footer-column">
                <h4>Cosmology Beauty</h4>
                <p>Ваша краса - наша турбота. Професійна косметологія з використанням сучасних методик та преміальних засобів.</p>
            </div>
            <div class="footer-column">
                <h4>Контакти</h4>
                <p>📍 м. Дніпро, вул. Хрещатик, 15</p>
                <p>📞 (098) 123-45-67</p>
                <p>📞 (099) 123-45-67</p>
                <p>✉️ info@cosmology-beauty.com</p>
            </div>
            <div class="footer-column">
                <h4>Години роботи</h4>
                <p>Пн-Пт: 9:00 - 20:00</p>
                <p>Сб: 10:00 - 18:00</p>
                <p>Нд: Вихідний</p>
            </div>
            <div class="footer-column">
                <h4>Соціальні мережі</h4>
                <a href="#">📷 Instagram</a>
                <a href="#">📘 Facebook</a>
                <a href="#">📱 Telegram</a>
                <a href="#">🎥 TikTok</a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>© 2026 Cosmetology Beauty. Всі права захищено.</p>
            <p>м. Дніпро, вул. Хрещатик, 15 | Тел: (098) 123-45-67</p>
        </div>
    </div>
</body>
</html>