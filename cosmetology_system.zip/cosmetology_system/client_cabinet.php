<?php
session_start();
require_once 'includes/config.php';

// Перевірка авторизації
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'client') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Отримуємо дані клієнта
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$client = $stmt->fetch();

// Отримуємо майбутні записи
$stmt = $pdo->prepare("
    SELECT a.*, s.name as service_name, s.price, s.duration_minutes,
           u.full_name as doctor_name, c.rating as doctor_rating
    FROM appointments a
    JOIN services s ON a.service_id = s.id
    JOIN cosmetologists c ON a.cosmetologist_id = c.id
    JOIN users u ON c.user_id = u.id
    WHERE a.client_id = ? AND a.appointment_datetime > NOW() AND a.status NOT IN ('canceled', 'completed')
    ORDER BY a.appointment_datetime ASC
");
$stmt->execute([$user_id]);
$upcoming_appointments = $stmt->fetchAll();

// Отримуємо історію записів
$stmt = $pdo->prepare("
    SELECT a.*, s.name as service_name, s.price,
           u.full_name as doctor_name, c.id as cosmetologist_id
    FROM appointments a
    JOIN services s ON a.service_id = s.id
    JOIN cosmetologists c ON a.cosmetologist_id = c.id
    JOIN users u ON c.user_id = u.id
    WHERE a.client_id = ? AND (a.appointment_datetime < NOW() OR a.status = 'completed')
    ORDER BY a.appointment_datetime DESC
    LIMIT 10
");
$stmt->execute([$user_id]);
$history_appointments = $stmt->fetchAll();

// Отримуємо сповіщення
$stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? AND is_read = 0 ORDER BY created_at DESC LIMIT 5");
$stmt->execute([$user_id]);
$notifications = $stmt->fetchAll();

// Отримуємо історію бонусів
$stmt = $pdo->prepare("SELECT * FROM bonus_history WHERE client_id = ? ORDER BY created_at DESC LIMIT 10");
$stmt->execute([$user_id]);
$bonus_history = $stmt->fetchAll();

// Отримуємо відгуки користувача
$stmt = $pdo->prepare("
    SELECT r.*, s.name as service_name, u.full_name as doctor_name 
    FROM reviews r
    JOIN appointments a ON r.appointment_id = a.id
    JOIN services s ON a.service_id = s.id
    JOIN cosmetologists c ON a.cosmetologist_id = c.id
    JOIN users u ON c.user_id = u.id
    WHERE r.client_id = ?
    ORDER BY r.created_at DESC
");
$stmt->execute([$user_id]);
$user_reviews = $stmt->fetchAll();

// Отримуємо завершені візити без відгуків
$stmt = $pdo->prepare("
    SELECT a.id, a.appointment_datetime, s.name as service_name, 
           u.full_name as doctor_name, c.id as cosmetologist_id
    FROM appointments a
    JOIN services s ON a.service_id = s.id
    JOIN cosmetologists c ON a.cosmetologist_id = c.id
    JOIN users u ON c.user_id = u.id
    LEFT JOIN reviews r ON a.id = r.appointment_id
    WHERE a.client_id = ? 
        AND a.status = 'completed' 
        AND a.appointment_datetime < NOW()
        AND r.id IS NULL
    ORDER BY a.appointment_datetime DESC
");
$stmt->execute([$user_id]);
$unreviewed_appointments = $stmt->fetchAll();

// Рекомендації
$stmt = $pdo->prepare("
    SELECT DISTINCT s.id, s.name, s.price, COUNT(a.id) as popularity
    FROM appointments a
    JOIN services s ON a.service_id = s.id
    WHERE a.client_id != ? AND s.is_active = 1
    GROUP BY s.id
    ORDER BY popularity DESC
    LIMIT 3
");
$stmt->execute([$user_id]);
$recommendations = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мій кабінет - Cosmology Beauty</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f0eb; }
        
        .top-bar { background: #2c2c2c; color: white; padding: 8px 0; text-align: center; font-size: 14px; }
        .header { background: white; box-shadow: 0 2px 15px rgba(0,0,0,0.08); position: sticky; top: 0; z-index: 1000; }
        .nav-container { max-width: 1300px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; padding: 15px 20px; flex-wrap: wrap; gap: 15px; }
        .logo { font-size: 28px; font-weight: bold; color: #c7a17a; }
        .logo span { color: #2c2c2c; }
        .nav-menu { display: flex; list-style: none; gap: 25px; flex-wrap: wrap; }
        .nav-menu a { text-decoration: none; color: #2c2c2c; font-weight: 500; }
        .nav-menu a:hover { color: #c7a17a; }
        .btn-book { background: #c7a17a; color: white !important; padding: 10px 25px; border-radius: 30px; }
        .auth-buttons { display: flex; gap: 15px; align-items: center; }
        
        .dashboard { max-width: 1300px; margin: 30px auto; padding: 0 20px; }
        
        .welcome-card {
            background: linear-gradient(135deg, #c7a17a, #a67c52);
            color: white;
            padding: 30px;
            border-radius: 25px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
        }
        .welcome-card h1 { font-size: 28px; margin-bottom: 10px; }
        .bonus-box { background: rgba(255,255,255,0.2); padding: 15px 25px; border-radius: 20px; text-align: center; }
        .bonus-box .bonus-value { font-size: 32px; font-weight: bold; }
        
        .profile-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px;
            margin-bottom: 30px;
        }
        .profile-card {
            background: white;
            border-radius: 20px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
        .profile-card h3 {
            color: #c7a17a;
            margin-bottom: 20px;
            font-size: 20px;
            border-bottom: 2px solid #f0e6dc;
            padding-bottom: 10px;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid #f0e6dc;
        }
        .info-label { color: #666; font-weight: 500; }
        .info-value { color: #2c2c2c; font-weight: 500; }
        
        .appointments-section {
            background: white;
            border-radius: 20px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
        .appointments-section h3 {
            color: #c7a17a;
            margin-bottom: 20px;
            font-size: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #f0e6dc;
        }
        th { color: #666; font-weight: 600; }
        .status-confirmed { color: #28a745; font-weight: 600; }
        .status-pending { color: #ffc107; font-weight: 600; }
        .status-completed { color: #17a2b8; }
        .status-canceled { color: #dc3545; }
        
        .btn-cancel {
            background: #dc3545;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 12px;
        }
        .btn-cancel:hover { background: #c82333; }
        .btn-edit {
            background: #c7a17a;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 12px;
            margin-right: 5px;
        }
        
        .recommendations-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 15px;
        }
        .rec-card {
            background: #f9f5f0;
            border-radius: 15px;
            padding: 20px;
            text-align: center;
        }
        .rec-card h4 { color: #c7a17a; margin-bottom: 10px; }
        .rec-card .price { font-size: 20px; font-weight: bold; margin: 10px 0; }
        .rec-card .btn { background: #c7a17a; color: white; padding: 8px 20px; border-radius: 25px; text-decoration: none; display: inline-block; }
        
        .edit-profile-btn {
            background: #c7a17a;
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 25px;
            cursor: pointer;
            margin-top: 15px;
        }
        
        /* Стилі для відгуків */
        .review-form {
            background: #fef8f2;
            padding: 20px;
            border-radius: 15px;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #2c2c2c;
            font-weight: 500;
        }
        .form-group select, 
        .form-group input, 
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-family: inherit;
        }
        .form-group textarea {
            resize: vertical;
            min-height: 100px;
        }
        .rating-stars {
            display: flex;
            gap: 10px;
            flex-direction: row-reverse;
            justify-content: flex-end;
        }
        .rating-stars input {
            display: none;
        }
        .rating-stars label {
            font-size: 30px;
            color: #ddd;
            cursor: pointer;
            transition: color 0.2s;
        }
        .rating-stars label:hover,
        .rating-stars label:hover ~ label,
        .rating-stars input:checked ~ label {
            color: #ffc107;
        }
        .btn-submit {
            background: #c7a17a;
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 25px;
            cursor: pointer;
            font-size: 16px;
        }
        .btn-submit:hover {
            background: #a67c52;
        }
        .review-item {
            border-bottom: 1px solid #f0e6dc;
            padding: 15px 0;
        }
        .review-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
            flex-wrap: wrap;
        }
        .review-rating {
            color: #ffc107;
            font-size: 18px;
        }
        .review-date {
            color: #999;
            font-size: 12px;
        }
        .review-comment {
            color: #555;
            line-height: 1.5;
            margin: 10px 0;
        }
        .review-status {
            font-size: 12px;
            padding: 3px 10px;
            border-radius: 12px;
            background: #f0e6dc;
            display: inline-block;
        }
        .review-status.approved {
            background: #d4edda;
            color: #155724;
        }
        .review-status.pending {
            background: #fff3cd;
            color: #856404;
        }
        .doctor-response {
            background: #f8f9fa;
            padding: 12px;
            border-radius: 10px;
            margin-top: 10px;
            font-size: 14px;
            border-left: 3px solid #c7a17a;
        }
        
        .footer {
            background: #1a1a1a;
            color: #999;
            padding: 40px 20px 30px;
            margin-top: 40px;
        }
        .footer-content { max-width: 1300px; margin: 0 auto; display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 40px; }
        .footer-bottom { text-align: center; padding-top: 30px; border-top: 1px solid #333; }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        .modal-content {
            background: white;
            padding: 30px;
            border-radius: 20px;
            width: 90%;
            max-width: 500px;
        }
        .modal-content input, .modal-content select, .modal-content textarea {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 8px;
        }
        
        @media (max-width: 800px) {
            .profile-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="top-bar">✨ Нова клієнтка отримує знижку 20% на перший візит ✨</div>
    
    <div class="header">
        <div class="nav-container">
            <div class="logo">Cosmology <span>Beauty</span></div>
            <ul class="nav-menu">
                <li><a href="index.php">Головна</a></li>
                <li><a href="booking.php">Записатися</a></li>
                <li><a href="client_cabinet.php" style="color:#c7a17a;">Мій кабінет</a></li>
                <li><a href="logout.php">Вихід</a></li>
            </ul>
            <div class="auth-buttons">
                <span>👤 <?= htmlspecialchars($_SESSION['user_name']) ?></span>
            </div>
        </div>
    </div>
    
    <div class="dashboard">
        <div class="welcome-card">
            <div>
                <h1>Вітаємо, <?= htmlspecialchars($client['full_name']) ?>!</h1>
                <p>Ваш шлях до краси починається тут</p>
            </div>
            <div class="bonus-box">
                <div class="bonus-value"><?= number_format($client['bonus_points'] ?? 0) ?></div>
                <div>бонусних балів</div>
                <small>1 бал = 1 грн</small>
            </div>
        </div>
        
        <?php if(count($notifications) > 0): ?>
        <div class="profile-card" style="margin-bottom: 20px; background: #fef3e8;">
            <h3>🔔 Сповіщення</h3>
            <?php foreach($notifications as $notif): ?>
                <p style="padding: 8px 0; border-bottom: 1px solid #f0e6dc;">
                    <strong><?= htmlspecialchars($notif['title']) ?></strong><br>
                    <?= htmlspecialchars($notif['message']) ?>
                </p>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
        
        <div class="profile-grid">
            <div class="profile-card">
                <h3>👤 Мої дані</h3>
                <div class="info-row"><span class="info-label">ПІБ:</span><span class="info-value"><?= htmlspecialchars($client['full_name']) ?></span></div>
                <div class="info-row"><span class="info-label">Email:</span><span class="info-value"><?= htmlspecialchars($client['email']) ?></span></div>
                <div class="info-row"><span class="info-label">Телефон:</span><span class="info-value"><?= htmlspecialchars($client['phone']) ?></span></div>
                <div class="info-row"><span class="info-label">Дата реєстрації:</span><span class="info-value"><?= date('d.m.Y', strtotime($client['created_at'])) ?></span></div>
                <div class="info-row"><span class="info-label">Бонусів нараховано:</span><span class="info-value"><?= number_format($client['bonus_points'] ?? 0) ?> грн</span></div>
            </div>
            
            <div class="profile-card">
                <h3>📊 Статистика</h3>
                <div class="info-row"><span class="info-label">Всього візитів:</span><span class="info-value"><?= count($history_appointments) + count($upcoming_appointments) ?></span></div>
                <div class="info-row"><span class="info-label">Майбутніх записів:</span><span class="info-value"><?= count($upcoming_appointments) ?></span></div>
                <div class="info-row"><span class="info-label">Загальна сума:</span><span class="info-value"><?php 
                    $total = 0;
                    foreach($history_appointments as $a) if($a['status'] == 'completed') $total += $a['price'];
                    echo number_format($total, 0) . " грн";
                ?></span></div>
                <div class="info-row"><span class="info-label">Рівень:</span><span class="info-value">
                    <?php 
                    if($total < 2000) echo "🌟 Новачок (5% бонусів)";
                    elseif($total < 5000) echo "✨ Преміум (7% бонусів)";
                    else echo "👑 VIP (10% бонусів)";
                    ?>
                </span></div>
            </div>
        </div>
        
        <!-- Форма залишення відгуку -->
        <?php if(count($unreviewed_appointments) > 0): ?>
        <div class="appointments-section">
            <h3>✍️ Залишити відгук про візит</h3>
            <div class="review-form">
                <form id="reviewForm">
                    <div class="form-group">
                        <label>Оберіть візит:</label>
                        <select id="appointment_id" name="appointment_id" required>
                            <option value="">-- Виберіть візит --</option>
                            <?php foreach($unreviewed_appointments as $apt): ?>
                                <option value="<?= $apt['id'] ?>" data-doctor-id="<?= $apt['cosmetologist_id'] ?>">
                                    <?= date('d.m.Y H:i', strtotime($apt['appointment_datetime'])) ?> - <?= htmlspecialchars($apt['service_name']) ?> (др. <?= htmlspecialchars($apt['doctor_name']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Ваша оцінка:</label>
                        <div class="rating-stars">
                            <input type="radio" name="rating" value="5" id="star5"><label for="star5">★</label>
                            <input type="radio" name="rating" value="4" id="star4"><label for="star4">★</label>
                            <input type="radio" name="rating" value="3" id="star3"><label for="star3">★</label>
                            <input type="radio" name="rating" value="2" id="star2"><label for="star2">★</label>
                            <input type="radio" name="rating" value="1" id="star1"><label for="star1">★</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Ваш відгук:</label>
                        <textarea id="comment" name="comment" placeholder="Розкажіть про ваш досвід... (мінімум 10 символів)" required></textarea>
                    </div>
                    <button type="submit" class="btn-submit">📝 Надіслати відгук</button>
                </form>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Мої відгуки -->
        <?php if(count($user_reviews) > 0): ?>
        <div class="appointments-section">
            <h3>⭐ Мої відгуки</h3>
            <?php foreach($user_reviews as $review): ?>
                <div class="review-item">
                    <div class="review-header">
                        <div>
                            <strong><?= htmlspecialchars($review['service_name']) ?></strong> — др. <?= htmlspecialchars($review['doctor_name']) ?>
                            <div class="review-rating">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <?= $i <= $review['rating'] ? '★' : '☆' ?>
                                <?php endfor; ?>
                            </div>
                        </div>
                        <div>
                            <span class="review-status <?= $review['is_approved'] ? 'approved' : 'pending' ?>">
                                <?= $review['is_approved'] ? '✅ Опубліковано' : '⏳ На модерації' ?>
                            </span>
                            <div class="review-date"><?= date('d.m.Y H:i', strtotime($review['created_at'])) ?></div>
                        </div>
                    </div>
                    <div class="review-comment"><?= nl2br(htmlspecialchars($review['comment'])) ?></div>
                    <?php if(!empty($review['doctor_response'])): ?>
                        <div class="doctor-response">
                            <strong>👩‍⚕️ Відповідь лікаря:</strong><br>
                            <?= nl2br(htmlspecialchars($review['doctor_response'])) ?>
                            <small style="color:#999; display:block; margin-top:5px;">
                                <?= date('d.m.Y', strtotime($review['response_date'])) ?>
                            </small>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
        
        <?php if(count($recommendations) > 0): ?>
        <div class="appointments-section">
            <h3>💡 Рекомендуємо для вас</h3>
            <div class="recommendations-grid">
                <?php foreach($recommendations as $rec): ?>
                <div class="rec-card">
                    <h4><?= htmlspecialchars($rec['name']) ?></h4>
                    <div class="price"><?= number_format($rec['price'], 0) ?> грн</div>
                    <a href="booking.php" class="btn">Записатися →</a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <div class="appointments-section">
            <h3>📅 Найближчі записи</h3>
            <?php if(count($upcoming_appointments) > 0): ?>
                <table>
                    <thead>
                        <tr><th>Дата та час</th><th>Послуга</th><th>Лікар</th><th>Статус</th><th>Сума</th><th>Дії</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach($upcoming_appointments as $app): ?>
                        <tr>
                            <td><?= date('d.m.Y H:i', strtotime($app['appointment_datetime'])) ?></td>
                            <td><?= htmlspecialchars($app['service_name']) ?></td>
                            <td><?= htmlspecialchars($app['doctor_name']) ?> ⭐<?= $app['doctor_rating'] ?></td>
                            <td><span class="status-<?= $app['status'] ?>"><?= $app['status'] == 'confirmed' ? '✅ Підтверджено' : '⏳ Очікує' ?></span></td>
                            <td><?= number_format($app['price'], 0) ?> грн</td>
                            <td>
                                <button class="btn-cancel" onclick="cancelAppointment(<?= $app['id'] ?>)">❌ Скасувати</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>У вас немає найближчих записів. <a href="booking.php">Записатися →</a></p>
            <?php endif; ?>
        </div>
        
        <div class="appointments-section">
            <h3>📜 Історія візитів</h3>
            <?php if(count($history_appointments) > 0): ?>
                <table>
                    <thead>
                        <tr><th>Дата</th><th>Послуга</th><th>Лікар</th><th>Статус</th><th>Сума</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php foreach($history_appointments as $app): ?>
                        <tr>
                            <td><?= date('d.m.Y', strtotime($app['appointment_datetime'])) ?></td>
                            <td><?= htmlspecialchars($app['service_name']) ?></td>
                            <td><?= htmlspecialchars($app['doctor_name']) ?></td>
                            <td class="status-<?= $app['status'] ?>"><?= $app['status'] == 'completed' ? '✅ Виконано' : '❌ Скасовано' ?></td>
                            <td><?= number_format($app['price'], 0) ?> грн</td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>Історія візитів порожня</p>
            <?php endif; ?>
        </div>
        
        <div class="appointments-section">
            <h3>💰 Історія бонусів</h3>
            <?php if(count($bonus_history) > 0): ?>
                <table>
                    <thead><tr><th>Дата</th><th>Сума</th><th>Тип</th><th>Джерело</th></tr></thead>
                    <tbody>
                        <?php foreach($bonus_history as $bonus): ?>
                        <tr>
                            <td><?= date('d.m.Y', strtotime($bonus['created_at'])) ?></td>
                            <td style="color: <?= $bonus['type'] == 'earned' ? '#28a745' : '#dc3545' ?>">
                                <?= $bonus['type'] == 'earned' ? '+' : '-' ?> <?= $bonus['amount'] ?> грн
                             </td>
                            <td><?= $bonus['type'] == 'earned' ? 'Нараховано' : 'Витрачено' ?></td>
                            <td><?= htmlspecialchars($bonus['source'] ?? '-') ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>Історія бонусів порожня</p>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="footer">
        <div class="footer-content">
            <div class="footer-column"><h4>Cosmology Beauty</h4><p>Ваша краса - наша турбота.</p></div>
            <div class="footer-column"><h4>Контакти</h4><p>📍 м. Дніпро, вул. Хрещатик, 15</p><p>📞 (098) 123-45-67</p></div>
        </div>
        <div class="footer-bottom"><p>© 2026 Cosmetology Beauty. Всі права захищено.</p></div>
    </div>
    
    <div id="reviewModal" class="modal">
        <div class="modal-content">
            <h3>Дякуємо за відгук!</h3>
            <p>Ваш відгук відправлено на модерацію. Після перевірки він з'явиться на сайті.</p>
            <button onclick="closeModal()" style="margin-top:15px; padding:10px 20px; background:#c7a17a; color:white; border:none; border-radius:8px; cursor:pointer;">Закрити</button>
        </div>
    </div>
    
    <script>
    // Відправка форми відгуку
    document.getElementById('reviewForm')?.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const appointmentId = document.getElementById('appointment_id').value;
        const rating = document.querySelector('input[name="rating"]:checked')?.value;
        const comment = document.getElementById('comment').value;
        
        if (!appointmentId) {
            alert('Будь ласка, оберіть візит');
            return;
        }
        if (!rating) {
            alert('Будь ласка, поставте оцінку');
            return;
        }
        if (comment.length < 10) {
            alert('Відгук повинен містити хоча б 10 символів');
            return;
        }
        
        const formData = new FormData();
        formData.append('appointment_id', appointmentId);
        formData.append('rating', rating);
        formData.append('comment', comment);
        
        try {
            const response = await fetch('api/add_review.php', {
                method: 'POST',
                body: formData
            });
            const data = await response.json();
            
            if (data.success) {
                document.getElementById('reviewModal').style.display = 'flex';
                document.getElementById('reviewForm').reset();
                setTimeout(() => location.reload(), 2000);
            } else {
                alert('Помилка: ' + data.message);
            }
        } catch (error) {
            alert('Помилка при відправці відгуку');
        }
    });
    
    function cancelAppointment(id) {
        if(confirm('Ви впевнені, що хочете скасувати запис?')) {
            fetch('api/cancel_appointment.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'appointment_id=' + id
            }).then(response => response.json()).then(data => {
                if(data.success) location.reload();
                else alert('Помилка: ' + data.error);
            });
        }
    }
    
    function closeModal() {
        document.getElementById('reviewModal').style.display = 'none';
        location.reload();
    }
    </script>
</body>
</html>